import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import LabelEncoder

def preprocess_data(df, is_train=True):
    # 불필요한 기능 제거
    cols_to_drop = ['PassengerId', 'Name', 'Ticket', 'Cabin']
    df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])
    
    # 결측치 처리
    df['Age'] = df['Age'].fillna(df['Age'].median())
    df['Fare'] = df['Fare'].fillna(df['Fare'].median())
    df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])
    
    # 범주형 변수 인코딩
    le = LabelEncoder()
    df['Sex'] = le.fit_transform(df['Sex'])
    df['Embarked'] = le.fit_transform(df['Embarked'])
    
    return df

def main():
    # 1. 데이터 로드
    print("데이터를 로드하는 중...")
    train_df = pd.read_csv('titanic_train.csv')
    test_df = pd.read_csv('titanic_test.csv')
    
    # 2. 데이터 전처리
    print("데이터 전처리 중...")
    train_data = preprocess_data(train_df)
    test_data = preprocess_data(test_df)
    
    X = train_data.drop('Survived', axis=1)
    y = train_data['Survived']
    
    # 3. 모델 학습 및 검증 (Train Split)
    # 실제 test.csv 에는 Survived 라벨이 없으므로 train 데이터의 일부를 검증용으로 사용합니다.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("RandomForest 모델 학습 중...")
    rf_model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
    rf_model.fit(X_train, y_train)
    
    # 4. 검증 데이터 평가
    y_pred = rf_model.predict(X_val)
    print("\n[모델 평가 결과 - Validation Set]")
    print(f"Accuracy: {accuracy_score(y_val, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_val, y_pred))
    
    # 5. titanic_test.csv 에 대한 예측 수행
    print("\ntitanic_test.csv 데이터 예측 중...")
    # test_data에 PassengerId가 없으므로 원본 test_df에서 가져옴
    test_X = test_data
    test_preds = rf_model.predict(test_X)
    
    # 결과 출력 (상위 10개)
    result = pd.DataFrame({
        'PassengerId': test_df['PassengerId'],
        'Survived': test_preds
    })
    
    print("\n[titanic_test.csv 예측 결과 (상위 10개)]")
    print(result.head(10))
    
    # 결과 저장
    result.to_csv('titanic_predictions.csv', index=False)
    print("\n예측 결과가 'titanic_predictions.csv'로 저장되었습니다.")

if __name__ == "__main__":
    main()

