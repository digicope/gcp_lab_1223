import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# 시각화 결과 저장 디렉토리 생성
if not os.path.exists('plots'):
    os.makedirs('plots')

def main():
    # 1. 데이터 로드
    print("데이터를 로딩 중입니다...")
    df = pd.read_csv('titanic_train.csv')

    # 한글 폰트 설정 (Windows 기준 기본 폰트 사용 시도, 필요 시 생략 가능)
    # plt.rc('font', family='Malgun Gothic') 
    # plt.rcParams['axes.unicode_minus'] = False

    # 2. 생존자 수 분포 (Count Plot)
    print("1. 생존자 수 분포 시각화 중...")
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Survived', data=df, palette='Set2')
    plt.title('Survival Count (0 = Dead, 1 = Survived)')
    plt.savefig('plots/survival_count.png')
    plt.close()

    # 3. 객실 등급별 생존자 수 (Pclass vs Survived)
    print("2. 객실 등급별 생존자 분석 중...")
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Pclass', hue='Survived', data=df, palette='viridis')
    plt.title('Survival by Passenger Class')
    plt.savefig('plots/survival_by_pclass.png')
    plt.close()

    # 4. 성별에 따른 생존자 수 (Sex vs Survived)
    print("3. 성별에 따른 생존자 분석 중...")
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Sex', hue='Survived', data=df, palette='pastel')
    plt.title('Survival by Gender')
    plt.savefig('plots/survival_by_gender.png')
    plt.close()

    # 5. 연령대 분포 (Age Distribution)
    print("4. 연령대 분포 분석 중...")
    plt.figure(figsize=(10, 6))
    sns.histplot(df['Age'].dropna(), kde=True, color='blue', bins=30)
    plt.title('Age Distribution of Passengers')
    plt.xlabel('Age')
    plt.savefig('plots/age_distribution.png')
    plt.close()

    # 6. 상관관계 히트맵 (Correlation Heatmap)
    print("5. 상관관계 분석 중...")
    plt.figure(figsize=(10, 8))
    # 숫자형 데이터만 추출
    numeric_df = df.select_dtypes(include=['float64', 'int64'])
    sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm', fmt='.2f')
    plt.title('Correlation Heatmap')
    plt.savefig('plots/correlation_heatmap.png')
    plt.close()

    print("\n분석이 완료되었습니다. 모든 그래프가 'plots/' 폴더에 저장되었습니다.")

if __name__ == "__main__":
    main()

