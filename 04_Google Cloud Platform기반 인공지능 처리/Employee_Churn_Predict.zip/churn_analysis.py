import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sys
import io
import os

# Windows 환경에서 한글 깨짐 방지 및 출력 설정
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')

# Matplotlib 한글 폰트 설정 (Windows 기준)
plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False

# 저장용 디렉토리 생성
output_dir = 'analysis_results'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 1. 데이터 로드
try:
    df = pd.read_excel('이직할 직원_학습용.xlsx')
    print("데이터를 성공적으로 불러왔습니다.")
except Exception as e:
    print(f"오류 발생: {e}")
    sys.exit(1)

# 2. 데이터 분석 및 시각화

# (1) 이직 여부 비율 (Pie Chart)
plt.figure(figsize=(8, 6))
df['이직'].value_counts().plot.pie(autopct='%1.1f%%', startangle=90, colors=['#66b3ff','#ff9999'])
plt.title('전체 직원 이직 비율')
plt.ylabel('')
plt.savefig(f'{output_dir}/01_churn_ratio.png')
print("1. 이직 비율 그래프 저장 완료")

# (2) 부서별 이직 현황 (Count Plot)
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x='부서', hue='이직', palette='viridis')
plt.title('부서별 이직 현황')
plt.xlabel('부서')
plt.ylabel('직원 수')
plt.savefig(f'{output_dir}/02_churn_by_department.png')
print("2. 부서별 이직 현황 그래프 저장 완료")

# (3) 나이대별 이직 분포 (Histogram)
plt.figure(figsize=(10, 6))
sns.histplot(data=df, x='나이', hue='이직', kde=True, element="step", palette='magma')
plt.title('나이대별 이직 분포')
plt.xlabel('나이')
plt.ylabel('빈도')
plt.savefig(f'{output_dir}/03_age_distribution.png')
print("3. 나이대별 이직 분포 그래프 저장 완료")

# (4) 직무만족도와 이직의 관계 (Box Plot)
# 만족도 데이터가 문자열일 경우 순서 지정을 위해 카테고리화가 필요할 수 있음
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x='직무만족도', hue='이직', palette='Set2')
plt.title('직무만족도별 이직 현황')
plt.xlabel('직무만족도')
plt.ylabel('직원 수')
plt.savefig(f'{output_dir}/04_job_satisfaction.png')
print("4. 직무만족도별 이직 현황 그래프 저장 완료")

# (5) 월급과 총경력의 상관관계 (Scatter Plot)
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x='총경력', y='월급($)', hue='이직', alpha=0.6)
plt.title('총경력 대비 월급 및 이직 현황')
plt.xlabel('총경력 (년)')
plt.ylabel('월급 ($)')
plt.savefig(f'{output_dir}/05_salary_vs_experience.png')
print("5. 총경력 대비 월급 상관관계 그래프 저장 완료")

print(f"\n모든 분석 결과가 '{output_dir}' 폴더에 저장되었습니다.")

