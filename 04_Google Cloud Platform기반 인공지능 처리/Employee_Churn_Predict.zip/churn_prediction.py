import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import LabelEncoder
import sys
import io

# Windows 환경에서 한글 출력을 위한 설정
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8')

# 1. 데이터 로드
try:
    train_df = pd.read_excel('이직할 직원_학습용.xlsx')
    test_df = pd.read_excel('이직할 직원_예측용.xlsx')
except Exception as e:
    print(f"파일을 읽는 중 오류가 발생했습니다: {e}")
    sys.exit(1)

# 2. 데이터 전처리
# '이직' 컬럼(타겟) 수치화 (Yes -> 1, No -> 0)
le_target = LabelEncoder()
train_df['이직'] = le_target.fit_transform(train_df['이직'])

# 범주형 컬럼 리스트 추출 (object 타입)
categorical_cols = train_df.select_dtypes(include=['object']).columns

# 학습 데이터와 예측 데이터의 범주형 변수 처리
for col in categorical_cols:
    le = LabelEncoder()
    train_df[col] = train_df[col].astype(str)
    test_df[col] = test_df[col].astype(str)
    
    # train과 test의 범주형 데이터를 통합하여 학습 (새로운 범주 대응)
    le.fit(pd.concat([train_df[col], test_df[col]]))
    train_df[col] = le.transform(train_df[col])
    test_df[col] = le.transform(test_df[col])

# 피처와 타겟 분리
X = train_df.drop('이직', axis=1)
y = train_df['이직']

# 3. 모델 학습 및 검증 데이터 분할
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 4. RandomForest 모델 생성 및 학습
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# 5. 모델 평가 (학습용 데이터의 일부를 검증용으로 사용)
y_val_pred = rf_model.predict(X_val)
print("### [검증 결과] 학습 데이터 기반 평가 ###")
print(f"정확도(Accuracy): {accuracy_score(y_val, y_val_pred):.4f}")
print("\n[상세 평가 지표]")
print(classification_report(y_val, y_val_pred, target_names=le_target.classes_))

# 6. '예측용' 데이터로 최종 예측 수행
X_test = test_df.drop('이직', axis=1)
test_predictions = rf_model.predict(X_test)
test_pred_proba = rf_model.predict_proba(X_test)[:, 1]

# 결과를 원본 '예측용' 데이터 프레임에 추가
test_df_result = pd.read_excel('이직할 직원_예측용.xlsx')
test_df_result['이직_예측'] = le_target.inverse_transform(test_predictions)
test_df_result['이직_확률'] = test_pred_proba

print("\n### [최종 예측 결과] '이직할 직원_예측용.xlsx' 결과 ###")
# 주요 컬럼만 출력 (나이, 성별, 부서 등)
display_cols = ['나이', '성별', '부서', '이직_예측', '이직_확률']
print(test_df_result[display_cols].to_string(index=False))

# 결과 저장
output_file = '이직_예측_결과.xlsx'
test_df_result.to_excel(output_file, index=False)
print(f"\n전체 예측 결과가 '{output_file}' 파일로 저장되었습니다.")

