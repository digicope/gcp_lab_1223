from typing import Dict, List, Union
from google.cloud import aiplatform

def predict_vertex_ai_endpoint(
    project: str,
    endpoint_id: str,
    instances: List[Dict],
    location: str = "us-central1",
):
    """
    GCP Vertex AI 엔드포인트로 예측 요청을 보냅니다.
    """
    # AI Platform 초기화
    aiplatform.init(project=project, location=location)

    # 엔드포인트 객체 생성
    endpoint = aiplatform.Endpoint(endpoint_id)

    # 예측 요청
    response = endpoint.predict(instances=instances)

    print("--- 예측 결과 ---")
    for prediction in response.predictions:
        print(prediction)
    
    print(f"\n배포된 모델 ID: {response.deployed_model_id}")
    return response

if __name__ == "__main__":
    # 설정 정보
    PROJECT_ID = "105186977018"
    ENDPOINT_ID = "8065893056550797312"
    LOCATION = "us-central1"

    # 입력 데이터 (curl 예시의 instances 내용)
    instances = [
        {
            "age": "18.58433593", 
            "ClientID": "5", 
            "income": "66952.68885", 
            "loan": "8770.099235"
        }
    ]

    try:
        predict_vertex_ai_endpoint(
            project=PROJECT_ID,
            endpoint_id=ENDPOINT_ID,
            instances=instances,
            location=LOCATION
        )
    except Exception as e:
        print(f"오류가 발생했습니다: {e}")
        print("\n도움말: 'google-cloud-aiplatform' 패키지가 설치되어 있는지, ")
        print("그리고 'gcloud auth application-default login'을 통해 인증되었는지 확인하세요.")

