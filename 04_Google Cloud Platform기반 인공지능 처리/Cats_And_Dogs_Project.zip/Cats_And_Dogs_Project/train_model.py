import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import os

# 데이터 경로 설정
# 현재 작업 디렉토리의 cats_and_dogs_filtered 폴더를 기준으로 합니다.
base_dir = 'cats_and_dogs_filtered'
train_dir = os.path.join(base_dir, 'train')
validation_dir = os.path.join(base_dir, 'validation')

# 이미지 크기 및 배치 사이즈 설정
IMG_SIZE = (150, 150)
BATCH_SIZE = 32

print("데이터셋을 로드하는 중...")

# 데이터셋 로드
train_dataset = tf.keras.utils.image_dataset_from_directory(
    train_dir,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    label_mode='binary'
)

validation_dataset = tf.keras.utils.image_dataset_from_directory(
    validation_dir,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    label_mode='binary'
)

# Prefetch를 사용하여 성능 최적화
AUTOTUNE = tf.data.AUTOTUNE
train_dataset = train_dataset.cache().prefetch(buffer_size=AUTOTUNE)
validation_dataset = validation_dataset.cache().prefetch(buffer_size=AUTOTUNE)

# 모델 구성
model = models.Sequential([
    # 이미지 정규화 (0-255 -> 0-1)
    layers.Rescaling(1./255, input_shape=(IMG_SIZE[0], IMG_SIZE[1], 3)),
    
    # Convolutional layers
    layers.Conv2D(32, (3, 3), activation='relu'),
    layers.MaxPooling2D(2, 2),
    
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D(2, 2),
    
    layers.Conv2D(128, (3, 3), activation='relu'),
    layers.MaxPooling2D(2, 2),
    
    layers.Conv2D(128, (3, 3), activation='relu'),
    layers.MaxPooling2D(2, 2),
    
    # Flatten 및 Dense layers
    layers.Flatten(),
    layers.Dropout(0.5), # 과적합 방지
    layers.Dense(512, activation='relu'),
    layers.Dense(1, activation='sigmoid') # 개/고양이 이진 분류
])

# 모델 컴파일
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# 모델 요약 출력
model.summary()

# 모델 학습
print("\n모델 학습을 시작합니다...")
epochs = 10 # 시간 관계상 10회로 설정 (필요에 따라 늘릴 수 있습니다)
history = model.fit(
    train_dataset,
    epochs=epochs,
    validation_data=validation_dataset
)

# 모델 평가
print("\n모델 평가 중...")
loss, accuracy = model.evaluate(validation_dataset)
print(f"\n[평가 결과]")
print(f"손실(Loss): {loss:.4f}")
print(f"정확도(Accuracy): {accuracy:.4f}")

# 학습 과정 시각화 및 저장
acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss_list = history.history['loss']
val_loss_list = history.history['val_loss']

epochs_range = range(epochs)

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(epochs_range, acc, label='Training Accuracy')
plt.plot(epochs_range, val_acc, label='Validation Accuracy')
plt.legend(loc='lower right')
plt.title('Training and Validation Accuracy')

plt.subplot(1, 2, 2)
plt.plot(epochs_range, loss_list, label='Training Loss')
plt.plot(epochs_range, val_loss_list, label='Validation Loss')
plt.legend(loc='upper right')
plt.title('Training and Validation Loss')

# 결과 그래프 저장
plt.savefig('learning_results.png')
print("\n학습 결과 그래프가 'learning_results.png'로 저장되었습니다.")

