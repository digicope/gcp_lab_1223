import base64
from google.cloud import aiplatform

def predict_image_classification(
    project_id: str,
    endpoint_id: str,
    location: str = "us-central1",
):
    """
    Vertex AI 엔드포인트에 이미지 예측 요청을 보냅니다.
    """
    # 1. AI Platform 초기화
    aiplatform.init(project=project_id, location=location)

    # 2. 엔드포인트 객체 생성
    endpoint = aiplatform.Endpoint(endpoint_id)

    # 3. 예측할 이미지 데이터 준비
    # 실제 실행 환경에 있는 이미지 파일명으로 수정하여 사용하세요.
    image_path = "test_engine.jpg" 
    try:
        with open(image_path, "rb") as f:
            file_content = f.read()
    except FileNotFoundError:
        print(f"알림: '{image_path}' 파일이 없어 샘플 코드로만 확인하세요.")
        # 파일이 없을 경우 테스트를 위해 가상의 데이터를 넣을 수 있습니다.
        encoded_content = "base64_encoded_data_here"
    else:
        # base64 인코딩
        encoded_content = base64.b64encode(file_content).decode("utf-8")

    # 4. 입력 인스턴스 구성 (제공해주신 payload.json 구조 반영)
    instances = [
        {"content": encoded_content}
    ]

    # 5. 파라미터 설정
    parameters = {
        "confidenceThreshold": 0.5,
        "maxPredictions": 5
    }

    # 6. 예측 요청 실행
    print(f"프로젝트: {project_id}")
    print(f"엔드포인트: {endpoint_id} 로 예측 요청을 보냅니다...")
    
    try:
        response = endpoint.predict(instances=instances, parameters=parameters)
        
        # 7. 결과 출력
        print("\n--- 예측 결과 ---")
        for prediction in response.predictions:
            print(prediction)
    except Exception as e:
        print(f"예측 도중 오류 발생: {e}")

if __name__ == "__main__":
    # 사용자 제공 정보
    ENDPOINT_ID = "1983605837926498304"
    PROJECT_ID = "105186977018"
    LOCATION = "us-central1"

    predict_image_classification(
        project_id=PROJECT_ID,
        endpoint_id=ENDPOINT_ID,
        location=LOCATION
    )

