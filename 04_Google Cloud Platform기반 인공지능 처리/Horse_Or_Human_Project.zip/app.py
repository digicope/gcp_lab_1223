import streamlit as st
import tensorflow as tf
from PIL import Image
import numpy as np

# 앱 제목 설정
st.set_page_config(page_title="말 vs 사람 분류기", page_icon="🐎")
st.title("🐎 말 vs 🚶 사람 분류기")
st.write("이미지를 업로드하면 인공지능이 말인지 사람인지 판별합니다.")

# 모델 로드 (캐싱을 통해 속도 향상)
@st.cache_resource
def load_model():
    model = tf.keras.models.load_model('horse_or_human_model.keras')
    return model

try:
    model = load_model()
except Exception as e:
    st.error(f"모델을 불러오는 중 오류가 발생했습니다: {e}")
    st.info("먼저 'python train.py'를 실행하여 모델을 생성해주세요.")
    st.stop()

# 파일 업로더
uploaded_file = st.file_uploader("이미지를 선택하세요...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # 이미지 표시
    image = Image.open(uploaded_file)
    st.image(image, caption='업로드된 이미지', use_column_width=True)
    
    # 예측 버튼
    if st.button('분류하기'):
        with st.spinner('분석 중...'):
            # 이미지 전처리
            img = image.convert('RGB')
            img = img.resize((150, 150))
            img_array = np.array(img)
            img_array = np.expand_dims(img_array, axis=0)
            # img_array = img_array / 255.0  # 모델 내부 Rescaling 레이어와 중복되므로 주석 처리 또는 제거
            
            # 예측 수행
            prediction = model.predict(img_array)
            
            # 결과 표시
            # 학습 시 label_mode='binary'로 설정했으며, 
            # tf.keras.utils.image_dataset_from_directory는 알파벳 순서로 라벨링함 (horses=0, humans=1)
            if prediction[0][0] > 0.5:
                st.success(f"분석 결과: **사람(Human)**입니다! (확률: {prediction[0][0]*100:.2f}%)")
            else:
                st.success(f"분석 결과: **말(Horse)**입니다! (확률: {(1-prediction[0][0])*100:.2f}%)")
                
# 실행 방법 안내
st.sidebar.markdown("""
### 사용 방법
1. 이미지를 업로드합니다.
2. '분류하기' 버튼을 누릅니다.
3. 인공지능의 판별 결과를 확인합니다.
""")

