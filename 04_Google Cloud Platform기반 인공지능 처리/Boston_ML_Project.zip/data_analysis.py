import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 한글 폰트 설정 (Windows 기준 - 설치된 폰트에 따라 변경될 수 있음)
plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False

# 1. 데이터 로드
print("데이터를 로드하는 중...")
df = pd.read_csv('boston_train.csv')

# 2. 데이터 기본 정보 출력
print("\n--- 데이터 기본 정보 ---")
print(df.info())
print("\n--- 통계 요약 ---")
print(df.describe())

# 3. 데이터 시각화
plt.figure(figsize=(20, 15))

# (1) 주택 가격(MEDV) 분포 (Histogram & KDE)
plt.subplot(2, 2, 1)
sns.histplot(df['MEDV'], kde=True, color='blue')
plt.title('주택 가격(MEDV) 분포')
plt.xlabel('가격 ($1000s)')
plt.ylabel('빈도')

# (2) 변수 간 상관관계 히트맵 (Correlation Heatmap)
plt.subplot(2, 2, 2)
correlation_matrix = df.corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('변수 간 상관관계 히트맵')

# (3) 방의 개수(RM)와 주택 가격(MEDV)의 관계 (Scatter Plot)
plt.subplot(2, 2, 3)
sns.regplot(x='RM', y='MEDV', data=df, scatter_kws={'alpha':0.5}, line_kws={'color':'red'})
plt.title('방의 개수(RM) vs 주택 가격(MEDV)')
plt.xlabel('평균 방 개수')
plt.ylabel('주택 가격 ($1000s)')

# (4) 하위 계층 비율(LSTAT 대신 CRIM 사용 - 원본 데이터에 CRIM 등이 있으므로 주요 변수 확인)
# CRIM(범죄율)과 주택 가격의 관계
plt.subplot(2, 2, 4)
sns.scatterplot(x='CRIM', y='MEDV', data=df, alpha=0.5)
plt.title('범죄율(CRIM) vs 주택 가격(MEDV)')
plt.xlabel('범죄율')
plt.ylabel('주택 가격 ($1000s)')

plt.tight_layout()
output_file = 'boston_analysis.png'
plt.savefig(output_file)
print(f"\n시각화 결과가 '{output_file}' 파일로 저장되었습니다.")
plt.show()

# 4. 주요 특징별 평균 가격 확인 (예: ZN 25 기준)
print("\n--- 주거 지역 비율(ZN)에 따른 평균 가격 ---")
zn_bins = pd.cut(df['ZN'], bins=[-1, 0, 100], labels=['0%', '0% 초과'])
print(df.groupby(zn_bins, observed=False)['MEDV'].mean())

