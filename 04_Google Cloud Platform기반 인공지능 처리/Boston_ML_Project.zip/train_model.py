import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

# 1. 데이터 로드
print("데이터를 로드하는 중...")
train_df = pd.read_csv('boston_train.csv')

# 2. 특징(Features)과 타겟(Target) 분리
X = train_df.drop('MEDV', axis=1)
y = train_df['MEDV']

# 3. 학습 데이터와 검증 데이터로 분할 (8:2 비율)
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. 모델 생성 및 학습
print("\n--- 선형 회귀 모델 학습 중 ---")
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

print("--- 랜덤 포레스트 모델 학습 중 ---")
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# 5. 모델 평가 함수
def evaluate_model(model, X, y, name):
    y_pred = model.predict(X)
    mse = mean_squared_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)
    print(f"\n[{name} 평가 결과]")
    print(f"MSE: {mse:.4f}")
    print(f"RMSE: {rmse:.4f}")
    print(f"R2 Score: {r2:.4f}")
    return r2

# 검증 데이터 평가
print("\n" + "="*40)
print("검증 데이터셋 평가")
print("="*40)
lr_val_r2 = evaluate_model(lr_model, X_val, y_val, "Linear Regression (Val)")
rf_val_r2 = evaluate_model(rf_model, X_val, y_val, "Random Forest (Val)")

# 6. 테스트 데이터(boston_test.csv)를 사용한 최종 평가
print("\n" + "="*40)
print("최종 테스트 데이터셋 평가 (boston_test.csv)")
print("="*40)

test_df = pd.read_csv('boston_test.csv')
X_test = test_df.drop('MEDV', axis=1)
y_test = test_df['MEDV']

lr_test_r2 = evaluate_model(lr_model, X_test, y_test, "Linear Regression (Test)")
rf_test_r2 = evaluate_model(rf_model, X_test, y_test, "Random Forest (Test)")

# 성능 개선 확인
improvement = rf_test_r2 - lr_test_r2
print(f"\n성능 개선 정도 (R2 Score 차이): {improvement:.4f}")

# 예측 결과 샘플 비교
y_test_pred_rf = rf_model.predict(X_test)
comparison_df = pd.DataFrame({
    '실제값': y_test, 
    '선형회귀 예측': lr_model.predict(X_test),
    '랜덤포레스트 예측': y_test_pred_rf
})
print("\n테스트 데이터 예측 비교 샘플 (처음 5개):")
print(comparison_df.head())
