import os
from fastapi import FastAPI, UploadFile, File, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import shutil
from pypdf import PdfReader
from google import genai
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# Gemini API 설정
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY)

app = FastAPI()

# 디렉토리 설정
UPLOAD_DIR = "uploads"
PROCESSED_DIR = "processed"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)

# 템플릿 설정
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # 업로드된 파일 목록 가져오기
    files = os.listdir(UPLOAD_DIR)
    pdf_files = [f for f in files if f.lower().endswith('.pdf')]
    return templates.TemplateResponse("index.html", {"request": request, "files": pdf_files})

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return JSONResponse(content={"filename": file.filename, "message": "파일 업로드 성공"})

@app.post("/process")
async def process_pdf(filename: str = Form(...)):
    file_path = os.path.join(UPLOAD_DIR, filename)
    
    if not os.path.exists(file_path):
        return JSONResponse(content={"error": "파일을 찾을 수 없습니다."}, status_code=404)

    try:
        # 1. 텍스트 추출
        reader = PdfReader(file_path)
        extracted_text = ""
        for page in reader.pages:
            extracted_text += page.extract_text() + "\n"

        # 추출된 텍스트 저장
        text_filename = f"{os.path.splitext(filename)[0]}_extracted.txt"
        text_path = os.path.join(PROCESSED_DIR, text_filename)
        with open(text_path, "w", encoding="utf-8") as f:
            f.write(extracted_text)

        # 2. Gemini를 이용한 요약
        # Gemini 2.5 Flash 모델 사용 (사용자 요청에 따라 최신 2.x 시리즈 적용)
        prompt = f"다음 텍스트를 핵심 내용을 중심으로 한국어로 요약해줘:\n\n{extracted_text[:30000]}"
        
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt
        )
        summary_text = response.text

        # 요약된 텍스트 저장
        summary_filename = f"{os.path.splitext(filename)[0]}_summary.txt"
        summary_path = os.path.join(PROCESSED_DIR, summary_filename)
        with open(summary_path, "w", encoding="utf-8") as f:
            f.write(summary_text)

        return JSONResponse(content={
            "message": "처리 완료",
            "extracted_text_file": text_filename,
            "summary_file": summary_filename,
            "summary": summary_text
        })

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

