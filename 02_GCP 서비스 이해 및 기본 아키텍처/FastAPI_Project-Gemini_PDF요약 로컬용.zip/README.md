# PDF 텍스트 추출 및 AI 요약 웹 애플리케이션

이 프로젝트는 FastAPI를 기반으로 PDF 파일을 업로드하고, 최신 Gemini AI(2.5-flash) 모델을 사용하여 텍스트 추출 및 요약을 수행하는 웹 애플리케이션입니다.

## 주요 기능

1.  **PDF 업로드**: 웹 페이지를 통해 PDF 파일을 서버의 로컬 저장소(`uploads/`)에 업로드합니다.
2.  **파일 목록 보기**: 업로드된 PDF 파일 목록을 메인 페이지에서 바로 확인할 수 있습니다.
3.  **텍스트 추출**: `pypdf` 라이브러리를 사용하여 PDF 내의 텍스트를 자동으로 추출하고 파일(`processed/`)로 저장합니다.
4.  **AI 요약**: 추출된 텍스트를 Google Gemini 2.5 Flash 모델에 전달하여 핵심 내용을 한국어로 요약합니다.
5.  **결과 저장**: 요약된 내용을 텍스트 파일(`processed/`)로 저장하며, 웹 페이지에서 즉시 결과를 확인할 수 있습니다.

## 설치 및 환경 설정

### 1. 사전 요구 사항
*   Python 3.10 이상
*   Google Gemini API Key ([Google AI Studio](https://aistudio.google.com/)에서 발급 가능)

### 2. 라이브러리 설치
터미널에서 아래 명령어를 입력하여 필요한 패키지를 설치합니다.
```bash
pip install -r requirements.txt
```

### 3. 환경 변수 설정
프로젝트 루트 폴더에 `.env` 파일을 생성하고 발급받은 API 키를 입력합니다.
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

## 실행 방법

서버를 실행하려면 터미널에서 다음 명령어를 입력하세요.
```bash
python main.py
```
서버 실행 후 브라우저에서 **`http://127.0.0.1:8000`**에 접속합니다.

## 사용 방법

1.  **PDF 업로드**: 메인 페이지의 '파일 선택' 버튼을 눌러 PDF 파일을 선택하고 '업로드' 버튼을 클릭합니다.
2.  **목록 확인**: 업로드된 파일이 하단 '저장된 PDF 목록'에 나타납니다.
3.  **요약 시작**: 목록 옆의 **[텍스트 추출 및 요약]** 버튼을 클릭합니다.
4.  **결과 확인**: 처리가 완료되면 하단에 AI가 생성한 요약 내용이 표시되며, 추출 및 요약 텍스트 파일은 `processed` 폴더 내에 자동으로 생성됩니다.

## 프로젝트 구조

*   `main.py`: FastAPI 백엔드 로직 (업로드, 추출, API 호출 등)
*   `templates/index.html`: 프론트엔드 UI (Tailwind CSS 사용)
*   `uploads/`: 업로드된 원본 PDF 파일 저장소
*   `processed/`: 추출된 텍스트 및 AI 요약본 저장소
*   `.env`: API 키 등 보안 설정 파일
*   `requirements.txt`: 의존성 라이브러리 목록

## 기술 스택
*   **Backend**: FastAPI, Uvicorn
*   **AI Model**: Google Gemini 2.5 Flash (via `google-genai` SDK)
*   **PDF Library**: pypdf
*   **Frontend**: HTML5, Tailwind CSS, JavaScript (Fetch API)

