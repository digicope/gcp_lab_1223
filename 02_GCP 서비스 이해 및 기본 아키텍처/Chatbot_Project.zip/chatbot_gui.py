import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import os
import sqlite3
from datetime import datetime
from openai import OpenAI
from openai import APIError, RateLimitError, APITimeoutError, APIConnectionError
from dotenv import load_dotenv
import threading

class ChatbotGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI 챗봇")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # 색상 및 폰트 설정
        self.setup_theme()
        
        # 대화 히스토리 저장
        self.conversation_history = []
        self.temperature = 0.7  # 기본값
        
        # 데이터베이스 초기화
        self.initialize_database()
        
        # GUI 구성 먼저
        self.setup_ui()
        
        # OpenAI 클라이언트 초기화
        self.initialize_openai()
    
    def setup_theme(self):
        """테마 및 색상 설정"""
        # 색상 팔레트
        self.colors = {
            'bg_primary': '#f8f9fa',      # 메인 배경색
            'bg_secondary': '#ffffff',    # 카드/프레임 배경색
            'bg_chat': '#ffffff',         # 채팅 영역 배경색
            'text_primary': '#2c3e50',    # 주요 텍스트 색상
            'text_secondary': '#6c757d',  # 보조 텍스트 색상
            'accent_blue': '#007bff',     # 사용자 메시지 색상
            'accent_green': '#28a745',    # 봇 메시지 색상
            'accent_orange': '#fd7e14',   # 시스템 메시지 색상
            'border': '#dee2e6',          # 테두리 색상
            'button_bg': '#007bff',       # 버튼 배경색
            'button_hover': '#0056b3'     # 버튼 호버 색상
        }
        
        # 폰트 설정
        self.fonts = {
            'title': ('Segoe UI', 18, 'bold'),
            'subtitle': ('Segoe UI', 12, 'bold'),
            'body': ('Segoe UI', 11),
            'chat': ('Segoe UI', 10),
            'small': ('Segoe UI', 9)
        }
        
        # 루트 윈도우 배경색 설정
        self.root.configure(bg=self.colors['bg_primary'])
    
    def initialize_database(self):
        """데이터베이스 초기화"""
        try:
            import os
            self.db_path = os.path.join(os.getcwd(), "chatbot_history.db")
            print(f"데이터베이스 경로: {self.db_path}")
            
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            
            # 대화 히스토리 테이블 생성
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    user_message TEXT NOT NULL,
                    bot_response TEXT NOT NULL,
                    temperature REAL NOT NULL
                )
            ''')
            
            self.conn.commit()
            print("데이터베이스가 성공적으로 초기화되었습니다.")
            
            # 테이블이 제대로 생성되었는지 확인
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='conversations'")
            if self.cursor.fetchone():
                print("conversations 테이블이 성공적으로 생성되었습니다.")
            else:
                print("conversations 테이블 생성에 실패했습니다.")
            
        except Exception as e:
            print(f"데이터베이스 초기화 오류: {str(e)}")
            import traceback
            traceback.print_exc()
            messagebox.showerror("오류", f"데이터베이스 초기화 실패: {str(e)}")
    
    def save_conversation(self, user_message, bot_response, temperature):
        """대화 내용을 데이터베이스에 저장"""
        try:
            if not hasattr(self, 'conn') or not self.conn:
                print("데이터베이스 연결이 없습니다. 재초기화를 시도합니다.")
                self.initialize_database()
                return
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute('''
                INSERT INTO conversations (timestamp, user_message, bot_response, temperature)
                VALUES (?, ?, ?, ?)
            ''', (timestamp, user_message, bot_response, temperature))
            self.conn.commit()
            print(f"대화 저장 완료: {timestamp} - {user_message[:50]}...")
            
            # 저장 확인
            self.cursor.execute("SELECT COUNT(*) FROM conversations")
            count = self.cursor.fetchone()[0]
            print(f"현재 저장된 대화 수: {count}")
            
        except Exception as e:
            print(f"대화 저장 오류: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def save_conversation_safe(self, user_message, bot_response, temperature):
        """스레드 안전한 대화 저장 (메인 스레드에서 호출)"""
        try:
            print(f"스레드 안전 저장 시작: {user_message[:50]}...")
            
            # 데이터베이스 연결 확인 및 재초기화
            if not hasattr(self, 'conn') or not self.conn:
                print("데이터베이스 연결이 없습니다. 재초기화를 시도합니다.")
                self.initialize_database()
            
            # 새로운 연결 생성 (스레드 안전성)
            import sqlite3
            temp_conn = sqlite3.connect(self.db_path)
            temp_cursor = temp_conn.cursor()
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            temp_cursor.execute('''
                INSERT INTO conversations (timestamp, user_message, bot_response, temperature)
                VALUES (?, ?, ?, ?)
            ''', (timestamp, user_message, bot_response, temperature))
            temp_conn.commit()
            
            # 저장 확인
            temp_cursor.execute("SELECT COUNT(*) FROM conversations")
            count = temp_cursor.fetchone()[0]
            print(f"스레드 안전 저장 완료: {timestamp} - {user_message[:50]}... (총 {count}개)")
            
            temp_conn.close()
            
        except Exception as e:
            print(f"스레드 안전 저장 오류: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def get_conversation_history(self):
        """저장된 대화 히스토리 가져오기"""
        try:
            if not hasattr(self, 'conn') or not self.conn:
                print("데이터베이스 연결이 없습니다.")
                return []
            
            self.cursor.execute('''
                SELECT id, timestamp, user_message, bot_response, temperature
                FROM conversations
                ORDER BY timestamp DESC
            ''')
            results = self.cursor.fetchall()
            print(f"히스토리 조회 완료: {len(results)}개 대화 발견")
            
            # 결과 상세 출력
            for i, result in enumerate(results[:3]):  # 처음 3개만 출력
                print(f"  {i+1}. {result[1]} - {result[2][:30]}...")
            
            return results
        except Exception as e:
            print(f"히스토리 조회 오류: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
        
    def initialize_openai(self):
        """OpenAI 클라이언트 초기화"""
        try:
            # .env 파일 로드
            load_dotenv()
            
            # API 키 확인
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                messagebox.showerror("오류", "OPENAI_API_KEY가 설정되지 않았습니다.\n.env 파일에 OPENAI_API_KEY를 설정해주세요.")
                self.root.quit()
                return
            
            # OpenAI 클라이언트 생성
            self.client = OpenAI(api_key=api_key)
            
            # 초기화 성공 메시지 (UI 설정 완료 후에 추가)
            self.root.after(100, lambda: self.add_message("시스템", "OpenAI 클라이언트가 성공적으로 초기화되었습니다.", "system"))
            self.root.after(200, lambda: self.add_message("시스템", "안녕하세요! AI 챗봇입니다. 무엇을 도와드릴까요?", "system"))
            
        except Exception as e:
            messagebox.showerror("오류", f"OpenAI 클라이언트 초기화 실패: {str(e)}")
            self.root.quit()
    
    def setup_ui(self):
        """GUI 구성"""
        # 메인 프레임
        main_frame = tk.Frame(self.root, bg=self.colors['bg_primary'], padx=20, pady=20)
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 그리드 가중치 설정
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # 제목
        title_label = tk.Label(
            main_frame, 
            text="🤖 AI 챗봇", 
            font=self.fonts['title'],
            fg=self.colors['text_primary'],
            bg=self.colors['bg_primary']
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15))
        
        # Temperature 모드 선택 프레임
        mode_frame = tk.LabelFrame(
            main_frame, 
            text="응답 모드", 
            font=self.fonts['subtitle'],
            fg=self.colors['text_primary'],
            bg=self.colors['bg_secondary'],
            relief=tk.RAISED,
            bd=1,
            padx=10,
            pady=10
        )
        mode_frame.grid(row=0, column=3, rowspan=2, padx=(15, 0), sticky=(tk.N, tk.S))
        
        self.temperature_var = tk.StringVar(value="0.7")
        
        # 라디오 버튼 스타일링
        radio_style = {
            'font': self.fonts['body'],
            'fg': self.colors['text_primary'],
            'bg': self.colors['bg_secondary'],
            'selectcolor': self.colors['accent_blue'],
            'activebackground': self.colors['bg_secondary']
        }
        
        ttk.Radiobutton(mode_frame, text="정확한 모드 (0.2)", 
                       variable=self.temperature_var, value="0.2").pack(anchor=tk.W, pady=2)
        ttk.Radiobutton(mode_frame, text="창의적 모드 (1.0)", 
                       variable=self.temperature_var, value="1.0").pack(anchor=tk.W, pady=2)
        
        # 채팅 영역
        chat_frame = tk.LabelFrame(
            main_frame, 
            text="💬 대화", 
            font=self.fonts['subtitle'],
            fg=self.colors['text_primary'],
            bg=self.colors['bg_secondary'],
            relief=tk.RAISED,
            bd=1,
            padx=10,
            pady=10
        )
        chat_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 15))
        chat_frame.columnconfigure(0, weight=1)
        chat_frame.rowconfigure(0, weight=1)
        
        # 스크롤 가능한 텍스트 위젯
        self.chat_display = scrolledtext.ScrolledText(
            chat_frame, 
            wrap=tk.WORD, 
            width=70, 
            height=25,
            state=tk.DISABLED,
            font=self.fonts['chat'],
            bg=self.colors['bg_chat'],
            fg=self.colors['text_primary'],
            relief=tk.FLAT,
            bd=0,
            padx=10,
            pady=10,
            selectbackground=self.colors['accent_blue'],
            selectforeground='white'
        )
        self.chat_display.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 입력 프레임
        input_frame = tk.Frame(main_frame, bg=self.colors['bg_primary'])
        input_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 15))
        input_frame.columnconfigure(0, weight=1)
        
        # 입력 필드
        self.input_entry = tk.Entry(
            input_frame, 
            font=self.fonts['body'],
            bg=self.colors['bg_secondary'],
            fg=self.colors['text_primary'],
            relief=tk.FLAT,
            bd=1,
            insertbackground=self.colors['text_primary']
        )
        self.input_entry.grid(row=0, column=0, sticky=(tk.W, tk.E), padx=(0, 10), ipady=8)
        self.input_entry.bind("<Return>", self.send_message)
        
        # 전송 버튼
        self.send_button = tk.Button(
            input_frame, 
            text="📤 전송", 
            command=self.send_message,
            font=self.fonts['body'],
            bg=self.colors['button_bg'],
            fg='white',
            relief=tk.FLAT,
            bd=0,
            padx=20,
            pady=8,
            cursor='hand2'
        )
        self.send_button.grid(row=0, column=1, padx=(0, 5))
        
        # 히스토리 버튼
        self.history_button = tk.Button(
            input_frame, 
            text="📚 History", 
            command=self.show_history,
            font=self.fonts['body'],
            bg=self.colors['accent_green'],
            fg='white',
            relief=tk.FLAT,
            bd=0,
            padx=15,
            pady=8,
            cursor='hand2'
        )
        self.history_button.grid(row=0, column=2)
        
        # 상태 표시
        self.status_label = tk.Label(
            main_frame, 
            text="✅ 준비됨", 
            font=self.fonts['small'],
            fg=self.colors['text_secondary'],
            bg=self.colors['bg_primary'],
            relief=tk.FLAT,
            anchor=tk.W
        )
        self.status_label.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(5, 0))
        
        # 포커스 설정
        self.input_entry.focus()
    
    def add_message(self, sender, message, msg_type="user"):
        """채팅 영역에 메시지 추가"""
        self.chat_display.config(state=tk.NORMAL)
        
        # 메시지 타입에 따른 아이콘과 색상 설정
        if msg_type == "user":
            self.chat_display.insert(tk.END, f"👤 You: ", "user_label")
            self.chat_display.insert(tk.END, f"{message}\n\n", "user")
        elif msg_type == "bot":
            self.chat_display.insert(tk.END, f"🤖 Bot: ", "bot_label")
            self.chat_display.insert(tk.END, f"{message}\n\n", "bot")
        elif msg_type == "system":
            self.chat_display.insert(tk.END, f"⚙️ System: ", "system_label")
            self.chat_display.insert(tk.END, f"{message}\n\n", "system")
        
        # 스크롤을 맨 아래로
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)
    
    def update_status(self, message):
        """상태 표시 업데이트"""
        # 상태에 따른 이모지 추가
        if "응답 생성" in message:
            self.status_label.config(text=f"⏳ {message}")
        elif "준비됨" in message:
            self.status_label.config(text=f"✅ {message}")
        elif "오류" in message:
            self.status_label.config(text=f"❌ {message}")
        else:
            self.status_label.config(text=f"ℹ️ {message}")
        self.root.update_idletasks()
    
    def send_message(self, event=None):
        """메시지 전송"""
        user_input = self.input_entry.get().strip()
        if not user_input:
            return
        
        print(f"사용자 메시지 전송: {user_input}")
        
        # 입력 필드 초기화
        self.input_entry.delete(0, tk.END)
        
        # 사용자 메시지 표시
        self.add_message("You", user_input, "user")
        
        # 전송 버튼 비활성화
        self.send_button.config(state=tk.DISABLED)
        self.input_entry.config(state=tk.DISABLED)
        
        # 상태 업데이트
        self.update_status("응답 생성 중...")
        
        # 별도 스레드에서 API 호출
        thread = threading.Thread(target=self.get_bot_response, args=(user_input,))
        thread.daemon = True
        thread.start()
    
    def get_bot_response(self, user_input):
        """봇 응답 가져오기 (별도 스레드에서 실행)"""
        print(f"봇 응답 요청 시작: {user_input[:50]}...")
        
        try:
            # 선택된 temperature 값 가져오기
            self.temperature = float(self.temperature_var.get())
            print(f"Temperature 설정: {self.temperature}")
            
            # API 호출
            print("OpenAI API 호출 중...")
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=self.conversation_history + [{"role": "user", "content": user_input}],
                max_tokens=1000,
                temperature=self.temperature
            )
            
            bot_response = response.choices[0].message.content
            print(f"봇 응답 받음: {bot_response[:50]}...")
            
            # 대화 히스토리에 추가
            self.conversation_history.append({"role": "user", "content": user_input})
            self.conversation_history.append({"role": "assistant", "content": bot_response})
            
            # 메인 스레드에서 데이터베이스 저장 (스레드 안전성)
            print("메인 스레드에서 데이터베이스 저장 요청...")
            self.root.after(0, self.save_conversation_safe, user_input, bot_response, self.temperature)
            
            # 히스토리 길이 제한 (최근 20개 메시지)
            if len(self.conversation_history) > 20:
                self.conversation_history = self.conversation_history[-20:]
            
            # UI 업데이트 (메인 스레드에서)
            self.root.after(0, self.display_bot_response, bot_response)
            
        except RateLimitError as e:
            error_msg = "API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."
            print(f"RateLimitError: {str(e)}")
            # 사용자 메시지는 저장 (스레드 안전)
            self.root.after(0, self.save_conversation_safe, user_input, error_msg, self.temperature)
            self.root.after(0, self.display_error, error_msg)
            
        except APITimeoutError as e:
            error_msg = "API 요청 시간이 초과되었습니다. 네트워크 연결을 확인하고 다시 시도해주세요."
            print(f"APITimeoutError: {str(e)}")
            # 사용자 메시지는 저장 (스레드 안전)
            self.root.after(0, self.save_conversation_safe, user_input, error_msg, self.temperature)
            self.root.after(0, self.display_error, error_msg)
            
        except APIConnectionError as e:
            error_msg = "API 서버에 연결할 수 없습니다. 인터넷 연결을 확인해주세요."
            print(f"APIConnectionError: {str(e)}")
            # 사용자 메시지는 저장 (스레드 안전)
            self.root.after(0, self.save_conversation_safe, user_input, error_msg, self.temperature)
            self.root.after(0, self.display_error, error_msg)
            
        except APIError as e:
            error_msg = f"OpenAI API 오류가 발생했습니다: {str(e)}"
            print(f"APIError: {str(e)}")
            # 사용자 메시지는 저장 (스레드 안전)
            self.root.after(0, self.save_conversation_safe, user_input, error_msg, self.temperature)
            self.root.after(0, self.display_error, error_msg)
            
        except Exception as e:
            error_msg = f"예상치 못한 오류가 발생했습니다: {str(e)}"
            print(f"Unexpected Error: {str(e)}")
            import traceback
            traceback.print_exc()
            # 사용자 메시지는 저장 (스레드 안전)
            self.root.after(0, self.save_conversation_safe, user_input, error_msg, self.temperature)
            self.root.after(0, self.display_error, error_msg)
    
    def display_bot_response(self, response):
        """봇 응답 표시"""
        self.add_message("Bot", response, "bot")
        self.update_status("준비됨")
        self.enable_input()
    
    def display_error(self, error_msg):
        """오류 메시지 표시"""
        self.add_message("System", error_msg, "system")
        self.update_status("오류 발생")
        self.enable_input()
    
    def enable_input(self):
        """입력 필드 활성화"""
        self.send_button.config(state=tk.NORMAL)
        self.input_entry.config(state=tk.NORMAL)
        self.input_entry.focus()
    
    def show_history(self):
        """히스토리 창 표시"""
        print("히스토리 창을 열고 있습니다...")
        
        history_window = tk.Toplevel(self.root)
        history_window.title("📚 대화 히스토리")
        history_window.geometry("800x600")
        history_window.configure(bg=self.colors['bg_primary'])
        
        # 메인 프레임
        main_frame = tk.Frame(history_window, bg=self.colors['bg_primary'], padx=20, pady=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 제목과 테스트 버튼 프레임
        title_frame = tk.Frame(main_frame, bg=self.colors['bg_primary'])
        title_frame.pack(fill=tk.X, pady=(0, 15))
        
        title_label = tk.Label(
            title_frame,
            text="📚 대화 히스토리",
            font=self.fonts['title'],
            fg=self.colors['text_primary'],
            bg=self.colors['bg_primary']
        )
        title_label.pack(side=tk.LEFT)
        
        # 버튼 프레임
        button_frame = tk.Frame(title_frame, bg=self.colors['bg_primary'])
        button_frame.pack(side=tk.RIGHT)
        
        # 새로고침 버튼
        refresh_button = tk.Button(
            button_frame,
            text="🔄 새로고침",
            command=lambda: self.refresh_history_window(history_window, canvas, scrollable_frame, configure_scroll_region),
            font=self.fonts['small'],
            bg=self.colors['accent_blue'],
            fg='white',
            relief=tk.FLAT,
            bd=0,
            padx=10,
            pady=5,
            cursor='hand2'
        )
        refresh_button.pack(side=tk.RIGHT, padx=(0, 5))
        
        # 테스트 버튼
        test_button = tk.Button(
            button_frame,
            text="🧪 테스트 데이터 추가",
            command=self.add_test_conversation,
            font=self.fonts['small'],
            bg=self.colors['accent_orange'],
            fg='white',
            relief=tk.FLAT,
            bd=0,
            padx=10,
            pady=5,
            cursor='hand2'
        )
        test_button.pack(side=tk.RIGHT)
        
        # 스크롤 가능한 프레임
        canvas = tk.Canvas(main_frame, bg=self.colors['bg_primary'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.colors['bg_primary'])
        
        def configure_scroll_region(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        scrollable_frame.bind("<Configure>", configure_scroll_region)
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # 히스토리 데이터 가져오기
        print("히스토리 데이터를 조회하고 있습니다...")
        conversations = self.get_conversation_history()
        print(f"조회된 대화 수: {len(conversations)}")
        
        if not conversations:
            no_data_label = tk.Label(
                scrollable_frame,
                text="저장된 대화가 없습니다.",
                font=self.fonts['body'],
                fg=self.colors['text_secondary'],
                bg=self.colors['bg_primary']
            )
            no_data_label.pack(pady=20)
        else:
            for i, (conv_id, timestamp, user_msg, bot_msg, temp) in enumerate(conversations):
                # 대화 카드 프레임
                card_frame = tk.Frame(
                    scrollable_frame,
                    bg=self.colors['bg_secondary'],
                    relief=tk.RAISED,
                    bd=1,
                    padx=15,
                    pady=10
                )
                card_frame.pack(fill=tk.X, pady=5, padx=5)
                
                # 타임스탬프와 온도 정보
                info_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                info_frame.pack(fill=tk.X, pady=(0, 8))
                
                timestamp_label = tk.Label(
                    info_frame,
                    text=f"🕒 {timestamp}",
                    font=self.fonts['small'],
                    fg=self.colors['text_secondary'],
                    bg=self.colors['bg_secondary']
                )
                timestamp_label.pack(side=tk.LEFT)
                
                temp_label = tk.Label(
                    info_frame,
                    text=f"🌡️ Temperature: {temp}",
                    font=self.fonts['small'],
                    fg=self.colors['text_secondary'],
                    bg=self.colors['bg_secondary']
                )
                temp_label.pack(side=tk.RIGHT)
                
                # 사용자 메시지
                user_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                user_frame.pack(fill=tk.X, pady=(0, 5))
                
                user_label = tk.Label(
                    user_frame,
                    text="👤 You:",
                    font=('Segoe UI', 9, 'bold'),
                    fg=self.colors['accent_blue'],
                    bg=self.colors['bg_secondary']
                )
                user_label.pack(anchor=tk.W)
                
                # 사용자 메시지를 텍스트 위젯으로 변경 (긴 텍스트 처리)
                user_text = tk.Text(
                    user_frame,
                    height=3,
                    font=self.fonts['small'],
                    fg=self.colors['text_primary'],
                    bg=self.colors['bg_secondary'],
                    wrap=tk.WORD,
                    relief=tk.FLAT,
                    bd=0,
                    padx=5,
                    pady=2
                )
                user_text.insert(tk.END, user_msg)
                user_text.config(state=tk.DISABLED)
                user_text.pack(anchor=tk.W, padx=(20, 0), fill=tk.X)
                
                # 봇 응답
                bot_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                bot_frame.pack(fill=tk.X, pady=(5, 0))
                
                bot_label = tk.Label(
                    bot_frame,
                    text="🤖 Bot:",
                    font=('Segoe UI', 9, 'bold'),
                    fg=self.colors['accent_green'],
                    bg=self.colors['bg_secondary']
                )
                bot_label.pack(anchor=tk.W)
                
                # 봇 응답을 텍스트 위젯으로 변경 (긴 텍스트 처리)
                bot_text = tk.Text(
                    bot_frame,
                    height=4,
                    font=self.fonts['small'],
                    fg=self.colors['text_primary'],
                    bg=self.colors['bg_secondary'],
                    wrap=tk.WORD,
                    relief=tk.FLAT,
                    bd=0,
                    padx=5,
                    pady=2
                )
                bot_text.insert(tk.END, bot_msg)
                bot_text.config(state=tk.DISABLED)
                bot_text.pack(anchor=tk.W, padx=(20, 0), fill=tk.X)
        
        # 스크롤 영역 업데이트
        history_window.update_idletasks()
        configure_scroll_region()
        
        # 캔버스와 스크롤바 배치
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # 마우스 휠 바인딩
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        # 창 닫을 때 바인딩 해제
        def on_closing():
            canvas.unbind_all("<MouseWheel>")
            history_window.destroy()
        
        history_window.protocol("WM_DELETE_WINDOW", on_closing)
    
    def add_test_conversation(self):
        """테스트용 대화 데이터 추가"""
        try:
            test_user_msg = "안녕하세요! 테스트 메시지입니다."
            test_bot_msg = "안녕하세요! AI 챗봇입니다. 테스트 응답입니다."
            test_temp = 0.7
            
            self.save_conversation_safe(test_user_msg, test_bot_msg, test_temp)
            print("테스트 대화가 추가되었습니다.")
            
        except Exception as e:
            print(f"테스트 대화 추가 오류: {str(e)}")
    
    def refresh_history_window(self, history_window, canvas, scrollable_frame, configure_scroll_region):
        """히스토리 창 새로고침"""
        try:
            print("히스토리 창을 새로고침합니다...")
            
            # 기존 위젯들 제거
            for widget in scrollable_frame.winfo_children():
                widget.destroy()
            
            # 히스토리 데이터 다시 가져오기
            conversations = self.get_conversation_history()
            print(f"새로고침된 대화 수: {len(conversations)}")
            
            if not conversations:
                no_data_label = tk.Label(
                    scrollable_frame,
                    text="저장된 대화가 없습니다.",
                    font=self.fonts['body'],
                    fg=self.colors['text_secondary'],
                    bg=self.colors['bg_primary']
                )
                no_data_label.pack(pady=20)
            else:
                for i, (conv_id, timestamp, user_msg, bot_msg, temp) in enumerate(conversations):
                    # 대화 카드 프레임
                    card_frame = tk.Frame(
                        scrollable_frame,
                        bg=self.colors['bg_secondary'],
                        relief=tk.RAISED,
                        bd=1,
                        padx=15,
                        pady=10
                    )
                    card_frame.pack(fill=tk.X, pady=5, padx=5)
                    
                    # 타임스탬프와 온도 정보
                    info_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                    info_frame.pack(fill=tk.X, pady=(0, 8))
                    
                    timestamp_label = tk.Label(
                        info_frame,
                        text=f"🕒 {timestamp}",
                        font=self.fonts['small'],
                        fg=self.colors['text_secondary'],
                        bg=self.colors['bg_secondary']
                    )
                    timestamp_label.pack(side=tk.LEFT)
                    
                    temp_label = tk.Label(
                        info_frame,
                        text=f"🌡️ Temperature: {temp}",
                        font=self.fonts['small'],
                        fg=self.colors['text_secondary'],
                        bg=self.colors['bg_secondary']
                    )
                    temp_label.pack(side=tk.RIGHT)
                    
                    # 사용자 메시지
                    user_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                    user_frame.pack(fill=tk.X, pady=(0, 5))
                    
                    user_label = tk.Label(
                        user_frame,
                        text="👤 You:",
                        font=('Segoe UI', 9, 'bold'),
                        fg=self.colors['accent_blue'],
                        bg=self.colors['bg_secondary']
                    )
                    user_label.pack(anchor=tk.W)
                    
                    # 사용자 메시지를 텍스트 위젯으로 변경 (긴 텍스트 처리)
                    user_text = tk.Text(
                        user_frame,
                        height=3,
                        font=self.fonts['small'],
                        fg=self.colors['text_primary'],
                        bg=self.colors['bg_secondary'],
                        wrap=tk.WORD,
                        relief=tk.FLAT,
                        bd=0,
                        padx=5,
                        pady=2
                    )
                    user_text.insert(tk.END, user_msg)
                    user_text.config(state=tk.DISABLED)
                    user_text.pack(anchor=tk.W, padx=(20, 0), fill=tk.X)
                    
                    # 봇 응답
                    bot_frame = tk.Frame(card_frame, bg=self.colors['bg_secondary'])
                    bot_frame.pack(fill=tk.X, pady=(5, 0))
                    
                    bot_label = tk.Label(
                        bot_frame,
                        text="🤖 Bot:",
                        font=('Segoe UI', 9, 'bold'),
                        fg=self.colors['accent_green'],
                        bg=self.colors['bg_secondary']
                    )
                    bot_label.pack(anchor=tk.W)
                    
                    # 봇 응답을 텍스트 위젯으로 변경 (긴 텍스트 처리)
                    bot_text = tk.Text(
                        bot_frame,
                        height=4,
                        font=self.fonts['small'],
                        fg=self.colors['text_primary'],
                        bg=self.colors['bg_secondary'],
                        wrap=tk.WORD,
                        relief=tk.FLAT,
                        bd=0,
                        padx=5,
                        pady=2
                    )
                    bot_text.insert(tk.END, bot_msg)
                    bot_text.config(state=tk.DISABLED)
                    bot_text.pack(anchor=tk.W, padx=(20, 0), fill=tk.X)
            
            # 스크롤 영역 업데이트
            history_window.update_idletasks()
            configure_scroll_region()
            
        except Exception as e:
            print(f"히스토리 새로고침 오류: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def cleanup(self):
        """애플리케이션 종료 시 정리 작업"""
        try:
            if hasattr(self, 'conn'):
                self.conn.close()
        except Exception as e:
            print(f"데이터베이스 연결 종료 오류: {str(e)}")

def main():
    """메인 함수"""
    root = tk.Tk()
    app = ChatbotGUI(root)
    
    # 색상 태그 설정 - 더 예쁜 색상으로
    app.chat_display.tag_configure("user", foreground=app.colors['accent_blue'], font=app.fonts['chat'])
    app.chat_display.tag_configure("bot", foreground=app.colors['accent_green'], font=app.fonts['chat'])
    app.chat_display.tag_configure("system", foreground=app.colors['accent_orange'], font=app.fonts['chat'])
    
    # 라벨 태그 설정 (더 굵게)
    app.chat_display.tag_configure("user_label", foreground=app.colors['accent_blue'], font=('Segoe UI', 10, 'bold'))
    app.chat_display.tag_configure("bot_label", foreground=app.colors['accent_green'], font=('Segoe UI', 10, 'bold'))
    app.chat_display.tag_configure("system_label", foreground=app.colors['accent_orange'], font=('Segoe UI', 10, 'bold'))
    
    # 애플리케이션 종료 시 정리 작업
    def on_closing():
        app.cleanup()
        root.destroy()
    
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()
