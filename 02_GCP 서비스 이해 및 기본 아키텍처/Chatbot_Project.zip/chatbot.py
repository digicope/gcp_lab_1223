import os
from openai import OpenAI
from openai import APIError, RateLimitError, APITimeoutError, APIConnectionError
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# API 키 확인
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    print("오류: OPENAI_API_KEY가 설정되지 않았습니다.")
    print(".env 파일에 OPENAI_API_KEY를 설정해주세요.")
    exit(1)

# OpenAI 클라이언트 생성
try:
    client = OpenAI(api_key=api_key)
    print("OpenAI 클라이언트가 성공적으로 초기화되었습니다.")
except Exception as e:
    print(f"OpenAI 클라이언트 초기화 실패: {str(e)}")
    exit(1)

def chat_with_gpt(user_input, conversation_history, temperature=0.7):
    """
    사용자 입력과 대화 히스토리를 받아 OpenAI API에 전달하고 응답을 반환하는 함수
    
    Args:
        user_input (str): 사용자가 입력한 질문
        conversation_history (list): 이전 대화 내용들
        temperature (float): 응답의 창의성 조절 (0.0-1.0)
        
    Returns:
        str: GPT의 응답 또는 오류 메시지
    """
    try:
        # 현재 사용자 입력을 히스토리에 추가
        messages = conversation_history + [{"role": "user", "content": user_input}]
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            max_tokens=1000,
            temperature=temperature
        )
        return response.choices[0].message.content
        
    except RateLimitError as e:
        error_msg = "API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."
        print(f"[오류] {error_msg}")
        return error_msg
        
    except APITimeoutError as e:
        error_msg = "API 요청 시간이 초과되었습니다. 네트워크 연결을 확인하고 다시 시도해주세요."
        print(f"[오류] {error_msg}")
        return error_msg
        
    except APIConnectionError as e:
        error_msg = "API 서버에 연결할 수 없습니다. 인터넷 연결을 확인해주세요."
        print(f"[오류] {error_msg}")
        return error_msg
        
    except APIError as e:
        error_msg = f"OpenAI API 오류가 발생했습니다: {str(e)}"
        print(f"[오류] {error_msg}")
        return error_msg
        
    except Exception as e:
        error_msg = f"예상치 못한 오류가 발생했습니다: {str(e)}"
        print(f"[오류] {error_msg}")
        return error_msg

def main():
    """
    메인 함수 - 사용자가 'quit'을 입력할 때까지 반복적으로 채팅
    """
    print("채팅봇에 오신 것을 환영합니다!")
    print("Temperature 모드를 선택해주세요:")
    print("1. 정확한 모드 (0.2) - 일관되고 정확한 응답")
    print("2. 창의적 모드 (1.0) - 다양하고 창의적인 응답")
    
    while True:
        mode_choice = input("모드를 선택하세요 (1 또는 2): ").strip()
        if mode_choice == "1":
            temperature = 0.2
            print("정확한 모드가 선택되었습니다.\n")
            break
        elif mode_choice == "2":
            temperature = 1.0
            print("창의적 모드가 선택되었습니다.\n")
            break
        else:
            print("1 또는 2를 입력해주세요.")
    
    print("'quit'을 입력하면 종료됩니다.\n")
    
    # 대화 히스토리를 저장할 리스트
    conversation_history = []
    
    while True:
        # 사용자 입력 받기
        user_input = input("You: ").strip()
        
        # 'quit' 입력 시 종료
        if user_input.lower() == 'quit':
            print("Bot: 안녕히 가세요!")
            break
        
        # 빈 입력 처리
        if not user_input:
            print("Bot: 질문을 입력해주세요.")
            continue
        
        # GPT와 채팅 (히스토리 포함)
        bot_response = chat_with_gpt(user_input, conversation_history, temperature)
        print(f"Bot: {bot_response}\n")
        
        # 오류가 발생하지 않은 경우에만 대화 히스토리에 추가
        if not bot_response.startswith("API 요청 한도를 초과했습니다") and \
           not bot_response.startswith("API 요청 시간이 초과되었습니다") and \
           not bot_response.startswith("API 서버에 연결할 수 없습니다") and \
           not bot_response.startswith("OpenAI API 오류가 발생했습니다") and \
           not bot_response.startswith("예상치 못한 오류가 발생했습니다"):
            conversation_history.append({"role": "user", "content": user_input})
            conversation_history.append({"role": "assistant", "content": bot_response})
        
        # 히스토리가 너무 길어지면 최근 10개 대화만 유지 (20개 메시지)
        if len(conversation_history) > 20:
            conversation_history = conversation_history[-20:]

if __name__ == "__main__":
    main()
