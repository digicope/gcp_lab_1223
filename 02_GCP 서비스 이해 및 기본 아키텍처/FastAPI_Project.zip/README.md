# PDF 텍스트 추출 및 AI 요약 웹 애플리케이션 (Google Cloud 버전)

이 프로젝트는 FastAPI를 기반으로 PDF 파일을 **Google Cloud Storage(GCS)**에 업로드하고, 최신 Gemini AI(2.5-flash) 모델을 사용하여 텍스트 추출 및 요약을 수행하는 웹 애플리케이션입니다.

## 주요 기능

1.  **GCS 업로드**: 웹 페이지를 통해 PDF 파일을 Google Cloud Storage 버킷의 `uploads/` 경로에 업로드합니다.
2.  **파일 목록 보기**: GCS 버킷에 저장된 PDF 파일 목록을 실시간으로 가져와 메인 페이지에 표시합니다.
3.  **텍스트 추출**: PDF를 메모리에서 직접 읽어 텍스트를 추출하고, 결과물을 GCS의 `processed/` 경로에 저장합니다.
4.  **AI 요약**: 추출된 텍스트를 Google Gemini 2.5 Flash 모델로 요약합니다.
5.  **클라우드 저장**: 모든 결과 파일(추출 텍스트, 요약본)은 GCS에 안전하게 저장됩니다.

## 설치 및 환경 설정

### 1. 사전 요구 사항
*   Python 3.10 이상
*   Google Cloud 프로젝트 및 **GCS 버킷** 생성
*   Gemini API Key ([Google AI Studio](https://aistudio.google.com/))
*   Google Cloud 서비스 계정 키 (JSON 파일)

### 2. 라이브러리 설치
```bash
pip install -r requirements.txt
```

### 3. 환경 변수 설정 (`.env`)
프로젝트 루트 폴더의 `.env` 파일을 다음과 같이 수정합니다.
```env
GEMINI_API_KEY=your_gemini_api_key
GCS_BUCKET_NAME=your_bucket_name
GOOGLE_APPLICATION_CREDENTIALS=path/to/your/service-account-key.json
```

## 실행 방법
```bash
python main.py
```
접속 주소: `http://127.0.0.1:8000`

## 기술 스택
*   **Backend**: FastAPI
*   **Cloud Storage**: Google Cloud Storage (GCS)
*   **AI Model**: Google Gemini 2.5 Flash
*   **Library**: `google-cloud-storage`, `google-genai`, `pypdf`

