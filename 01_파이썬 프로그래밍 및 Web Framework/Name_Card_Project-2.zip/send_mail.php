<?php
// JSON 응답 헤더 설정
header('Content-Type: application/json; charset=UTF-8');

// 메일 전송 설정 
$to = "digicope@aicore.co.kr"; // 수신 주소
$subject = "문의하기 - " . date("Y-m-d H:i:s");

// POST 데이터 받기
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

// 입력값 검증
if (empty($name) || empty($email) || empty($message)) {
    echo json_encode([
        'success' => false,
        'message' => '모든 필드를 입력해주세요.'
    ]);
    exit;
}

// 이메일 형식 검증
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'success' => false,
        'message' => '올바른 이메일 주소를 입력해주세요.'
    ]);
    exit;
}

// 메일 본문 작성
$body = "문의하기 폼에서 메시지가 도착했습니다.\n\n";
$body .= "이름: " . $name . "\n";
$body .= "이메일: " . $email . "\n";
$body .= "메시지:\n" . $message . "\n\n";
$body .= "---\n";
$body .= "발신 시간: " . date("Y-m-d H:i:s");

// 메일 헤더 설정
$headers = "From: " . $email . "\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// 메일 전송
$mailSent = mail($to, $subject, $body, $headers);

// 결과 반환
if ($mailSent) {
    echo json_encode([
        'success' => true,
        'message' => '메일이 성공적으로 전송되었습니다.'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => '메일 전송에 실패했습니다. 다시 시도해주세요.'
    ]);
}
?>

