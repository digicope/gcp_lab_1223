// 다크 모드 토글 기능
document.addEventListener('DOMContentLoaded', function() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const businessCard = document.getElementById('businessCard');
    
    // 로컬 스토리지에서 다크 모드 상태 불러오기
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    
    // 초기 다크 모드 상태 적용
    if (isDarkMode) {
        businessCard.classList.add('dark-mode');
        updateToggleIcon(true);
    }
    
    // 다크 모드 토글 버튼 클릭 이벤트
    darkModeToggle.addEventListener('click', function() {
        businessCard.classList.toggle('dark-mode');
        const isDark = businessCard.classList.contains('dark-mode');
        
        // 로컬 스토리지에 다크 모드 상태 저장
        localStorage.setItem('darkMode', isDark);
        
        // 토글 아이콘 업데이트
        updateToggleIcon(isDark);
    });
    
    // 토글 아이콘 업데이트 함수
    function updateToggleIcon(isDark) {
        const toggleIcon = darkModeToggle.querySelector('.toggle-icon');
        if (isDark) {
            toggleIcon.textContent = '☀️';
        } else {
            toggleIcon.textContent = '🌙';
        }
    }

    // Contacts 모달 기능
    const contactsButton = document.getElementById('contactsButton');
    const modalOverlay = document.getElementById('modalOverlay');
    const modalClose = document.getElementById('modalClose');
    const contactForm = document.getElementById('contactForm');

    // 모달 열기
    if (contactsButton) {
        contactsButton.addEventListener('click', function() {
            modalOverlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });
    }

    // 모달 닫기
    if (modalClose) {
        modalClose.addEventListener('click', function() {
            modalOverlay.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }

    // 오버레이 클릭 시 모달 닫기
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                modalOverlay.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    }

    // ESC 키로 모달 닫기
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modalOverlay.style.display === 'flex') {
            modalOverlay.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // 폼 제출 처리
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitButton = contactForm.querySelector('.submit-button');
            const originalText = submitButton.textContent;
            
            // 버튼 비활성화 및 로딩 표시
            submitButton.disabled = true;
            submitButton.textContent = '전송 중...';
            
            // FormData 생성
            const formData = new FormData(contactForm);
            
            // AJAX로 폼 제출
            fetch('send_mail.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    contactForm.reset();
                    modalOverlay.style.display = 'none';
                    document.body.style.overflow = 'auto';
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('오류가 발생했습니다. 다시 시도해주세요.');
            })
            .finally(() => {
                submitButton.disabled = false;
                submitButton.textContent = originalText;
            });
        });
    }
});

