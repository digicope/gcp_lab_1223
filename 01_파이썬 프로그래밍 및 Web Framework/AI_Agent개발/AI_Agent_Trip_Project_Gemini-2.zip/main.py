"""
메인 실행 파일
CLI 인터페이스를 제공합니다.
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# 프로젝트 루트 경로 설정
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# 환경 변수 로드 (프로젝트 루트의 .env 파일)
env_file = project_root / ".env"
load_dotenv(env_file)

from agent.travel_agent import TravelAgent
from utils.logger import logger


def main():
    """메인 함수"""
    print("=" * 60)
    print("AI 여행 루트 추천 에이전트")
    print("=" * 60)
    print()
    
    try:
        # API 키 확인
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            print("오류: GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
            env_path = project_root / ".env"
            print(f"프로젝트 루트의 .env 파일에 GEMINI_API_KEY를 설정해주세요.")
            print(f"경로: {env_path}")
            return
        
        # 에이전트 초기화
        print("에이전트 초기화 중...")
        agent = TravelAgent(api_key=api_key)
        print("에이전트 초기화 완료!")
        print()
        
        # 사용자 입력 받기
        print("여행 정보를 입력해주세요:")
        print("-" * 60)
        
        destination = input("여행지: ").strip()
        if not destination:
            print("여행지를 입력해주세요.")
            return
        
        duration_str = input("여행 기간 (일): ").strip()
        try:
            duration = int(duration_str)
        except ValueError:
            print("올바른 숫자를 입력해주세요.")
            return
        
        budget = input("예산 (선택적, Enter로 건너뛰기): ").strip() or None
        travelers_str = input("동행 인원 (선택적, Enter로 건너뛰기): ").strip()
        travelers = int(travelers_str) if travelers_str else None
        
        preferences = input("선호사항 (선택적, Enter로 건너뛰기): ").strip() or None
        
        image_path = input("이미지 경로 (선택적, Enter로 건너뛰기): ").strip() or None
        
        print()
        print("=" * 60)
        print("여행 일정 생성 중...")
        print("=" * 60)
        print()
        
        # 여행 계획 생성
        result = agent.plan_travel(
            destination=destination,
            duration=duration,
            budget=budget,
            travelers=travelers,
            preferences=preferences,
            image_path=image_path
        )
        
        # 결과 출력
        if "error" in result:
            print(f"오류 발생: {result['error']}")
            return
        
        print("=" * 60)
        print("생성된 여행 일정")
        print("=" * 60)
        print()
        
        if result.get("image_analysis"):
            print("📸 이미지 분석 결과:")
            print("-" * 60)
            print(result["image_analysis"])
            print()
        
        print("🗺️  여행 일정:")
        print("-" * 60)
        print(result.get("itinerary", "일정을 생성할 수 없습니다."))
        print()
        
        print("=" * 60)
        print("완료!")
        print("=" * 60)
        
    except KeyboardInterrupt:
        print("\n\n프로그램이 중단되었습니다.")
    except Exception as e:
        logger.error(f"프로그램 실행 중 오류: {e}")
        print(f"\n오류 발생: {e}")


if __name__ == "__main__":
    main()

