# 프로젝트 구조 상세 설명

## 전체 파일 구조

```
AI_Agent_Trip_Project_Gemini/
├── main.py                      # CLI 메인 실행 파일
├── requirements.txt             # Python 패키지 의존성
├── README.md                    # 프로젝트 소개 및 사용법
├── TEST_GUIDE.md                # 테스트 가이드
├── PROJECT_STRUCTURE.md         # 프로젝트 구조 설명 (이 파일)
├── .gitignore                   # Git 무시 파일 목록
│
├── agent/                       # 에이전트 모듈
│   ├── __init__.py
│   └── travel_agent.py         # 메인 여행 에이전트 클래스
│
├── tools/                       # 도구(Tool) 모듈
│   ├── __init__.py
│   ├── image_tool.py           # 이미지 분석 도구
│   ├── search_tool.py          # 웹 검색 도구 (DuckDuckGo)
│   ├── rag_tool.py             # RAG 검색 도구
│   └── itinerary_tool.py       # 여행 일정 생성 도구
│
├── rag/                         # RAG 시스템
│   ├── __init__.py
│   ├── rag_init.py             # RAG 초기화 및 벡터 스토어 관리
│   └── dataset/                # RAG 데이터셋 디렉토리
│       ├── .gitkeep
│       └── sample_travel_guide.txt  # 샘플 여행 가이드
│
├── utils/                       # 유틸리티 모듈
│   ├── __init__.py
│   └── logger.py               # 로깅 유틸리티
│
└── ui/                          # 사용자 인터페이스
    └── app.py                   # Streamlit 웹 UI
```

## 주요 파일 설명

### 1. main.py
- CLI 인터페이스를 제공하는 메인 실행 파일
- 사용자 입력을 받아 여행 일정을 생성
- 환경 변수 로드: `C:/env/.env`

### 2. agent/travel_agent.py
- **TravelAgent 클래스**: 통합 여행 에이전트
- LangChain v1.0의 `create_react_agent`를 사용하여 에이전트 구성
- 여러 도구를 통합하여 사용
- 주요 메서드:
  - `plan_travel()`: 여행 일정 계획
  - `chat()`: 대화형 인터페이스

### 3. tools/ 디렉토리
각 도구는 `@tool` 데코레이터로 정의되어 LangChain 에이전트에서 사용 가능:

- **image_tool.py**: Gemini Vision API를 사용한 이미지 분석
- **search_tool.py**: DuckDuckGo 웹 검색
- **rag_tool.py**: ChromaDB 벡터 검색
- **itinerary_tool.py**: 최종 일정 생성 (Gemini LLM 사용)

### 4. rag/rag_init.py
- **RAGInitializer 클래스**: RAG 시스템 초기화 및 관리
- ChromaDB를 사용한 벡터 스토어 생성
- Google Generative AI Embeddings 사용
- 기본 여행 가이드 문서 자동 생성

### 5. ui/app.py
- Streamlit 기반 웹 인터페이스
- 사용자 친화적인 UI 제공
- 이미지 업로드, 일정 생성, 결과 다운로드 기능

### 6. utils/logger.py
- 로깅 유틸리티
- 콘솔 및 파일 로그 출력
- `logs/` 디렉토리에 일별 로그 파일 저장

## 데이터 흐름

```
사용자 입력
    ↓
TravelAgent.plan_travel()
    ↓
[이미지 분석] → image_tool
    ↓
[정보 수집]
    ├─→ rag_tool (기본 정보)
    ├─→ search_tool (최신 정보)
    └─→ search_tool (맛집 정보)
    ↓
[일정 생성] → itinerary_tool
    ↓
결과 반환
```

## 환경 변수 설정

프로젝트 루트 디렉토리에 `.env` 파일을 생성하고 다음을 설정:
```
GEMINI_API_KEY=your_gemini_api_key_here
```

`.env.example` 파일을 참고하여 `.env` 파일을 생성할 수 있습니다.

## 실행 순서

1. **환경 설정**
   - Python 가상 환경 생성
   - `pip install -r requirements.txt`
   - `.env` 파일에 API 키 설정

2. **RAG 초기화** (자동)
   - 첫 실행 시 `rag/chroma_db/` 디렉토리에 벡터 DB 생성
   - 기본 여행 가이드 문서 자동 포함

3. **에이전트 실행**
   - CLI: `python main.py`
   - UI: `streamlit run ui/app.py`

## 확장 가능성

- **추가 도구**: `tools/` 디렉토리에 새 도구 추가
- **RAG 데이터**: `rag/dataset/`에 텍스트 파일 추가
- **UI 커스터마이징**: `ui/app.py` 수정
- **에이전트 로직**: `agent/travel_agent.py` 수정

