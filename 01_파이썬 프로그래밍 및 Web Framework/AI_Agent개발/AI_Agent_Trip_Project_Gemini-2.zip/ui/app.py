"""
Streamlit 웹 UI
여행 일정 추천 에이전트의 웹 인터페이스입니다.
"""

import os
import sys
from pathlib import Path
import tempfile
from dotenv import load_dotenv

import streamlit as st

# 프로젝트 루트를 경로에 추가
# Streamlit 실행 시 경로 문제 해결
try:
    # __file__이 있는 경우 (일반적인 경우)
    script_path = Path(__file__).resolve()
    project_root = script_path.parent.parent
except NameError:
    # __file__이 없는 경우 (일부 환경)
    project_root = Path.cwd()

# 프로젝트 루트를 sys.path에 추가 (중복 방지)
project_root_str = str(project_root.resolve())
if project_root_str not in sys.path:
    sys.path.insert(0, project_root_str)

# 환경 변수 로드 (프로젝트 루트의 .env 파일)
env_file = project_root / ".env"
load_dotenv(env_file)

# 디버깅용 (필요시 주석 해제)
# st.write(f"Project root: {project_root_str}")
# st.write(f"Python path: {sys.path[:3]}")

from agent.travel_agent import TravelAgent
from utils.logger import logger


# 페이지 설정
st.set_page_config(
    page_title="AI 여행 루트 추천 에이전트",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if "agent" not in st.session_state:
    st.session_state.agent = None
if "itinerary_result" not in st.session_state:
    st.session_state.itinerary_result = None


def initialize_agent():
    """에이전트를 초기화합니다."""
    if st.session_state.agent is None:
        try:
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                st.error("❌ GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
                st.info(f"프로젝트 루트의 .env 파일에 GEMINI_API_KEY를 설정해주세요.\n경로: {project_root_str}\\.env")
                return False
            
            with st.spinner("에이전트 초기화 중..."):
                st.session_state.agent = TravelAgent(api_key=api_key)
            return True
        except Exception as e:
            st.error(f"에이전트 초기화 실패: {e}")
            logger.error(f"에이전트 초기화 실패: {e}")
            return False
    return True


def main():
    """메인 UI 함수"""
    
    # 헤더
    st.title("✈️ AI 여행 루트 추천 에이전트")
    st.markdown("---")
    st.markdown(
        """
        **Gemini API와 LangChain v1.0**을 활용한 통합 여행 일정 추천 시스템입니다.
        
        - 📝 텍스트 기반 여행 일정 추천
        - 📸 이미지 기반 장소 추론
        - 🔍 웹 검색 통합 (최신 정보 반영)
        - 📚 RAG 시스템 (여행 지식 검색)
        """
    )
    st.markdown("---")
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # API 키 확인
        api_key = os.getenv("GEMINI_API_KEY")
        if api_key:
            st.success("✅ API 키 설정됨")
        else:
            st.error("❌ API 키 미설정")
            st.info(f"프로젝트 루트의 .env 파일에 GEMINI_API_KEY를 설정해주세요.\n경로: {project_root_str}\\.env")
        
        st.markdown("---")
        
        # 에이전트 초기화 버튼
        if st.button("🔄 에이전트 초기화", use_container_width=True):
            st.session_state.agent = None
            if initialize_agent():
                st.success("에이전트 초기화 완료!")
        
        st.markdown("---")
        st.markdown("### 📖 사용 방법")
        st.markdown("""
        1. 여행 정보를 입력하세요
        2. (선택) 여행 사진을 업로드하세요
        3. "여행 일정 생성하기" 버튼을 클릭하세요
        4. 생성된 일정을 확인하세요
        """)
    
    # 메인 컨텐츠
    if not initialize_agent():
        st.stop()
    
    # 입력 폼
    st.header("📋 여행 정보 입력")
    
    col1, col2 = st.columns(2)
    
    with col1:
        destination = st.text_input(
            "여행지 *",
            placeholder="예: 파리, 도쿄, 서울",
            help="여행하고 싶은 도시나 지역을 입력하세요"
        )
        
        duration = st.number_input(
            "여행 기간 (일) *",
            min_value=1,
            max_value=30,
            value=3,
            help="여행할 일수를 입력하세요"
        )
        
        budget = st.text_input(
            "예산 (선택적)",
            placeholder="예: 100만원, $2000",
            help="예산을 입력하세요 (선택사항)"
        )
    
    with col2:
        travelers = st.number_input(
            "동행 인원 (선택적)",
            min_value=1,
            max_value=20,
            value=2,
            help="함께 여행할 인원 수"
        )
        
        preferences = st.text_area(
            "선호사항 (선택적)",
            placeholder="예: 예술과 맛집, 자연 경관, 쇼핑",
            help="여행 중 선호하는 활동이나 관심사"
        )
    
    # 이미지 업로드
    st.markdown("---")
    st.subheader("📸 여행 사진 업로드 (선택적)")
    uploaded_file = st.file_uploader(
        "이미지 파일을 업로드하세요",
        type=["jpg", "jpeg", "png"],
        help="여행지 사진을 업로드하면 장소를 분석하고 일정에 반영합니다"
    )
    
    image_path = None
    if uploaded_file is not None:
        # 이미지 미리보기
        st.image(uploaded_file, caption="업로드된 이미지", use_container_width=True)
        
        # 임시 파일로 저장
        with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            image_path = tmp_file.name
    
    st.markdown("---")
    
    # 일정 생성 버튼
    col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 2])
    
    with col_btn1:
        generate_button = st.button(
            "🚀 여행 일정 생성하기",
            type="primary",
            use_container_width=True
        )
    
    with col_btn2:
        clear_button = st.button(
            "🗑️ 결과 초기화",
            use_container_width=True
        )
    
    if clear_button:
        st.session_state.itinerary_result = None
        st.rerun()
    
    # 일정 생성 처리
    if generate_button:
        # 입력 검증
        if not destination:
            st.error("❌ 여행지를 입력해주세요.")
            st.stop()
        
        # 진행 상황 표시
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        try:
            status_text.text("여행 일정 생성 중...")
            progress_bar.progress(20)
            
            # 여행 계획 생성
            with st.spinner("AI가 여행 일정을 생성하고 있습니다. 잠시만 기다려주세요..."):
                result = st.session_state.agent.plan_travel(
                    destination=destination,
                    duration=duration,
                    budget=budget if budget else None,
                    travelers=travelers if travelers > 0 else None,
                    preferences=preferences if preferences else None,
                    image_path=image_path
                )
            
            progress_bar.progress(100)
            status_text.text("완료!")
            
            # 결과 저장
            st.session_state.itinerary_result = result
            
            # 임시 파일 삭제
            if image_path and os.path.exists(image_path):
                try:
                    os.unlink(image_path)
                except:
                    pass
            
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ 오류 발생: {e}")
            logger.error(f"일정 생성 중 오류: {e}")
            progress_bar.empty()
            status_text.empty()
    
    # 결과 표시
    if st.session_state.itinerary_result:
        result = st.session_state.itinerary_result
        
        if "error" in result:
            st.error(f"❌ 오류: {result['error']}")
        else:
            st.markdown("---")
            st.header("📅 생성된 여행 일정")
            
            # 이미지 분석 결과
            if result.get("image_analysis"):
                with st.expander("📸 이미지 분석 결과", expanded=False):
                    st.markdown(result["image_analysis"])
            
            # 여행 일정
            st.markdown("### 🗺️ 상세 일정")
            st.markdown(result.get("itinerary", "일정을 생성할 수 없습니다."))
            
            # 다운로드 버튼
            st.markdown("---")
            col_dl1, col_dl2 = st.columns(2)
            
            with col_dl1:
                st.download_button(
                    label="📥 일정 다운로드 (텍스트)",
                    data=result.get("itinerary", ""),
                    file_name=f"{result.get('destination', 'travel')}_itinerary.txt",
                    mime="text/plain",
                    use_container_width=True
                )
            
            with col_dl2:
                # JSON 형식으로 다운로드
                import json
                json_data = json.dumps(result, ensure_ascii=False, indent=2)
                st.download_button(
                    label="📥 일정 다운로드 (JSON)",
                    data=json_data,
                    file_name=f"{result.get('destination', 'travel')}_itinerary.json",
                    mime="application/json",
                    use_container_width=True
                )
    
    # 푸터
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: gray;'>
        <p>AI 여행 루트 추천 에이전트 | Powered by Gemini API & LangChain v1.0</p>
        </div>
        """,
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()

