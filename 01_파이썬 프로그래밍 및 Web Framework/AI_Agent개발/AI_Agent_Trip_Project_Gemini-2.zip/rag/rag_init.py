"""
RAG 시스템 초기화 모듈
ChromaDB를 사용하여 여행 관련 문서를 벡터화하고 저장합니다.
"""

import os
from pathlib import Path
from typing import List, Optional

import chromadb
from chromadb.config import Settings
from langchain_community.vectorstores import Chroma
from langchain_google_genai import GoogleGenerativeAIEmbeddings

# LangChain v1.0 호환 import
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    try:
        from langchain_core.text_splitters import RecursiveCharacterTextSplitter
    except ImportError:
        from langchain.text_splitter import RecursiveCharacterTextSplitter

try:
    from langchain_core.documents import Document
except ImportError:
    from langchain.schema import Document

from utils.logger import logger


class RAGInitializer:
    """RAG 시스템을 초기화하고 관리하는 클래스"""
    
    def __init__(self, db_path: str = "./rag/chroma_db", collection_name: str = "travel_knowledge"):
        """
        RAG 초기화
        
        Args:
            db_path: ChromaDB 저장 경로
            collection_name: 컬렉션 이름
        """
        self.db_path = db_path
        self.collection_name = collection_name
        self.embeddings = None
        self.vectorstore = None
        
        # ChromaDB 클라이언트 초기화
        self.client = chromadb.PersistentClient(
            path=db_path,
            settings=Settings(anonymized_telemetry=False)
        )
        
    def initialize_embeddings(self):
        """임베딩 모델 초기화"""
        try:
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                raise ValueError("GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
            
            self.embeddings = GoogleGenerativeAIEmbeddings(
                model="models/embedding-001",
                google_api_key=api_key
            )
            logger.info("임베딩 모델 초기화 완료")
        except Exception as e:
            logger.error(f"임베딩 모델 초기화 실패: {e}")
            raise
    
    def load_documents(self, dataset_dir: str = "./rag/dataset") -> List[Document]:
        """
        데이터셋 디렉토리에서 문서를 로드합니다.
        
        Args:
            dataset_dir: 데이터셋 디렉토리 경로
        
        Returns:
            Document 리스트
        """
        documents = []
        dataset_path = Path(dataset_dir)
        
        if not dataset_path.exists():
            logger.warning(f"데이터셋 디렉토리가 없습니다: {dataset_dir}")
            # 기본 여행 정보 문서 생성
            default_docs = self._create_default_documents()
            return default_docs
        
        # 텍스트 파일 읽기
        for file_path in dataset_path.glob("*.txt"):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    documents.append(Document(
                        page_content=content,
                        metadata={"source": str(file_path), "type": "travel_guide"}
                    ))
                logger.info(f"문서 로드 완료: {file_path}")
            except Exception as e:
                logger.error(f"문서 로드 실패 {file_path}: {e}")
        
        if not documents:
            logger.warning("로드된 문서가 없습니다. 기본 문서를 생성합니다.")
            documents = self._create_default_documents()
        
        return documents
    
    def _create_default_documents(self) -> List[Document]:
        """기본 여행 정보 문서를 생성합니다."""
        default_docs = [
            Document(
                page_content="""
                파리 여행 가이드
                파리는 프랑스의 수도로, 예술과 문화의 중심지입니다.
                주요 관광지: 에펠탑, 루브르 박물관, 노트르담 대성당, 샹젤리제 거리
                추천 맛집: 프랑스 전통 레스토랑, 파리 카페
                최적 여행 기간: 3-5일
                """,
                metadata={"source": "default_paris", "type": "travel_guide"}
            ),
            Document(
                page_content="""
                도쿄 여행 가이드
                도쿄는 일본의 수도로, 현대적이면서도 전통적인 문화가 공존하는 도시입니다.
                주요 관광지: 도쿄 타워, 시부야, 하라주쿠, 아사쿠사, 긴자
                추천 맛집: 스시, 라멘, 이자카야
                최적 여행 기간: 4-7일
                """,
                metadata={"source": "default_tokyo", "type": "travel_guide"}
            ),
            Document(
                page_content="""
                서울 여행 가이드
                서울은 대한민국의 수도로, 고궁과 현대적 건축물이 어우러진 도시입니다.
                주요 관광지: 경복궁, 남산타워, 명동, 홍대, 인사동
                추천 맛집: 한식, 김치찌개, 불고기, 치킨
                최적 여행 기간: 2-4일
                """,
                metadata={"source": "default_seoul", "type": "travel_guide"}
            ),
        ]
        return default_docs
    
    def create_vectorstore(self, documents: Optional[List[Document]] = None) -> Chroma:
        """
        벡터 스토어를 생성합니다.
        
        Args:
            documents: 문서 리스트 (None이면 자동 로드)
        
        Returns:
            Chroma 벡터 스토어
        """
        if self.embeddings is None:
            self.initialize_embeddings()
        
        if documents is None:
            documents = self.load_documents()
        
        # 문서 분할
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )
        splits = text_splitter.split_documents(documents)
        logger.info(f"문서 분할 완료: {len(splits)}개 청크")
        
        # 벡터 스토어 생성
        try:
            self.vectorstore = Chroma.from_documents(
                documents=splits,
                embedding=self.embeddings,
                persist_directory=self.db_path,
                collection_name=self.collection_name
            )
            logger.info(f"벡터 스토어 생성 완료: {self.db_path}")
        except Exception as e:
            logger.error(f"벡터 스토어 생성 실패: {e}")
            raise
        
        return self.vectorstore
    
    def get_vectorstore(self) -> Optional[Chroma]:
        """
        기존 벡터 스토어를 로드합니다.
        
        Returns:
            Chroma 벡터 스토어 또는 None
        """
        if self.embeddings is None:
            self.initialize_embeddings()
        
        try:
            self.vectorstore = Chroma(
                persist_directory=self.db_path,
                embedding_function=self.embeddings,
                collection_name=self.collection_name
            )
            logger.info("기존 벡터 스토어 로드 완료")
            return self.vectorstore
        except Exception as e:
            logger.warning(f"기존 벡터 스토어 로드 실패: {e}")
            logger.info("새로운 벡터 스토어를 생성합니다.")
            return self.create_vectorstore()
    
    def add_documents(self, documents: List[Document]):
        """
        벡터 스토어에 새 문서를 추가합니다.
        
        Args:
            documents: 추가할 문서 리스트
        """
        if self.vectorstore is None:
            self.get_vectorstore()
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        splits = text_splitter.split_documents(documents)
        
        self.vectorstore.add_documents(splits)
        logger.info(f"{len(splits)}개 문서 추가 완료")


def initialize_rag(db_path: str = "./rag/chroma_db") -> Chroma:
    """
    RAG 시스템을 초기화하고 벡터 스토어를 반환합니다.
    
    Args:
        db_path: 벡터 DB 저장 경로
    
    Returns:
        Chroma 벡터 스토어
    """
    initializer = RAGInitializer(db_path=db_path)
    return initializer.get_vectorstore()

