# AI 여행 루트 추천 에이전트 프로젝트

Gemini API와 LangChain v1.0을 활용한 통합 여행 일정 추천 AI 에이전트입니다.

## 주요 기능

1. **텍스트 기반 여행 일정 추천**: 여행지, 날짜, 예산, 인원 등을 입력받아 맞춤형 일정 생성
2. **이미지 기반 장소 추론**: 여행 사진을 업로드하여 장소를 분석하고 일정에 반영
3. **웹 검색 통합**: DuckDuckGo를 활용한 최신 여행 정보 검색
4. **RAG 시스템**: 여행 관련 기본 정보를 문서로 저장하고 검색

## 프로젝트 구조

```
project/
  ├── main.py                 # CLI 실행 파일
  ├── agent/
  │     ├── travel_agent.py   # 메인 에이전트 구현
  ├── tools/
  │     ├── image_tool.py     # 이미지 분석 도구
  │     ├── search_tool.py    # 웹 검색 도구
  │     ├── rag_tool.py       # RAG 검색 도구
  │     ├── itinerary_tool.py # 일정 생성 도구
  ├── rag/
  │     ├── rag_init.py       # RAG 초기화
  │     ├── dataset/          # RAG 데이터셋
  ├── utils/
  │     ├── logger.py         # 로깅 유틸리티
  ├── ui/
  │     ├── app.py            # Streamlit UI
  ├── requirements.txt
  └── README.md
```

## 설치 방법

1. 가상 환경 생성 및 활성화:
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate
```

2. 의존성 설치:
```bash
pip install -r requirements.txt
```

3. 환경 변수 설정:
   - 프로젝트 루트 디렉토리에 `.env` 파일을 생성
   - Gemini API 키를 설정:
     ```
     GEMINI_API_KEY=your_api_key_here
     ```
   - 예시: `.env.example` 파일을 참고하여 `.env` 파일을 생성할 수 있습니다.

## 실행 방법

### CLI 실행
```bash
python main.py
```

### Streamlit UI 실행
```bash
streamlit run ui/app.py
```

## 사용 예시

### 텍스트 기반 일정 생성
```
여행지: 파리
기간: 3일
예산: 100만원
인원: 2명
```

### 이미지 업로드
- 여행지 사진을 업로드하면 자동으로 장소를 분석하고 일정에 반영합니다.

## 주요 기술 스택

- **LangChain v1.0**: 에이전트 프레임워크
- **Google Gemini API**: LLM 및 Vision API
- **ChromaDB**: 벡터 데이터베이스 (RAG)
- **DuckDuckGo Search**: 웹 검색
- **Streamlit**: 웹 UI

## 라이선스

이 프로젝트는 교육용 목적으로 제작되었습니다.

