"""
여행 에이전트 메인 모듈
LangChain v1.0의 create_agent()를 사용하여 통합 에이전트를 구성합니다.
"""

import os
from typing import List, Optional, Dict, Any

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import create_agent
from langchain_core.tools import Tool

from tools.image_tool import analyze_travel_image, analyze_image_from_bytes
from tools.search_tool import search_travel_info, search_recent_trends, search_restaurants
from tools.rag_tool import search_travel_knowledge, get_destination_info
from tools.itinerary_tool import generate_itinerary

from utils.logger import logger


class TravelAgent:
    """통합 여행 에이전트 클래스"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        에이전트 초기화
        
        Args:
            api_key: Gemini API 키 (None이면 환경 변수에서 로드)
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY가 설정되지 않았습니다.")
        
        # LLM 초기화 (gemini-2.5-flash 모델 사용)
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash-exp",  # gemini-2.5-flash (작동하지 않으면 gemini-2.0-flash-exp로 변경)
            google_api_key=self.api_key,
            temperature=0.7
        )
        
        # 도구 리스트 생성
        self.tools = self._create_tools()
        
        # 에이전트 생성 (LangChain v1.0 create_agent 사용)
        self.agent = self._create_agent()
        
        logger.info("여행 에이전트 초기화 완료")
    
    def _create_tools(self) -> List[Tool]:
        """사용 가능한 도구들을 생성합니다."""
        
        # 도구 함수 래퍼 (Tool은 문자열 입력을 받으므로)
        def analyze_image_wrapper(input_str: str) -> str:
            """이미지 분석 도구 래퍼"""
            return analyze_travel_image.invoke({"image_path": input_str})
        
        def search_info_wrapper(query: str) -> str:
            """검색 도구 래퍼"""
            return search_travel_info.invoke({"query": query})
        
        def search_trends_wrapper(destination: str) -> str:
            """트렌드 검색 도구 래퍼"""
            return search_recent_trends.invoke({"destination": destination})
        
        def search_restaurants_wrapper(input_str: str) -> str:
            """맛집 검색 도구 래퍼"""
            parts = input_str.split(",", 1)
            destination = parts[0].strip()
            cuisine = parts[1].strip() if len(parts) > 1 else None
            return search_restaurants.invoke({
                "destination": destination,
                "cuisine_type": cuisine
            })
        
        def search_knowledge_wrapper(query: str) -> str:
            """RAG 검색 도구 래퍼"""
            return search_travel_knowledge.invoke({"query": query})
        
        def get_dest_info_wrapper(destination: str) -> str:
            """여행지 정보 도구 래퍼"""
            return get_destination_info.invoke({"destination": destination})
        
        def generate_itinerary_wrapper(input_str: str) -> str:
            """일정 생성 도구 래퍼 - 간단한 파싱"""
            # 실제로는 더 복잡한 파싱이 필요하지만, 여기서는 기본 구현
            # 실제 사용 시에는 에이전트가 직접 generate_itinerary를 호출하도록 함
            return "일정 생성 도구는 직접 호출해야 합니다."
        
        tools = [
            Tool(
                name="analyze_travel_image",
                func=analyze_image_wrapper,
                description="""
                여행 사진을 분석하여 장소, 랜드마크, 분위기 등을 추론합니다.
                입력: 이미지 파일 경로 (예: "path/to/image.jpg")
                출력: 이미지 분석 결과 (장소 정보, 특징, 추천 활동 등)
                """
            ),
            Tool(
                name="search_travel_info",
                func=search_info_wrapper,
                description="""
                DuckDuckGo를 사용하여 여행 관련 최신 정보를 검색합니다.
                입력: 검색 쿼리 (예: "파리 최신 맛집 2024")
                출력: 검색 결과 요약
                """
            ),
            Tool(
                name="search_recent_trends",
                func=search_trends_wrapper,
                description="""
                특정 여행지의 최근 트렌드와 인기 정보를 검색합니다.
                입력: 여행지 이름 (예: "파리")
                출력: 최근 트렌드 정보
                """
            ),
            Tool(
                name="search_restaurants",
                func=search_restaurants_wrapper,
                description="""
                특정 여행지의 맛집 정보를 검색합니다.
                입력: "여행지, 음식종류" 형식 (예: "파리, 프랑스 요리") 또는 "여행지"만
                출력: 맛집 정보
                """
            ),
            Tool(
                name="search_travel_knowledge",
                func=search_knowledge_wrapper,
                description="""
                RAG 시스템에서 여행 관련 지식을 검색합니다.
                입력: 검색 쿼리 (예: "파리 관광지")
                출력: 검색된 여행 정보
                """
            ),
            Tool(
                name="get_destination_info",
                func=get_dest_info_wrapper,
                description="""
                특정 여행지의 기본 정보를 RAG에서 검색합니다.
                입력: 여행지 이름 (예: "파리")
                출력: 여행지 기본 정보
                """
            ),
            # generate_itinerary는 직접 호출 가능하도록 유지
            generate_itinerary,
        ]
        
        logger.info(f"{len(tools)}개 도구 생성 완료")
        return tools
    
    def _create_agent(self):
        """LangChain v1.0 create_agent를 사용하여 에이전트를 생성합니다."""
        try:
            # 시스템 프롬프트 정의
            system_prompt = """You are a helpful travel planning assistant. 
You help users create detailed travel itineraries by:
1. Analyzing travel images to identify locations and landmarks
2. Searching for up-to-date travel information and trends
3. Retrieving knowledge from the travel database
4. Generating detailed day-by-day travel plans

Always provide comprehensive, practical, and well-organized travel itineraries in Korean.
Include recommendations for attractions, restaurants, and activities for each day.
Consider the user's budget, preferences, and travel duration."""
            
            # LangChain v1.0 create_agent 사용 시도
            # create_agent가 존재하는지 확인
            try:
                from langchain.agents import create_agent
                agent = create_agent(
                    model=self.llm,
                    tools=self.tools,
                    system_prompt=system_prompt
                )
                logger.info("에이전트 생성 완료 (create_agent API 사용)")
                return agent
            except (ImportError, AttributeError) as import_error:
                logger.warning(f"create_agent를 사용할 수 없습니다: {import_error}")
                raise  # 폴백으로 넘어감
            
        except Exception as e:
            logger.error(f"에이전트 생성 실패: {e}")
            # 폴백: 기존 방식 사용
            logger.warning("create_agent 실패, 기존 방식으로 폴백합니다.")
            try:
                from langchain.agents import AgentExecutor, create_react_agent
                from langchain_core.prompts import PromptTemplate
                
                prompt_template = """You are a helpful travel planning assistant. You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin!

Question: {input}
Thought: {agent_scratchpad}"""
                
                prompt = PromptTemplate.from_template(prompt_template)
                react_agent = create_react_agent(self.llm, self.tools, prompt)
                agent_executor = AgentExecutor(
                    agent=react_agent,
                    tools=self.tools,
                    verbose=True,
                    handle_parsing_errors=True,
                    max_iterations=10
                )
                logger.info("폴백 에이전트 생성 완료")
                return agent_executor
            except Exception as fallback_error:
                logger.error(f"폴백 에이전트 생성도 실패: {fallback_error}")
                raise
    
    def plan_travel(
        self,
        destination: str,
        duration: int,
        budget: Optional[str] = None,
        travelers: Optional[int] = None,
        preferences: Optional[str] = None,
        image_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        여행 일정을 계획합니다.
        
        Args:
            destination: 여행지 이름
            duration: 여행 기간 (일 수)
            budget: 예산
            travelers: 동행 인원
            preferences: 선호사항
            image_path: 업로드된 이미지 경로 (선택적)
        
        Returns:
            여행 일정 및 관련 정보 딕셔너리
        """
        try:
            logger.info(f"여행 계획 시작: {destination}, {duration}일")
            
            # 사용자 요청 구성
            user_request = f"""
            다음 정보를 바탕으로 {destination} 여행 일정을 생성해주세요:
            - 여행 기간: {duration}일
            - 여행지: {destination}
            """
            
            if budget:
                user_request += f"- 예산: {budget}\n"
            if travelers:
                user_request += f"- 동행 인원: {travelers}명\n"
            if preferences:
                user_request += f"- 선호사항: {preferences}\n"
            
            user_request += """
            
            다음 단계를 수행해주세요:
            1. 먼저 get_destination_info를 사용하여 여행지 기본 정보를 수집하세요.
            2. search_recent_trends를 사용하여 최신 트렌드를 검색하세요.
            3. search_restaurants를 사용하여 맛집 정보를 검색하세요.
            4. 모든 정보를 종합하여 generate_itinerary를 사용하여 상세한 일정을 생성하세요.
            
            일정은 Day별로 구분하여 작성하고, 각 날짜별로 오전/오후/저녁 활동과 맛집 추천을 포함해주세요.
            """
            
            # 이미지가 있으면 분석 추가
            image_analysis = None
            if image_path:
                logger.info(f"이미지 분석 시작: {image_path}")
                image_analysis = analyze_travel_image.invoke({"image_path": image_path})
                user_request += f"\n\n[추가 정보 - 이미지 분석 결과]\n{image_analysis}\n이 정보도 일정 생성에 반영해주세요."
            
            # 정보 수집을 위해 에이전트 실행
            logger.info("여행 정보 수집 중...")
            info_collection_request = f"""
            {destination} 여행에 필요한 정보를 수집해주세요:
            1. get_destination_info를 사용하여 {destination}의 기본 정보를 가져오세요.
            2. search_recent_trends를 사용하여 {destination}의 최신 트렌드를 검색하세요.
            3. search_restaurants를 사용하여 {destination}의 맛집 정보를 검색하세요.
            
            수집한 정보를 요약해주세요.
            """
            
            # 에이전트 실행 (여러 방식 시도)
            collected_info = ""
            try:
                # 먼저 기존 방식 (AgentExecutor) 시도
                if hasattr(self.agent, 'invoke'):
                    # AgentExecutor는 "input" 키 사용
                    try:
                        info_result = self.agent.invoke({"input": info_collection_request})
                        if isinstance(info_result, dict):
                            collected_info = info_result.get("output", "")
                        else:
                            collected_info = str(info_result)
                    except Exception as e1:
                        logger.warning(f"AgentExecutor 방식 실패: {e1}")
                        # create_agent API 시도 (messages 형식)
                        try:
                            info_result = self.agent.invoke({
                                "messages": [
                                    {"role": "user", "content": info_collection_request}
                                ]
                            })
                            if isinstance(info_result, dict) and "messages" in info_result:
                                collected_info = info_result["messages"][-1].get("content", "")
                            elif isinstance(info_result, dict) and "output" in info_result:
                                collected_info = info_result.get("output", "")
                            else:
                                collected_info = str(info_result)
                        except Exception as e2:
                            logger.error(f"모든 에이전트 호출 방식 실패: {e2}")
                            collected_info = f"정보 수집 실패: {str(e2)}"
                else:
                    # 직접 호출
                    info_result = self.agent.invoke({"input": info_collection_request})
                    collected_info = info_result.get("output", "") if isinstance(info_result, dict) else str(info_result)
            except Exception as e:
                logger.error(f"에이전트 실행 중 오류: {e}")
                collected_info = f"정보 수집 중 오류 발생: {str(e)}"
            
            # RAG 정보 수집
            rag_info = None
            try:
                rag_info = get_destination_info.invoke({"destination": destination})
            except Exception as e:
                logger.warning(f"RAG 정보 수집 실패: {e}")
            
            # 웹 검색 결과 수집
            web_search_results = None
            try:
                web_search_results = search_recent_trends.invoke({"destination": destination})
            except Exception as e:
                logger.warning(f"웹 검색 실패: {e}")
            
            # 일정 생성
            logger.info("여행 일정 생성 중...")
            itinerary = generate_itinerary.invoke({
                "destination": destination,
                "duration": duration,
                "budget": budget,
                "travelers": travelers,
                "preferences": preferences,
                "image_analysis": image_analysis,
                "web_search_results": web_search_results,
                "rag_info": rag_info
            })
            
            logger.info("여행 계획 완료")
            
            return {
                "itinerary": itinerary,
                "image_analysis": image_analysis,
                "collected_info": collected_info,
                "destination": destination,
                "duration": duration,
                "budget": budget,
                "travelers": travelers,
                "preferences": preferences
            }
            
        except Exception as e:
            error_msg = f"여행 계획 중 오류 발생: {str(e)}"
            logger.error(error_msg)
            return {
                "error": error_msg,
                "itinerary": None
            }
    
    def chat(self, message: str) -> str:
        """
        에이전트와 대화합니다.
        
        Args:
            message: 사용자 메시지
        
        Returns:
            에이전트 응답
        """
        try:
            # create_agent는 messages 형식 사용
            if hasattr(self.agent, 'invoke'):
                try:
                    result = self.agent.invoke({
                        "messages": [
                            {"role": "user", "content": message}
                        ]
                    })
                    # 결과에서 메시지 추출
                    if isinstance(result, dict) and "messages" in result:
                        return result["messages"][-1].get("content", "응답을 생성할 수 없습니다.")
                    elif isinstance(result, dict) and "output" in result:
                        return result.get("output", "응답을 생성할 수 없습니다.")
                    else:
                        return str(result)
                except Exception as e:
                    logger.warning(f"새 API로 실행 실패, 기존 방식 시도: {e}")
                    # 기존 방식으로 폴백
                    result = self.agent.invoke({"input": message})
                    return result.get("output", "응답을 생성할 수 없습니다.") if isinstance(result, dict) else str(result)
            else:
                # AgentExecutor 사용 (폴백)
                result = self.agent.invoke({"input": message})
                return result.get("output", "응답을 생성할 수 없습니다.") if isinstance(result, dict) else str(result)
        except Exception as e:
            error_msg = f"대화 중 오류 발생: {str(e)}"
            logger.error(error_msg)
            return error_msg

