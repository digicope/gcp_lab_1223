"""
이미지 분석 도구
Gemini Vision API를 사용하여 여행 사진을 분석하고 장소를 추론합니다.
"""

import os
import base64
from typing import Optional
from pathlib import Path

import google.generativeai as genai
from langchain.tools import tool
from PIL import Image

from utils.logger import logger


@tool
def analyze_travel_image(image_path: str) -> str:
    """
    여행 사진을 분석하여 장소, 랜드마크, 분위기 등을 추론합니다.
    
    Args:
        image_path: 이미지 파일 경로
    
    Returns:
        이미지 분석 결과 (JSON 문자열 또는 텍스트)
    
    Example:
        analyze_travel_image("path/to/image.jpg")
    """
    try:
        # API 키 확인
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
        
        genai.configure(api_key=api_key)
        
        # 이미지 로드
        image_path_obj = Path(image_path)
        if not image_path_obj.exists():
            raise FileNotFoundError(f"이미지 파일을 찾을 수 없습니다: {image_path}")
        
        image = Image.open(image_path)
        
        # Gemini Vision 모델 초기화 (gemini-2.5-flash 모델 사용)
        # gemini-2.0-flash-exp는 Vision 기능도 지원합니다
        model = genai.GenerativeModel('gemini-2.0-flash-exp')  # gemini-2.5-flash
        
        # 프롬프트 구성
        prompt = """
        이 이미지를 분석하여 다음 정보를 제공해주세요:
        1. 이 장소가 어디인지 추론 (도시, 국가, 랜드마크 이름 등)
        2. 이미지에서 보이는 주요 특징 (건축물, 자연 경관, 분위기 등)
        3. 여행 활동 추천 (이 장소에서 할 수 있는 활동)
        4. 주변 맛집이나 카페 추천 가능 여부
        
        한국어로 상세하게 설명해주세요.
        """
        
        # 이미지 분석
        response = model.generate_content([prompt, image])
        
        result = response.text
        logger.info(f"이미지 분석 완료: {image_path}")
        
        return result
        
    except Exception as e:
        error_msg = f"이미지 분석 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def analyze_image_from_bytes(image_bytes: bytes, image_format: str = "JPEG") -> str:
    """
    바이트 데이터로부터 이미지를 분석합니다.
    
    Args:
        image_bytes: 이미지 바이트 데이터
        image_format: 이미지 포맷 (JPEG, PNG 등)
    
    Returns:
        이미지 분석 결과
    """
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
        
        genai.configure(api_key=api_key)
        
        # 바이트에서 이미지 생성
        from io import BytesIO
        image = Image.open(BytesIO(image_bytes))
        
        # gemini-2.5-flash 모델 사용 (Vision 기능 지원)
        model = genai.GenerativeModel('gemini-2.0-flash-exp')  # gemini-2.5-flash
        
        prompt = """
        이 이미지를 분석하여 다음 정보를 제공해주세요:
        1. 이 장소가 어디인지 추론 (도시, 국가, 랜드마크 이름 등)
        2. 이미지에서 보이는 주요 특징 (건축물, 자연 경관, 분위기 등)
        3. 여행 활동 추천 (이 장소에서 할 수 있는 활동)
        4. 주변 맛집이나 카페 추천 가능 여부
        
        한국어로 상세하게 설명해주세요.
        """
        
        response = model.generate_content([prompt, image])
        result = response.text
        logger.info("이미지 분석 완료 (바이트 데이터)")
        
        return result
        
    except Exception as e:
        error_msg = f"이미지 분석 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

