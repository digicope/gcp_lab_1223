"""
웹 검색 도구
DuckDuckGo를 사용하여 최신 여행 정보를 검색합니다.
"""

from typing import Optional
from langchain.tools import tool
from utils.logger import logger

# DuckDuckGo 검색 인스턴스 (지연 로딩)
_search_instance = None

def get_search_instance():
    """DuckDuckGo 검색 인스턴스를 가져옵니다 (지연 로딩)"""
    global _search_instance
    if _search_instance is None:
        try:
            from langchain_community.tools import DuckDuckGoSearchRun
            _search_instance = DuckDuckGoSearchRun()
        except ImportError:
            # 대체 검색 도구 사용
            logger.warning("DuckDuckGo 검색을 사용할 수 없습니다. 간단한 검색 도구를 사용합니다.")
            _search_instance = None
    return _search_instance


@tool
def search_travel_info(query: str, max_results: int = 5) -> str:
    """
    DuckDuckGo를 사용하여 여행 관련 최신 정보를 검색합니다.
    
    Args:
        query: 검색 쿼리 (예: "파리 최신 맛집 2024", "도쿄 인기 관광지")
        max_results: 최대 결과 수 (기본값: 5)
    
    Returns:
        검색 결과 요약 (텍스트)
    
    Example:
        search_travel_info("파리 최신 맛집 추천")
    """
    try:
        search = get_search_instance()
        if search is None:
            return f"'{query}'에 대한 검색 기능을 사용할 수 없습니다. DuckDuckGo 검색 패키지를 설치해주세요: pip install duckduckgo-search"
        
        # 검색 쿼리 개선
        enhanced_query = f"{query} 여행 정보"
        
        logger.info(f"웹 검색 실행: {enhanced_query}")
        result = search.run(enhanced_query)
        
        if not result or len(result.strip()) == 0:
            return f"'{query}'에 대한 검색 결과를 찾을 수 없습니다."
        
        logger.info(f"검색 완료: {len(result)}자 결과")
        return result
        
    except Exception as e:
        error_msg = f"웹 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def search_recent_trends(destination: str) -> str:
    """
    특정 여행지의 최근 트렌드와 인기 정보를 검색합니다.
    
    Args:
        destination: 여행지 이름 (예: "파리", "도쿄")
    
    Returns:
        최근 트렌드 정보
    
    Example:
        search_recent_trends("파리")
    """
    try:
        search = get_search_instance()
        if search is None:
            return f"'{destination}'의 최근 트렌드 정보를 검색할 수 없습니다. DuckDuckGo 검색 패키지를 설치해주세요."
        
        query = f"{destination} 최신 여행 트렌드 2024 인기 스팟 맛집"
        logger.info(f"트렌드 검색 실행: {destination}")
        
        result = search.run(query)
        
        if not result or len(result.strip()) == 0:
            return f"'{destination}'의 최근 트렌드 정보를 찾을 수 없습니다."
        
        logger.info(f"트렌드 검색 완료")
        return result
        
    except Exception as e:
        error_msg = f"트렌드 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def search_restaurants(destination: str, cuisine_type: Optional[str] = None) -> str:
    """
    특정 여행지의 맛집 정보를 검색합니다.
    
    Args:
        destination: 여행지 이름
        cuisine_type: 음식 종류 (선택적, 예: "한식", "일식", "프랑스 요리")
    
    Returns:
        맛집 정보
    
    Example:
        search_restaurants("파리", "프랑스 요리")
    """
    try:
        search = get_search_instance()
        if search is None:
            return f"'{destination}'의 맛집 정보를 검색할 수 없습니다. DuckDuckGo 검색 패키지를 설치해주세요."
        
        if cuisine_type:
            query = f"{destination} {cuisine_type} 맛집 추천"
        else:
            query = f"{destination} 맛집 추천"
        
        logger.info(f"맛집 검색 실행: {destination}")
        result = search.run(query)
        
        if not result or len(result.strip()) == 0:
            return f"'{destination}'의 맛집 정보를 찾을 수 없습니다."
        
        logger.info(f"맛집 검색 완료")
        return result
        
    except Exception as e:
        error_msg = f"맛집 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

