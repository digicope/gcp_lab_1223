"""
여행 일정 생성 도구
사용자 입력을 바탕으로 여행 일정을 생성합니다.
"""

import os
import json
from typing import Dict, Any, Optional
from langchain.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI

from utils.logger import logger


@tool
def generate_itinerary(
    destination: str,
    duration: int,
    budget: Optional[str] = None,
    travelers: Optional[int] = None,
    preferences: Optional[str] = None,
    image_analysis: Optional[str] = None,
    web_search_results: Optional[str] = None,
    rag_info: Optional[str] = None
) -> str:
    """
    여행 일정을 생성합니다.
    
    Args:
        destination: 여행지 이름
        duration: 여행 기간 (일 수)
        budget: 예산 (선택적)
        travelers: 동행 인원 (선택적)
        preferences: 선호사항 (선택적)
        image_analysis: 이미지 분석 결과 (선택적)
        web_search_results: 웹 검색 결과 (선택적)
        rag_info: RAG 검색 결과 (선택적)
    
    Returns:
        생성된 여행 일정 (마크다운 형식)
    
    Example:
        generate_itinerary("파리", 3, "100만원", 2, "예술과 맛집")
    """
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY가 환경 변수에 설정되지 않았습니다.")
        
        # LLM 초기화 (gemini-2.5-flash 모델 사용)
        llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash-exp",  # gemini-2.5-flash (작동하지 않으면 gemini-2.0-flash-exp로 변경)
            google_api_key=api_key,
            temperature=0.7
        )
        
        # 프롬프트 구성
        prompt_parts = [
            f"다음 정보를 바탕으로 {destination} 여행 일정을 생성해주세요:\n",
            f"- 여행 기간: {duration}일\n",
            f"- 여행지: {destination}\n"
        ]
        
        if budget:
            prompt_parts.append(f"- 예산: {budget}\n")
        if travelers:
            prompt_parts.append(f"- 동행 인원: {travelers}명\n")
        if preferences:
            prompt_parts.append(f"- 선호사항: {preferences}\n")
        
        prompt_parts.append("\n")
        
        # 추가 정보가 있으면 포함
        if image_analysis:
            prompt_parts.append(f"[이미지 분석 결과]\n{image_analysis}\n\n")
        
        if rag_info:
            prompt_parts.append(f"[기본 여행 정보]\n{rag_info}\n\n")
        
        if web_search_results:
            prompt_parts.append(f"[최신 여행 정보]\n{web_search_results}\n\n")
        
        prompt_parts.append("""
다음 형식으로 일정을 작성해주세요:

# {destination} {duration}일 여행 일정

## Day 1
- 오전: [활동]
- 오후: [활동]
- 저녁: [맛집 추천]

## Day 2
- 오전: [활동]
- 오후: [활동]
- 저녁: [맛집 추천]

## Day 3
...

## 예산 요약
- 숙박: [예상 비용]
- 식사: [예상 비용]
- 관광: [예상 비용]
- 기타: [예상 비용]

## 추천 팁
[여행 팁과 주의사항]

한국어로 상세하고 실용적인 일정을 작성해주세요.
        """)
        
        prompt = "".join(prompt_parts)
        
        # 빈 프롬프트 체크
        if not prompt or not prompt.strip():
            raise ValueError("프롬프트가 비어있습니다.")
        
        logger.info(f"일정 생성 시작: {destination}, {duration}일")
        
        # 일정 생성 (메시지 형식으로 전달)
        try:
            # LangChain의 ChatGoogleGenerativeAI는 문자열도 받을 수 있지만, 
            # 메시지 형식으로 명시적으로 전달
            from langchain_core.messages import HumanMessage
            messages = [HumanMessage(content=prompt)]
            response = llm.invoke(messages)
        except Exception as e:
            # 폴백: 문자열 직접 전달
            logger.warning(f"메시지 형식 호출 실패, 문자열로 재시도: {e}")
            response = llm.invoke(prompt)
        
        # 응답 처리
        if hasattr(response, 'content'):
            itinerary = response.content
        elif isinstance(response, str):
            itinerary = response
        else:
            itinerary = str(response)
        
        logger.info("일정 생성 완료")
        
        return itinerary
        
    except Exception as e:
        error_msg = f"일정 생성 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def format_itinerary_json(itinerary_text: str) -> str:
    """
    텍스트 일정을 JSON 형식으로 변환합니다.
    
    Args:
        itinerary_text: 마크다운 형식의 일정 텍스트
    
    Returns:
        JSON 형식의 일정
    """
    try:
        # 간단한 파싱 (실제로는 더 정교한 파싱이 필요할 수 있음)
        # 여기서는 기본 구조만 제공
        result = {
            "format": "markdown",
            "content": itinerary_text
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        error_msg = f"일정 포맷 변환 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

