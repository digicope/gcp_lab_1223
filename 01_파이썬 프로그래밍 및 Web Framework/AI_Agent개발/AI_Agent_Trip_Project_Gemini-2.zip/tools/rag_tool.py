"""
RAG 검색 도구
벡터 데이터베이스에서 여행 관련 정보를 검색합니다.
"""

from typing import Optional
from langchain.tools import tool
from langchain_community.vectorstores import Chroma

from rag.rag_init import initialize_rag
from utils.logger import logger


# 전역 벡터 스토어 (초기화 시 한 번만 로드)
_vectorstore: Optional[Chroma] = None


def get_vectorstore() -> Chroma:
    """벡터 스토어를 가져옵니다 (싱글톤 패턴)"""
    global _vectorstore
    if _vectorstore is None:
        _vectorstore = initialize_rag()
    return _vectorstore


@tool
def search_travel_knowledge(query: str, k: int = 3) -> str:
    """
    RAG 시스템에서 여행 관련 지식을 검색합니다.
    
    Args:
        query: 검색 쿼리 (예: "파리 관광지", "도쿄 맛집")
        k: 반환할 문서 수 (기본값: 3)
    
    Returns:
        검색된 여행 정보 (텍스트)
    
    Example:
        search_travel_knowledge("파리 주요 관광지")
    """
    try:
        vectorstore = get_vectorstore()
        
        logger.info(f"RAG 검색 실행: {query}")
        
        # 유사도 검색
        docs = vectorstore.similarity_search(query, k=k)
        
        if not docs:
            return f"'{query}'에 대한 정보를 찾을 수 없습니다."
        
        # 검색 결과 결합
        results = []
        for i, doc in enumerate(docs, 1):
            content = doc.page_content.strip()
            source = doc.metadata.get("source", "unknown")
            results.append(f"[정보 {i} - 출처: {source}]\n{content}\n")
        
        combined_result = "\n---\n".join(results)
        logger.info(f"RAG 검색 완료: {len(docs)}개 문서 반환")
        
        return combined_result
        
    except Exception as e:
        error_msg = f"RAG 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def get_destination_info(destination: str) -> str:
    """
    특정 여행지의 기본 정보를 RAG에서 검색합니다.
    
    Args:
        destination: 여행지 이름 (예: "파리", "도쿄", "서울")
    
    Returns:
        여행지 정보
    
    Example:
        get_destination_info("파리")
    """
    try:
        query = f"{destination} 여행 가이드 관광지 추천"
        return search_travel_knowledge(query, k=2)
        
    except Exception as e:
        error_msg = f"여행지 정보 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

