# PowerShell 스크립트: Anaconda3 Python을 사용하여 Streamlit 실행
# 사용법: .\run_streamlit.ps1

# Anaconda3 Python 경로 설정
$anacondaPython = "$env:USERPROFILE\anaconda3\python.exe"

# 경로가 존재하는지 확인
if (-not (Test-Path $anacondaPython)) {
    Write-Host "Anaconda3 Python을 찾을 수 없습니다: $anacondaPython" -ForegroundColor Yellow
    Write-Host "다른 경로를 찾는 중..." -ForegroundColor Yellow
    
    # 다른 일반적인 Anaconda 경로 확인
    $possiblePaths = @(
        "C:\anaconda3\python.exe",
        "C:\ProgramData\anaconda3\python.exe",
        "$env:LOCALAPPDATA\anaconda3\python.exe"
    )
    
    $found = $false
    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            $anacondaPython = $path
            $found = $true
            break
        }
    }
    
    if (-not $found) {
        Write-Host "Anaconda3를 찾을 수 없습니다. 수동으로 경로를 설정해주세요." -ForegroundColor Red
        Read-Host "아무 키나 눌러 종료"
        exit 1
    }
}

Write-Host "Anaconda3 Python 사용: $anacondaPython" -ForegroundColor Green
Write-Host "Python 버전 확인:" -ForegroundColor Cyan
& $anacondaPython --version

Write-Host "`nStreamlit 실행 중..." -ForegroundColor Cyan
& $anacondaPython -m streamlit run app.py

