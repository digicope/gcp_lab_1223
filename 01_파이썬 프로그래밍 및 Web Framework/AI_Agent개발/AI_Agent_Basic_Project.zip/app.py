"""
Streamlit 기반 멀티모달 AI 에이전트 챗봇 UI
- 이미지 업로드 및 분석
- 텍스트 입력 및 처리
- RAG 기반 문서 검색
- 에이전트 도구 자동 실행
"""

import streamlit as st
import os
import tempfile
from pathlib import Path
from dotenv import load_dotenv
from agent.agent_builder import build_agent, analyze_image_with_agent, run_agent_with_text
from agent.rag_store import initialize_rag_store

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 페이지 설정
st.set_page_config(
    page_title="멀티모달 AI 에이전트",
    page_icon="🤖",
    layout="wide"
)

# 세션 상태 초기화
if "agent" not in st.session_state:
    st.session_state.agent = None
if "rag_initialized" not in st.session_state:
    st.session_state.rag_initialized = False
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []


def initialize_system():
    """시스템 초기화: RAG 저장소 및 에이전트 생성"""
    if not st.session_state.rag_initialized:
        with st.spinner("RAG 저장소 초기화 중..."):
            initialize_rag_store()
            st.session_state.rag_initialized = True
    
    if st.session_state.agent is None:
        with st.spinner("에이전트 생성 중..."):
            st.session_state.agent = build_agent()
            st.success("에이전트가 준비되었습니다!")


def main():
    """메인 애플리케이션"""
    st.title("🤖 멀티모달 AI 에이전트 챗봇")
    st.markdown("---")
    
    # 시스템 초기화
    initialize_system()
    
    # 사이드바
    with st.sidebar:
        st.header("📋 기능")
        st.markdown("""
        이 에이전트는 다음 기능을 제공합니다:
        
        1. **이미지 분석**: 업로드한 이미지를 분석하고 설명합니다
        2. **문서 검색**: RAG 기반으로 저장된 문서를 검색합니다
        3. **문서 요약**: 긴 텍스트를 간결하게 요약합니다
        4. **키워드 추출**: 텍스트에서 핵심 키워드를 추출합니다
        
        에이전트가 자동으로 적절한 도구를 선택하여 사용합니다.
        """)
        
        st.markdown("---")
        
        # 초기화 버튼
        if st.button("🔄 시스템 재초기화"):
            st.session_state.agent = None
            st.session_state.rag_initialized = False
            st.session_state.chat_history = []
            st.rerun()
    
    # 메인 컨텐츠 영역
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("💬 대화")
        
        # 채팅 히스토리 표시
        chat_container = st.container()
        with chat_container:
            for idx, (role, content) in enumerate(st.session_state.chat_history):
                if role == "user":
                    with st.chat_message("user"):
                        st.write(content)
                else:
                    with st.chat_message("assistant"):
                        st.write(content)
        
        st.markdown("---")
        
        # 입력 영역
        input_method = st.radio(
            "입력 방식 선택:",
            ["텍스트 입력", "이미지 업로드"],
            horizontal=True
        )
        
        if input_method == "텍스트 입력":
            user_input = st.text_area(
                "메시지를 입력하세요:",
                height=100,
                placeholder="예: '인공지능에 대해 검색해줘', '다음 텍스트를 요약해줘: ...', '이 문서의 키워드를 추출해줘' 등"
            )
            
            if st.button("📤 전송", type="primary"):
                if user_input.strip():
                    # 사용자 메시지 추가
                    st.session_state.chat_history.append(("user", user_input))
                    
                    # 에이전트 실행
                    with st.spinner("에이전트가 작업 중입니다..."):
                        try:
                            response = run_agent_with_text(
                                st.session_state.agent,
                                user_input
                            )
                            st.session_state.chat_history.append(("assistant", response))
                        except Exception as e:
                            error_msg = f"오류 발생: {str(e)}"
                            st.session_state.chat_history.append(("assistant", error_msg))
                            st.error(error_msg)
                    
                    st.rerun()
        
        else:  # 이미지 업로드
            uploaded_file = st.file_uploader(
                "이미지를 업로드하세요:",
                type=["png", "jpg", "jpeg", "gif", "bmp"],
                help="PNG, JPG, JPEG, GIF, BMP 형식을 지원합니다."
            )
            
            if uploaded_file is not None:
                # 이미지 미리보기 (Streamlit 1.37.1 버전 호환)
                st.image(uploaded_file, caption="업로드된 이미지")
                
                # 이미지 분석 쿼리 입력
                image_query = st.text_input(
                    "이미지에 대해 무엇을 알고 싶으신가요?",
                    value="이 이미지를 분석하고 설명해주세요.",
                    placeholder="예: 이 이미지의 주요 내용을 설명해주세요."
                )
                
                if st.button("🔍 이미지 분석", type="primary"):
                    if image_query.strip():
                        # 임시 파일로 저장
                        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
                            tmp_file.write(uploaded_file.getvalue())
                            tmp_path = tmp_file.name
                        
                        try:
                            # 사용자 메시지 추가
                            st.session_state.chat_history.append(("user", f"[이미지 업로드] {image_query}"))
                            
                            # 이미지 분석 실행
                            with st.spinner("이미지 분석 중..."):
                                response = analyze_image_with_agent(
                                    st.session_state.agent,
                                    tmp_path,
                                    image_query
                                )
                                st.session_state.chat_history.append(("assistant", response))
                            
                            # 임시 파일 삭제
                            os.unlink(tmp_path)
                            
                        except Exception as e:
                            error_msg = f"이미지 분석 중 오류 발생: {str(e)}"
                            st.session_state.chat_history.append(("assistant", error_msg))
                            st.error(error_msg)
                            if os.path.exists(tmp_path):
                                os.unlink(tmp_path)
                        
                        st.rerun()
    
    with col2:
        st.header("📚 도구 정보")
        st.markdown("""
        ### 사용 가능한 도구:
        
        **1. search_docs(query)**
        - RAG 기반 문서 검색
        - 저장된 문서에서 관련 내용 검색
        
        **2. summarize_doc(text)**
        - 텍스트 요약
        - 긴 문서를 간결하게 요약
        
        **3. extract_keywords(text)**
        - 핵심 키워드 추출
        - 텍스트에서 중요한 키워드 추출
        
        ### 사용 예시:
        - "인공지능에 대해 검색해줘"
        - "다음 텍스트를 요약해줘: [텍스트]"
        - "이 문서의 키워드를 추출해줘"
        - "이미지를 분석해줘"
        """)
        
        st.markdown("---")
        
        # 채팅 히스토리 초기화 버튼
        if st.button("🗑️ 대화 기록 삭제"):
            st.session_state.chat_history = []
            st.rerun()


if __name__ == "__main__":
    main()

