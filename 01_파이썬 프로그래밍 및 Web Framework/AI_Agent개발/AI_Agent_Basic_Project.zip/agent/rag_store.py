"""
RAG 저장소 초기화 및 검색 기능 구현
OpenAI Embeddings를 사용하여 문서를 임베딩하고 검색 가능하게 만듦
"""

import os
from pathlib import Path
from typing import List
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 전역 변수로 vectorstore 저장
_vectorstore = None


def initialize_rag_store(data_dir: str = "data/samples") -> Chroma:
    """
    RAG 저장소 초기화
    data/samples 폴더의 문서들을 로드하고 임베딩하여 벡터 스토어 생성
    
    Args:
        data_dir: 샘플 문서가 있는 디렉토리 경로
        
    Returns:
        Chroma: 초기화된 벡터 스토어
    """
    global _vectorstore
    
    # 이미 초기화된 경우 재사용
    if _vectorstore is not None:
        return _vectorstore
    
    # OpenAI Embeddings 초기화 (text-embedding-3-small 모델 사용)
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    
    # 문서 로더 및 텍스트 분할기 초기화
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len,
    )
    
    # 모든 문서 로드
    documents = []
    data_path = Path(data_dir)
    
    if not data_path.exists():
        print(f"경고: {data_dir} 디렉토리가 존재하지 않습니다.")
        # 빈 벡터 스토어 생성
        _vectorstore = Chroma(embedding_function=embeddings)
        return _vectorstore
    
    # txt 파일 찾기
    txt_files = list(data_path.glob("*.txt"))
    
    if not txt_files:
        print(f"경고: {data_dir}에 txt 파일이 없습니다.")
        _vectorstore = Chroma(embedding_function=embeddings)
        return _vectorstore
    
    # 각 파일 로드 및 처리
    for file_path in txt_files:
        try:
            loader = TextLoader(str(file_path), encoding='utf-8')
            loaded_docs = loader.load()
            # 문서 분할
            split_docs = text_splitter.split_documents(loaded_docs)
            documents.extend(split_docs)
            print(f"로드 완료: {file_path.name} ({len(split_docs)} 청크)")
        except Exception as e:
            print(f"오류: {file_path} 로드 실패 - {e}")
    
    # 벡터 스토어 생성 (메모리 기반)
    if documents:
        _vectorstore = Chroma.from_documents(
            documents=documents,
            embedding=embeddings,
        )
        print(f"RAG 저장소 초기화 완료: {len(documents)}개 청크 저장됨")
    else:
        _vectorstore = Chroma(embedding_function=embeddings)
        print("RAG 저장소 초기화 완료 (문서 없음)")
    
    return _vectorstore


def search_documents(query: str, k: int = 3) -> List[dict]:
    """
    RAG 기반 문서 검색
    
    Args:
        query: 검색 쿼리
        k: 반환할 문서 수
        
    Returns:
        List[dict]: 검색 결과 리스트 (content, metadata 포함)
    """
    global _vectorstore
    
    # 벡터 스토어가 초기화되지 않았으면 초기화
    if _vectorstore is None:
        _vectorstore = initialize_rag_store()
    
    try:
        # 유사도 검색 수행
        results = _vectorstore.similarity_search_with_score(query, k=k)
        
        # 결과 포맷팅
        formatted_results = []
        for doc, score in results:
            formatted_results.append({
                "content": doc.page_content,
                "metadata": doc.metadata,
                "score": float(score)
            })
        
        return formatted_results
    except Exception as e:
        print(f"문서 검색 오류: {e}")
        return []


def get_rag_store() -> Chroma:
    """
    현재 벡터 스토어 반환 (이미 초기화된 경우)
    
    Returns:
        Chroma: 벡터 스토어
    """
    global _vectorstore
    if _vectorstore is None:
        _vectorstore = initialize_rag_store()
    return _vectorstore

