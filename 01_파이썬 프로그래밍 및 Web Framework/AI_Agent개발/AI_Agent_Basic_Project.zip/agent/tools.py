"""
에이전트가 사용할 도구(Tools) 구현
- summarize_doc: 문서 요약
- extract_keywords: 핵심 키워드 추출
- search_docs: RAG 기반 문서 검색
"""

from typing import List, Dict
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from agent.rag_store import search_documents

# 환경 변수 로드
load_dotenv("C:/env/.env")

# LLM 초기화 (도구에서 사용)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)


@tool
def summarize_doc(text: str) -> str:
    """
    주어진 텍스트를 요약하는 도구
    
    Args:
        text: 요약할 텍스트
        
    Returns:
        str: 요약된 텍스트
    """
    try:
        prompt = f"""다음 텍스트를 간결하고 핵심적인 내용만 요약해주세요.
        
텍스트:
{text}

요약:"""
        
        # LangChain v1.0 형식: 메시지 리스트로 전달
        response = llm.invoke([{"role": "user", "content": prompt}])
        # response.content 또는 response.text 접근
        if hasattr(response, 'content'):
            return response.content
        elif hasattr(response, 'text'):
            return response.text
        else:
            return str(response)
    except Exception as e:
        return f"요약 중 오류 발생: {str(e)}"


@tool
def extract_keywords(text: str) -> str:
    """
    주어진 텍스트에서 핵심 키워드를 추출하는 도구
    
    Args:
        text: 키워드를 추출할 텍스트
        
    Returns:
        str: 추출된 키워드들 (쉼표로 구분)
    """
    try:
        prompt = f"""다음 텍스트에서 가장 중요한 핵심 키워드 5-10개를 추출해주세요.
키워드는 쉼표로 구분하여 나열해주세요.

텍스트:
{text}

핵심 키워드:"""
        
        # LangChain v1.0 형식: 메시지 리스트로 전달
        response = llm.invoke([{"role": "user", "content": prompt}])
        # response.content 또는 response.text 접근
        if hasattr(response, 'content'):
            return response.content
        elif hasattr(response, 'text'):
            return response.text
        else:
            return str(response)
    except Exception as e:
        return f"키워드 추출 중 오류 발생: {str(e)}"


@tool
def search_docs(query: str) -> str:
    """
    RAG 기반으로 저장된 문서를 검색하는 도구
    
    Args:
        query: 검색 쿼리
        
    Returns:
        str: 검색 결과 요약
    """
    try:
        # RAG 저장소에서 검색
        results = search_documents(query, k=3)
        
        if not results:
            return f"'{query}'에 대한 검색 결과를 찾을 수 없습니다."
        
        # 검색 결과 포맷팅
        formatted_results = []
        for idx, result in enumerate(results, 1):
            content = result["content"][:500]  # 처음 500자만 표시
            score = result["score"]
            formatted_results.append(
                f"[결과 {idx}] (유사도 점수: {score:.3f})\n{content}\n"
            )
        
        return "\n".join(formatted_results)
    except Exception as e:
        return f"문서 검색 중 오류 발생: {str(e)}"


# 모든 도구를 리스트로 export
def get_all_tools():
    """
    모든 도구를 리스트로 반환
    
    Returns:
        List: 도구 리스트
    """
    return [summarize_doc, extract_keywords, search_docs]

