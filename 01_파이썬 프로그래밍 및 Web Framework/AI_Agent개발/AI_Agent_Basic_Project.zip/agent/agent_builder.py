"""
에이전트 빌더: LangChain v1.0의 create_agent를 사용하여 멀티모달 AI 에이전트 생성
"""

from langchain.agents import create_agent
from dotenv import load_dotenv
from agent.tools import get_all_tools

# 환경 변수 로드
load_dotenv("C:/env/.env")


def build_agent():
    """
    멀티모달 AI 에이전트 생성
    - 이미지 분석 기능 포함
    - RAG 검색 도구 포함
    - 문서 요약 및 키워드 추출 도구 포함
    
    Returns:
        RunnableAgent: 생성된 에이전트
    """
    # 모든 도구 가져오기
    tools = get_all_tools()
    
    # 프롬프트 템플릿 정의
    system_prompt = """당신은 멀티모달 AI 에이전트입니다. 다음 기능을 수행할 수 있습니다:

1. 이미지 분석: 사용자가 업로드한 이미지를 분석하고 설명 또는 캡션을 생성할 수 있습니다.
2. 문서 검색: RAG 기반으로 저장된 문서를 검색할 수 있습니다 (search_docs 도구 사용).
3. 문서 요약: 긴 텍스트를 간결하게 요약할 수 있습니다 (summarize_doc 도구 사용).
4. 키워드 추출: 텍스트에서 핵심 키워드를 추출할 수 있습니다 (extract_keywords 도구 사용).

사용자의 입력을 분석하여 적절한 도구를 자동으로 선택하고 실행하세요.
이미지가 포함된 경우 이미지 내용을 분석하여 설명해주세요.
문서 검색이 필요한 경우 search_docs 도구를 사용하세요.
텍스트 요약이나 키워드 추출이 요청되면 해당 도구를 사용하세요.

응답은 친절하고 명확하게 작성하세요."""
    
    # 에이전트 생성 (LangChain v1.0의 create_agent 사용)
    # model 파라미터에 OpenAI 모델명 전달
    agent = create_agent(
        model="openai:gpt-4o-mini",
        tools=tools,
        system_prompt=system_prompt,
    )
    
    return agent


def analyze_image_with_agent(agent, image_path: str, user_query: str = "이 이미지를 분석하고 설명해주세요.") -> str:
    """
    에이전트를 사용하여 이미지 분석
    
    Args:
        agent: 에이전트 인스턴스
        image_path: 이미지 파일 경로
        user_query: 사용자 쿼리
        
    Returns:
        str: 이미지 분석 결과
    """
    # 이미지를 base64로 인코딩
    import base64
    from PIL import Image
    import io
    
    try:
        # 이미지 파일 읽기
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
        
        # base64 인코딩
        base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # MIME 타입 결정
        image = Image.open(io.BytesIO(image_data))
        mime_type = f"image/{image.format.lower()}" if image.format else "image/jpeg"
        
        # 메시지 생성 (이미지 포함) - LangChain v1.0 형식
        # 멀티모달 메시지 형식
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": user_query
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{mime_type};base64,{base64_image}"
                        }
                    }
                ]
            }
        ]
        
        # 에이전트 실행
        result = agent.invoke({
            "messages": messages
        })
        
        # 마지막 메시지의 content 반환
        if result and "messages" in result and len(result["messages"]) > 0:
            last_message = result["messages"][-1]
            # content가 문자열인 경우
            if isinstance(last_message.content, str):
                return last_message.content
            # content가 리스트인 경우 (멀티모달)
            elif isinstance(last_message.content, list):
                text_content = ""
                for item in last_message.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_content += item.get("text", "")
                return text_content if text_content else str(last_message.content)
            else:
                return str(last_message.content)
        else:
            return "이미지 분석 결과를 가져올 수 없습니다."
            
    except Exception as e:
        return f"이미지 분석 중 오류 발생: {str(e)}"


def run_agent_with_text(agent, user_input: str) -> str:
    """
    텍스트 입력으로 에이전트 실행
    
    Args:
        agent: 에이전트 인스턴스
        user_input: 사용자 입력 텍스트
        
    Returns:
        str: 에이전트 응답
    """
    try:
        # 메시지 생성 (LangChain v1.0 형식)
        messages = [
            {
                "role": "user",
                "content": user_input
            }
        ]
        
        # 에이전트 실행
        result = agent.invoke({
            "messages": messages
        })
        
        # 마지막 메시지의 content 반환
        if result and "messages" in result and len(result["messages"]) > 0:
            last_message = result["messages"][-1]
            # content가 문자열인 경우
            if isinstance(last_message.content, str):
                return last_message.content
            # content가 리스트인 경우
            elif isinstance(last_message.content, list):
                text_content = ""
                for item in last_message.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_content += item.get("text", "")
                return text_content if text_content else str(last_message.content)
            else:
                return str(last_message.content)
        else:
            return "응답을 생성할 수 없습니다."
            
    except Exception as e:
        return f"에이전트 실행 중 오류 발생: {str(e)}"

