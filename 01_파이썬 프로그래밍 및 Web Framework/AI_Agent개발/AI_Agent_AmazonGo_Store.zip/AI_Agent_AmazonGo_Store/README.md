# 🏪 무인 점포 AI 에이전트 (Amazon Go Simulation)

카메라로 촬영한 영상 또는 실시간 스트림을 분석하여 고객의 상품 선택(Pick) 동작을 감지하고, 자동으로 장바구니에 추가하여 총액을 계산하는 무인 점포 AI 시스템입니다.

## 📌 주요 기능

1. **사람 검출**: 영상에서 사람을 감지합니다.
2. **손/팔 영역 추적**: 손의 위치를 실시간으로 추적합니다.
3. **상품 선반 인식**: 미리 정의된 선반 영역을 인식합니다.
4. **Pick/Put 판정**: "집었다(Pick)" vs "놓았다(Put)" 동작을 판단합니다.
5. **자동 장바구니 추가**: Pick된 상품을 자동으로 장바구니에 추가합니다.
6. **금액 자동 계산**: 장바구니의 총액을 자동으로 계산합니다.
7. **LangChain Agent**: LangChain의 `create_agent()`를 활용한 워크플로우 제어
8. **Streamlit UI**: 실시간 모니터링을 위한 웹 인터페이스

## 📁 프로젝트 구조

```
AI_Agent_AmazonGo_Store/
├── app.py                 # Streamlit UI 메인 애플리케이션
├── agent.py               # LangChain create_agent() 에이전트
├── vision_core.py         # 영상 처리 및 Pick/Put 판정 핵심 로직
├── product_db.py          # 상품 정보 및 선반 위치 데이터베이스
├── utils.py               # 프레임 변환 및 디버그 유틸리티 함수
├── requirements.txt       # Python 패키지 의존성
├── README.md             # 프로젝트 설명서
└── .env                  # 환경 변수 (OPENAI_API_KEY 등)
```

## 🚀 설치 방법

### 1. 저장소 클론 또는 파일 다운로드

```bash
cd AI_Agent_AmazonGo_Store
```

### 2. Python 가상 환경 생성 (권장)

```bash
python -m venv venv
```

- Windows:
```bash
venv\Scripts\activate
```

- macOS/Linux:
```bash
source venv/bin/activate
```

### 3. 필요한 패키지 설치

```bash
pip install -r requirements.txt
```

### 4. 환경 변수 설정

프로젝트 루트에 `.env` 파일을 생성하고 OpenAI API 키를 추가합니다:

```env
OPENAI_API_KEY=your_openai_api_key_here
```

## 🎮 실행 방법

### Streamlit 애플리케이션 실행

```bash
streamlit run app.py
```

브라우저가 자동으로 열리며 `http://localhost:8501`에서 애플리케이션을 확인할 수 있습니다.

## 📘 사용 시나리오

### 시나리오 1: 영상 분석 및 자동 장바구니 추가

1. **영상 업로드**
   - Streamlit UI에서 "상품을 집는 장면이 포함된 영상" 업로드
   - 지원 형식: MP4, MOV, AVI, MKV

2. **영상 분석**
   - "영상 분석하기" 버튼 클릭
   - AI 에이전트가 자동으로:
     - 프레임을 추출하여 손의 위치를 감지
     - 손이 선반 영역에 들어갔는지 확인
     - Pick 동작을 판정하여 상품 식별
     - 감지된 상품을 장바구니에 자동 추가

3. **장바구니 확인**
   - 우측 패널에서 장바구니 내용 확인
   - 총액 자동 계산 표시

### 시나리오 2: 수동 장바구니 관리

```python
from agent import run_agent

# 상품 추가
run_agent("장바구니에 chips를 추가해라.")

# 총액 확인
run_agent("장바구니 총액을 계산해라.")

# 장바구니 비우기
run_agent("장바구니를 비워라.")
```

## 📦 구성 파일 설명

### `app.py` - Streamlit UI
- 영상 업로드 인터페이스
- 영상 분석 버튼 및 결과 표시
- 장바구니 상태 실시간 모니터링
- 총액 계산 및 관리 기능

### `agent.py` - LangChain 에이전트
- `analyze_video(video_path)`: 영상 분석 도구
- `add_to_cart(product)`: 장바구니 추가 도구
- `get_cart_total()`: 총액 계산 도구
- `clear_cart()`: 장바구니 비우기 도구
- `get_cart_items()`: 장바구니 목록 조회 도구

### `vision_core.py` - 영상 처리 핵심
- `extract_frames()`: 영상에서 프레임 추출
- `detect_hand_zone()`: OpenAI Vision API를 사용한 손 위치 감지
- `determine_pick()`: 이전 프레임과 현재 프레임 비교하여 Pick 판정
- `analyze_video_picks()`: 영상 전체 분석하여 Pick된 상품 리스트 반환

### `product_db.py` - 상품 데이터베이스
- `PRODUCTS`: 상품 이름 및 가격 딕셔너리
- `SHELF_ZONES`: 선반 위치 좌표 (x1, y1, x2, y2)
- `get_price()`: 상품 가격 조회
- `get_shelf_zone()`: 선반 영역 조회
- `check_hand_in_shelf()`: 손이 선반 영역에 있는지 확인

### `utils.py` - 유틸리티 함수
- `draw_bbox_on_frame()`: 프레임에 bbox 그리기
- `draw_shelf_zones()`: 선반 영역 시각화
- `resize_frame()`: 프레임 크기 조정
- `frames_to_video()`: 프레임 리스트를 영상으로 변환

## ⚙️ 동작 원리

### 1. 프레임 추출
- OpenCV를 사용하여 영상에서 일정 간격(skip=5)으로 프레임 추출

### 2. 손 감지
- OpenAI Vision API (gpt-4o-mini)를 사용하여 각 프레임에서 손의 위치를 감지
- 손의 bounding box 좌표 (x1, y1, x2, y2) 반환

### 3. Pick 판정
- 이전 프레임과 현재 프레임을 비교
- 손이 선반 영역에 들어갔는지 확인 (`check_hand_in_shelf()`)
- 선반 영역 변화를 감지하여 Pick 동작 판정

### 4. 상품 식별
- 손이 위치한 선반 영역에 해당하는 상품을 자동으로 식별
- `SHELF_ZONES` 딕셔너리를 참조하여 상품 매핑

### 5. 자동 장바구니 추가
- LangChain 에이전트가 감지된 상품을 자동으로 장바구니에 추가
- `add_to_cart()` 도구를 사용하여 장바구니 관리

## 🔧 커스터마이징

### 상품 및 가격 변경

`product_db.py` 파일에서 상품 정보를 수정할 수 있습니다:

```python
PRODUCTS = {
    "chips": 2000,
    "cola": 1500,
    "water": 1000,
    "sandwich": 3500,
    "new_product": 5000  # 새 상품 추가
}
```

### 선반 위치 조정

카메라 영상의 실제 좌표에 맞게 선반 위치를 조정하세요:

```python
SHELF_ZONES = {
    "chips": (50, 100, 250, 300),    # (x1, y1, x2, y2)
    "cola": (300, 100, 500, 300),
    # ...
}
```

### 프레임 추출 간격 조정

`vision_core.py`의 `extract_frames()` 함수에서 `skip` 파라미터를 조정:

```python
frames = extract_frames(video_path, skip=10)  # 더 적은 프레임 추출 (빠른 처리)
```

## 🐛 문제 해결

### OpenAI API 키 오류
- `.env` 파일에 `OPENAI_API_KEY`가 올바르게 설정되었는지 확인
- API 키가 유효한지 확인

### 영상 파일을 열 수 없음
- 지원되는 형식(MP4, MOV, AVI, MKV)인지 확인
- 파일 경로가 올바른지 확인

### 손 감지 실패
- 영상의 품질 및 조명 상태 확인
- 손이 명확하게 보이는 영상 사용 권장

## 📝 라이센스

이 프로젝트는 교육 및 연구 목적으로 제작되었습니다.

## 🤝 기여

버그 리포트 및 기능 제안은 언제든 환영합니다!

## 📧 문의

프로젝트 관련 문의사항이 있으시면 이슈를 등록해주세요.

---

**참고**: 이 프로젝트는 Amazon Go 스타일의 무인 점포 시뮬레이션으로, 실제 상용 시스템과는 차이가 있을 수 있습니다.

