"""
상품 데이터베이스 및 선반 위치 정보 관리 모듈
"""

# 상품 이름 및 가격 정보
PRODUCTS = {
    "cola": 1500,
    "water": 1000,
    "sandwich": 3500,
    "eye_drop": 5000,  # 점안액
    "pen": 1000,  # 볼펜
    "charger": 5000,  # 충전기
    "toothpaste": 2000  # 치약
}

# 상품 인식용 한국어 이름 매핑
PRODUCT_NAMES_KR = {
    "cola": "콜라",
    "water": "생수 500ml",
    "sandwich": "샌드위치",
    "eye_drop": "점안액",
    "pen": "볼펜",
    "charger": "충전기",
    "toothpaste": "치약"
}

# 상품 인식용 영어 이름 매핑 (Vision API가 인식할 수 있는 이름)
PRODUCT_NAMES_EN = {
    "cola": ["cola", "coke", "soft drink", "soda", "carbonated drink"],
    "water": ["water", "bottled water", "water bottle", "drinking water", "500ml water", "500ml bottled water", "500ml", "mineral water", "purified water", "spring water", "bottle of water"],
    "sandwich": ["sandwich", "sub sandwich", "sandwich roll"],
    "eye_drop": ["eye drop", "eye drops", "eye solution", "eye medicine", "ophthalmic solution"],
    "pen": ["pen", "ballpoint pen", "writing pen", "ball pen"],
    "charger": ["charger", "phone charger", "charging cable", "USB charger", "cable charger"],
    "toothpaste": ["toothpaste", "tooth paste", "dental paste", "oral paste", "toothpaste tube", "tube toothpaste", "toothpaste in tube", "tooth paste tube", "dental tube", "paste tube"]
}

def get_price(product: str) -> int:
    """
    상품 이름으로 가격 조회
    
    Args:
        product: 상품 이름
        
    Returns:
        가격 (원), 상품이 없으면 -1
    """
    return PRODUCTS.get(product, -1)

def get_product_name_kr(product: str) -> str:
    """
    상품의 한국어 이름 조회
    
    Args:
        product: 상품 이름 (영어)
        
    Returns:
        한국어 상품 이름
    """
    return PRODUCT_NAMES_KR.get(product, product)

def get_product_names_en(product: str) -> list:
    """
    상품의 영어 인식 이름 리스트 조회
    
    Args:
        product: 상품 이름 (영어)
        
    Returns:
        인식 가능한 영어 이름 리스트
    """
    return PRODUCT_NAMES_EN.get(product, [product])

def get_all_products() -> list:
    """
    모든 상품 목록 반환
    
    Returns:
        상품 이름 리스트
    """
    return list(PRODUCTS.keys())

def check_hand_in_shelf(hand_bbox: tuple, shelf_zone: tuple) -> bool:
    """
    손의 bbox가 선반 영역과 겹치는지 확인
    
    Args:
        hand_bbox: 손의 bbox (x1, y1, x2, y2)
        shelf_zone: 선반 영역 (x1, y1, x2, y2)
        
    Returns:
        겹치면 True, 아니면 False
    """
    if not hand_bbox or not shelf_zone:
        return False
    
    hx1, hy1, hx2, hy2 = hand_bbox
    sx1, sy1, sx2, sy2 = shelf_zone
    
    # 손의 중심점이 선반 영역에 있는지 확인
    hand_center_x = (hx1 + hx2) / 2
    hand_center_y = (hy1 + hy2) / 2
    
    return (sx1 <= hand_center_x <= sx2) and (sy1 <= hand_center_y <= sy2)


def calculate_hand_shelf_overlap(hand_bbox: tuple, shelf_zone: tuple) -> float:
    """
    손의 bbox와 선반 영역의 겹침 정도를 계산 (0.0 ~ 1.0)
    
    Args:
        hand_bbox: 손의 bbox (x1, y1, x2, y2)
        shelf_zone: 선반 영역 (x1, y1, x2, y2)
        
    Returns:
        겹침 비율 (0.0 ~ 1.0), 겹치지 않으면 0.0
    """
    if not hand_bbox or not shelf_zone:
        return 0.0
    
    hx1, hy1, hx2, hy2 = hand_bbox
    sx1, sy1, sx2, sy2 = shelf_zone
    
    # 교차 영역 계산
    overlap_x1 = max(hx1, sx1)
    overlap_y1 = max(hy1, sy1)
    overlap_x2 = min(hx2, sx2)
    overlap_y2 = min(hy2, sy2)
    
    if overlap_x2 <= overlap_x1 or overlap_y2 <= overlap_y1:
        return 0.0
    
    # 교차 영역 면적
    overlap_area = (overlap_x2 - overlap_x1) * (overlap_y2 - overlap_y1)
    
    # 손 영역 면적
    hand_area = (hx2 - hx1) * (hy2 - hy1)
    
    if hand_area == 0:
        return 0.0
    
    # 겹침 비율 (손 영역 대비)
    overlap_ratio = overlap_area / hand_area
    
    return overlap_ratio


def find_best_matching_shelf(hand_bbox: tuple) -> tuple:
    """
    손의 위치와 가장 잘 일치하는 선반을 찾음
    
    Args:
        hand_bbox: 손의 bbox (x1, y1, x2, y2)
        
    Returns:
        (product_name, overlap_ratio) 튜플, 일치하는 선반이 없으면 (None, 0.0)
    """
    if not hand_bbox:
        return (None, 0.0)
    
    best_product = None
    best_overlap = 0.0
    min_overlap_threshold = 0.1  # 최소 10% 이상 겹쳐야 인정
    
    for product, shelf_zone in SHELF_ZONES.items():
        overlap = calculate_hand_shelf_overlap(hand_bbox, shelf_zone)
        if overlap > best_overlap and overlap >= min_overlap_threshold:
            best_overlap = overlap
            best_product = product
    
    return (best_product, best_overlap)

