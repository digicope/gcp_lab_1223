"""
Streamlit UI - 무인 점포 AI (Amazon Go Simulation) - 실시간 카메라 버전 (Beta 버전)
"""

import streamlit as st
import numpy as np
import time
from agent import run_agent, get_cart, add_product_to_cart
from product_db import PRODUCTS, get_price, get_product_name_kr
from vision_core import process_frame_realtime, image_bytes_to_frame

# 페이지 설정
st.set_page_config(
    page_title="무인 점포 AI",
    page_icon="🏪",
    layout="wide"
)

# 타이틀
st.title("🏪 무인 점포 AI (Amazon Go Simulation) - 실시간 카메라 베타버전전")
st.markdown("---")

# 세션 상태 초기화
if 'prev_products' not in st.session_state:
    st.session_state.prev_products = []
if 'detection_enabled' not in st.session_state:
    st.session_state.detection_enabled = False
if 'last_detection_time' not in st.session_state:
    st.session_state.last_detection_time = 0
if 'detected_picks' not in st.session_state:
    st.session_state.detected_picks = []
if 'frame_count' not in st.session_state:
    st.session_state.frame_count = 0
if 'last_camera_image' not in st.session_state:
    st.session_state.last_camera_image = None
if 'last_camera_bytes' not in st.session_state:
    st.session_state.last_camera_bytes = None
if 'current_products' not in st.session_state:
    st.session_state.current_products = []
if 'cart' not in st.session_state:
    st.session_state.cart = []
if 'recently_picked' not in st.session_state:
    st.session_state.recently_picked = {}  # {product: timestamp} 형태로 최근 Pick 기록
if 'last_pick_time' not in st.session_state:
    st.session_state.last_pick_time = 0

# agent.py의 전역 cart와 세션 상태 동기화
from agent import cart as agent_cart
if len(st.session_state.cart) > len(agent_cart):
    # 세션 상태가 더 최신이면 agent의 전역 변수 동기화
    agent_cart.clear()
    agent_cart.extend(st.session_state.cart)
elif len(agent_cart) > len(st.session_state.cart):
    # agent의 전역 변수가 더 최신이면 세션 상태 동기화
    st.session_state.cart = agent_cart.copy()

# 사이드바 - 상품 정보
with st.sidebar:
    st.header("📦 상품 정보")
    # 상품 표시명 매핑
    product_display_names = {
        "cola": "콜라",
        "water": "생수 500ml",
        "sandwich": "샌드위치",
        "eye_drop": "점안액",
        "pen": "볼펜",
        "charger": "충전기",
        "toothpaste": "치약"
    }
    for product, price in PRODUCTS.items():
        display_name = product_display_names.get(product, product)
        st.write(f"**{display_name}** ({product}): ₩{price:,}")
    
    st.markdown("---")
    st.header("ℹ️ 인식 방식")
    st.info("이미지에서 제품을 직접 인식하여 Pick 동작을 감지합니다.")
    
    st.markdown("---")
    st.header("⚙️ 설정")
    
    # 감지 간격 설정 (초)
    detection_interval = st.slider(
        "감지 간격 (초)",
        min_value=0.5,
        max_value=5.0,
        value=2.0,
        step=0.5,
        help="프레임 분석 간격을 설정합니다. 값이 작을수록 더 자주 분석합니다."
    )
    
    # 자동 장바구니 추가 옵션
    auto_add_to_cart = st.checkbox(
        "자동 장바구니 추가",
        value=True,
        help="Pick 감지 시 자동으로 장바구니에 추가합니다."
    )

# 메인 영역
col1, col2 = st.columns([1, 1])

with col1:
    st.header("📹 실시간 카메라 감지")
    
    # 실시간 감지 시작/중지 버튼 (카메라 입력 전에도 표시)
    col1_1, col1_2 = st.columns(2)
    
    with col1_1:
        if st.button("▶️ 자동 감지 시작", type="primary", use_container_width=True):
            st.session_state.detection_enabled = True
            st.session_state.prev_products = []
            st.session_state.last_detection_time = 0
            st.session_state.frame_count = 0
            st.session_state.current_products = []
            st.success("✅ 자동 감지가 시작되었습니다!")
            st.rerun()
    
    with col1_2:
        if st.button("⏹️ 자동 감지 중지", use_container_width=True):
            st.session_state.detection_enabled = False
            st.warning("⏹️ 자동 감지가 중지되었습니다.")
            st.rerun()
    
    # 감지 상태 표시
    if st.session_state.detection_enabled:
        st.info("🟢 **자동 감지 활성화 중...**")
    else:
        st.info("⏸️ 자동 감지가 중지되었습니다. '자동 감지 시작' 버튼을 클릭하세요.")
    
    # 카메라 입력
    camera_image = st.camera_input(
        "상품을 집는 동작을 카메라에 보여주세요",
        help="웹캠 권한을 허용해주세요. 상품을 집는 동작을 카메라에 보이면 자동으로 감지합니다.",
        key=f"camera_{st.session_state.frame_count}" if st.session_state.detection_enabled else "camera"
    )
    
    # 자동 감지 활성화 시 주기적으로 프레임 분석
    if st.session_state.detection_enabled:
        # 카메라 이미지가 있으면 분석
        if camera_image:
            # 새 이미지가 캡처되었는지 확인 (이미지 바이트 비교)
            new_image_captured = False
            try:
                current_image_bytes = camera_image.getvalue()
                
                if st.session_state.last_camera_image is None:
                    # 처음 이미지인 경우
                    new_image_captured = True
                    st.session_state.last_camera_image = camera_image
                    st.session_state.last_camera_bytes = current_image_bytes
                else:
                    # 이전 이미지 바이트와 비교
                    if 'last_camera_bytes' not in st.session_state:
                        st.session_state.last_camera_bytes = None
                    
                    if st.session_state.last_camera_bytes is None or current_image_bytes != st.session_state.last_camera_bytes:
                        # 새 이미지가 캡처된 경우
                        new_image_captured = True
                        st.session_state.last_camera_image = camera_image
                        st.session_state.last_camera_bytes = current_image_bytes
            except:
                # 이미지 바이트 비교 실패 시 객체 비교로 대체
                if st.session_state.last_camera_image is None or camera_image != st.session_state.last_camera_image:
                    new_image_captured = True
                    st.session_state.last_camera_image = camera_image
            
            # 감지 간격 확인
            current_time = time.time()
            time_since_last = current_time - st.session_state.last_detection_time
            
            # 새 이미지가 캡처되었거나, 감지 간격이 지났거나, 처음인 경우 분석
            should_analyze = new_image_captured or time_since_last >= detection_interval or st.session_state.last_detection_time == 0
            
            if should_analyze:
                # 상태 표시 영역
                status_placeholder = st.empty()
                pick_products_detected = []  # 변수 초기화
                
                # 디버깅: 새 이미지 감지 여부 표시
                if new_image_captured:
                    st.info("📸 **새 이미지가 캡처되었습니다. 분석을 시작합니다...**")
                
                with status_placeholder.container():
                    with st.spinner(f"🔍 프레임 분석 중... (프레임 #{st.session_state.frame_count + 1})"):
                        try:
                            # 이미지 바이트를 프레임으로 변환
                            image_bytes = camera_image.getvalue()
                            frame = image_bytes_to_frame(image_bytes)
                            
                            # 프레임 처리 (제품 직접 인식)
                            current_products, pick_products = process_frame_realtime(
                                frame,
                                st.session_state.prev_products
                            )
                            
                            # 현재 인식된 제품 표시
                            st.session_state.current_products = current_products
                            
                            # Pick 감지 시 즉시 처리 (중복 방지)
                            pick_products_detected = []  # 변수 초기화
                            if pick_products:
                                PICK_COOLDOWN = 3.0  # 같은 제품을 3초 이내에 다시 Pick하지 않음
                                
                                # Pick된 제품들을 필터링하여 중복 제거
                                for pick_product in pick_products:
                                    # 최근에 Pick된 제품인지 확인
                                    last_pick_time = st.session_state.recently_picked.get(pick_product, 0)
                                    time_since_last_pick = current_time - last_pick_time
                                    
                                    # 쿨다운 시간이 지났거나 처음 Pick하는 경우만 추가
                                    if time_since_last_pick >= PICK_COOLDOWN or last_pick_time == 0:
                                        pick_products_detected.append(pick_product)
                                        # 최근 Pick 시간 업데이트
                                        st.session_state.recently_picked[pick_product] = current_time
                                
                                # 중복 제거된 Pick 제품들을 장바구니에 추가
                                for pick_product in pick_products_detected:
                                    product_name_kr = get_product_name_kr(pick_product)
                                    
                                    # 장바구니에 즉시 추가 (세션 상태에 직접 추가하여 즉시 반영)
                                    if auto_add_to_cart:
                                        try:
                                            # 세션 상태에 직접 추가 (즉시 반영)
                                            if 'cart' not in st.session_state:
                                                st.session_state.cart = []
                                            
                                            # 중복 체크: 같은 제품이 이미 최근에 추가되었는지 확인
                                            # (같은 프레임에서 여러 번 추가되는 것을 방지)
                                            should_add = True
                                            if len(st.session_state.cart) > 0:
                                                # 마지막으로 추가된 제품이 같은 제품이고 시간이 가깝다면 스킵
                                                last_item = st.session_state.cart[-1]
                                                if last_item == pick_product and st.session_state.frame_count > 0:
                                                    # 같은 프레임에서 추가된 것일 수 있음
                                                    pass
                                            
                                            if should_add:
                                                st.session_state.cart.append(pick_product)
                                                
                                                # agent.py의 전역 변수도 동기화
                                                from agent import cart as agent_cart
                                                agent_cart.append(pick_product)
                                                
                                                # 결과 메시지 생성
                                                price = get_price(pick_product)
                                                cart_size = len(st.session_state.cart)
                                                result = f"{product_name_kr} (₩{price:,}) added to cart. Cart now has {cart_size} items."
                                                
                                                st.success(f"✅ **상품 감지: {product_name_kr} ({pick_product})**")
                                                st.info(f"🛒 {result}")
                                        except Exception as e:
                                            st.error(f"❌ 장바구니 추가 오류: {str(e)}")
                                    else:
                                        st.success(f"✅ **상품 감지: {product_name_kr} ({pick_product})**")
                                    
                                    # 감지 기록 저장
                                    st.session_state.detected_picks.append({
                                        'product': pick_product,
                                        'time': current_time
                                    })
                                
                                # Pick 시간 업데이트 및 이전 상태 즉시 업데이트 (중복 방지)
                                if pick_products_detected:
                                    st.session_state.last_pick_time = current_time
                                    # Pick이 감지된 경우 이전 상태를 즉시 업데이트하여 중복 방지
                                    st.session_state.prev_products = current_products.copy()
                            
                            # 현재 상태 업데이트 (Pick이 감지되지 않은 경우에만)
                            if not pick_products_detected:
                                st.session_state.prev_products = current_products.copy()
                            
                            st.session_state.last_detection_time = current_time
                            st.session_state.frame_count += 1
                            
                            # 현재 인식된 제품 표시
                            if current_products:
                                product_names_kr = [get_product_name_kr(p) for p in current_products]
                                st.info(f"👁️ **현재 인식된 제품**: {', '.join([f'{kr} ({en})' for kr, en in zip(product_names_kr, current_products)])}")
                            else:
                                st.caption("👁️ 현재 인식된 제품이 없습니다.")
                            
                            # 디버깅 정보
                            if st.checkbox("🔍 디버깅 정보 표시", key="debug_info"):
                                st.json({
                                    "현재 제품": current_products,
                                    "이전 제품": st.session_state.prev_products,
                                    "Pick된 제품": pick_products,
                                    "프레임 번호": st.session_state.frame_count
                                })
                            
                        except Exception as e:
                            st.error(f"❌ 분석 중 오류 발생: {str(e)}")
                
                # 새 이미지가 캡처되었거나 Pick이 감지되었으면 즉시 rerun하여 UI 업데이트
                if new_image_captured or pick_products_detected:
                    # 세션 상태가 저장되었으므로 즉시 rerun
                    # prev_products는 이미 위에서 업데이트되었음
                    # 세션 상태 동기화 확인
                    if 'cart' not in st.session_state:
                        st.session_state.cart = []
                    
                    # 새 이미지가 캡처된 경우에도 분석이 완료되었으므로 rerun
                    # rerun 후 col2가 자동으로 최신 세션 상태를 읽음
                    st.rerun()
                else:
                    # 자동 새로고침 (Pick이 감지되지 않은 경우)
                    remaining = detection_interval - time_since_last
                    if remaining > 0:
                        time.sleep(min(remaining, 0.5))
                    st.rerun()
            else:
                # 다음 분석까지 남은 시간 표시
                remaining = detection_interval - time_since_last
                st.caption(f"⏱️ 다음 분석까지 {remaining:.1f}초 남음 (프레임 #{st.session_state.frame_count})")
                
                # 남은 시간 동안 자동으로 새로고침
                if remaining > 0:
                    time.sleep(min(remaining, 0.5))
                    st.rerun()
        else:
            st.warning("⚠️ 카메라를 활성화해주세요.")
    elif st.session_state.last_camera_image:
        # 감지가 중지되었지만 마지막 이미지가 있으면 표시
        st.image(st.session_state.last_camera_image, caption="마지막 캡처된 이미지")
    
    # 최근 감지 기록
    if st.session_state.detected_picks:
        st.markdown("### 📝 최근 감지 기록")
        recent_picks = st.session_state.detected_picks[-5:]  # 최근 5개만 표시
        for pick in reversed(recent_picks):
            time_str = time.strftime("%H:%M:%S", time.localtime(pick['time']))
            st.write(f"⏰ {time_str}: **{pick['product']}**")

with col2:
    st.header("🛒 장바구니 관리")
    
    # 장바구니 상태 (항상 최신 세션 상태에서 직접 가져오기)
    # 매번 최신 상태를 읽어서 표시 (rerun 후에도 최신 상태 반영)
    if 'cart' not in st.session_state:
        st.session_state.cart = []
    
    # 항상 세션 상태에서 직접 가져오기 (최신 상태 보장)
    # 이 부분은 매 rerun마다 실행되므로 항상 최신 상태를 읽음
    cart = st.session_state.cart.copy()
    
    # agent.py의 전역 변수와 동기화 (세션 상태가 더 최신인 경우)
    from agent import cart as agent_cart
    if len(cart) != len(agent_cart):
        agent_cart.clear()
        agent_cart.extend(cart)
    
    if cart:
        st.subheader("현재 장바구니")
        
        # 상품별 개수 계산
        items_count = {}
        for item in cart:
            items_count[item] = items_count.get(item, 0) + 1
        
        # 장바구니 아이템 표시
        for product, count in items_count.items():
            price = get_price(product)
            total_price = price * count
            product_name_kr = get_product_name_kr(product)
            st.write(f"**{product_name_kr}** ({product}) x{count} = ₩{total_price:,}")
        
        # 총액 계산
        total = sum(get_price(p) for p in cart)
        st.markdown("---")
        st.metric("💰 총액", f"₩{total:,}")
        
        # 장바구니 버튼
        col2_1, col2_2 = st.columns(2)
        
        with col2_1:
            if st.button("📊 총액 상세 보기", use_container_width=True, key="cart_detail"):
                response = run_agent("장바구니 총액을 자세히 계산해라.")
                st.info(response)
        
        with col2_2:
            if st.button("🗑️ 장바구니 비우기", use_container_width=True, key="clear_cart"):
                # 세션 상태의 장바구니 비우기
                st.session_state.cart.clear()
                # agent.py의 전역 변수도 비우기
                from agent import cart as agent_cart
                agent_cart.clear()
                st.warning("✅ 장바구니가 비워졌습니다.")
                st.rerun()
    else:
        st.info("장바구니가 비어있습니다.")
        st.caption("실시간 감지를 활성화하면 상품이 자동으로 추가됩니다.")
        
        # 빈 장바구니에서도 총액 조회 가능
        if st.button("📊 총액 보기", use_container_width=True, key="empty_cart_total"):
            response = run_agent("장바구니 총액을 계산해라.")
            st.info(response)

# 하단 정보
st.markdown("---")
st.markdown("### 📝 사용 방법")
st.markdown("""
1. **카메라 권한 허용**: 웹 브라우저에서 카메라 권한을 허용합니다.
2. **감지 시작**: "자동 감지 시작" 버튼을 클릭하여 실시간 감지를 활성화합니다.
3. **상품 보이기**: 카메라 앞에서 상품을 보여주거나 집는 동작을 수행합니다.
4. **제품 인식**: AI가 이미지에서 제품을 직접 인식합니다.
5. **Pick 감지**: 제품이 사라지는 것을 감지하여 Pick 동작으로 판정합니다.
6. **자동 장바구니 추가**: Pick된 상품이 자동으로 장바구니에 추가됩니다.
7. **총액 확인**: 우측 패널에서 장바구니 총액을 확인할 수 있습니다.
""")

st.markdown("### ⚙️ 기술 스택")
st.markdown("""
- **Computer Vision**: OpenCV + OpenAI Vision API
- **AI Agent**: LangChain create_agent()
- **UI**: Streamlit (실시간 카메라 입력)
- **Product Detection**: 실시간 Pick/Put 판정 알고리즘
""")
