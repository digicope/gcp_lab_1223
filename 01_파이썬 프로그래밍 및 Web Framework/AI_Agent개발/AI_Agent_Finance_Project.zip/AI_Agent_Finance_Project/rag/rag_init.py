"""
RAG 시스템 초기화 스크립트
"""
from tools.rag_tool import initialize_rag, add_documents_to_rag
from utils.logger import logger
import os

def init_rag_system():
    """
    RAG 시스템 초기화
    """
    try:
        logger.info("RAG 시스템 초기화 시작")
        
        # RAG 초기화
        vector_store = initialize_rag()
        
        # dataset 폴더의 문서가 있으면 추가
        dataset_dir = "./rag/dataset"
        if os.path.exists(dataset_dir):
            documents = []
            for filename in os.listdir(dataset_dir):
                if filename.endswith(('.txt', '.md')):
                    filepath = os.path.join(dataset_dir, filename)
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        documents.append(content)
            
            if documents:
                metadata = [{"source": f"dataset_{i}"} for i in range(len(documents))]
                add_documents_to_rag(documents, metadata)
                logger.info(f"{len(documents)}개의 문서를 RAG에 추가했습니다.")
        
        logger.info("RAG 시스템 초기화 완료")
        return vector_store
        
    except Exception as e:
        logger.error(f"RAG 초기화 오류: {str(e)}")
        raise

if __name__ == "__main__":
    init_rag_system()

