"""
차트 생성 유틸리티 모듈
"""
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Optional
import pandas as pd
import io
import base64

def create_financial_chart_matplotlib(
    data: Dict[str, float],
    title: str = "재무 지표",
    chart_type: str = "bar"
) -> str:
    """
    matplotlib을 사용한 재무 차트 생성 (Base64 인코딩된 이미지 반환)
    
    Args:
        data: 차트 데이터 (키: 지표명, 값: 수치)
        title: 차트 제목
        chart_type: 차트 타입 ("bar", "line", "pie")
    
    Returns:
        Base64 인코딩된 이미지 문자열
    """
    plt.rcParams['font.family'] = 'Malgun Gothic'  # Windows 한글 폰트
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    if chart_type == "bar":
        ax.bar(data.keys(), data.values(), color='steelblue')
        ax.set_ylabel('값')
    elif chart_type == "line":
        ax.plot(list(data.keys()), list(data.values()), marker='o', linewidth=2)
        ax.set_ylabel('값')
    elif chart_type == "pie":
        ax.pie(data.values(), labels=data.keys(), autopct='%1.1f%%', startangle=90)
    
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    # Base64 인코딩
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode()
    plt.close()
    
    return image_base64

def create_financial_chart_plotly(
    data: Dict[str, float],
    title: str = "재무 지표",
    chart_type: str = "bar"
) -> go.Figure:
    """
    plotly를 사용한 재무 차트 생성
    
    Args:
        data: 차트 데이터
        title: 차트 제목
        chart_type: 차트 타입 ("bar", "line", "pie")
    
    Returns:
        plotly Figure 객체
    """
    if chart_type == "bar":
        fig = go.Figure(data=[
            go.Bar(x=list(data.keys()), y=list(data.values()), marker_color='steelblue')
        ])
    elif chart_type == "line":
        fig = go.Figure(data=[
            go.Scatter(x=list(data.keys()), y=list(data.values()), 
                      mode='lines+markers', line=dict(width=2))
        ])
    elif chart_type == "pie":
        fig = go.Figure(data=[
            go.Pie(labels=list(data.keys()), values=list(data.values()))
        ])
    
    fig.update_layout(
        title=dict(text=title, font=dict(size=16, color='black')),
        xaxis_title="지표",
        yaxis_title="값",
        template="plotly_white",
        height=400
    )
    
    return fig

def create_comparison_chart(
    companies: List[str],
    metrics: Dict[str, List[float]],
    title: str = "기업 비교"
) -> go.Figure:
    """
    여러 기업의 지표를 비교하는 차트 생성
    
    Args:
        companies: 기업명 리스트
        metrics: 지표별 값 딕셔너리 (지표명: [기업1값, 기업2값, ...])
        title: 차트 제목
    
    Returns:
        plotly Figure 객체
    """
    fig = go.Figure()
    
    for metric_name, values in metrics.items():
        fig.add_trace(go.Bar(
            name=metric_name,
            x=companies,
            y=values
        ))
    
    fig.update_layout(
        title=dict(text=title, font=dict(size=16)),
        xaxis_title="기업",
        yaxis_title="값",
        barmode='group',
        template="plotly_white",
        height=500
    )
    
    return fig

