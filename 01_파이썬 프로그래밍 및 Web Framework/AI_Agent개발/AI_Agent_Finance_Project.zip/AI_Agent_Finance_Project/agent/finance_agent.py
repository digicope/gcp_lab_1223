"""
AI 금융 분석 에이전트
LangChain v1.0 create_agent()를 사용한 통합 에이전트
"""
from langchain.agents import create_agent
from typing import List, Dict, Optional, Any
import os
from dotenv import load_dotenv
from utils.logger import logger

# LangChain v1.0 호환성을 위한 import
try:
    from langchain.chat_models import init_chat_model
except ImportError:
    # 대체 방법
    try:
        from langchain_openai import ChatOpenAI
    except ImportError:
        pass

# Tools import
from tools.news_search_tool import search_news_and_market_info, search_company_info
from tools.finance_calc_tool import get_financial_metrics, calculate_financial_ratios
from tools.risk_tool import (
    analyze_market_risk,
    analyze_industry_risk,
    analyze_financial_risk,
    comprehensive_risk_analysis
)
from tools.image_finance_tool import analyze_financial_statement_image_bytes
from tools.rag_tool import search_rag_documents

# 환경 변수 로드
load_dotenv("C:/env/.env")

def create_finance_agent(model: str = "gpt-4o-mini", api_key: Optional[str] = None) -> Any:
    """
    금융 분석 에이전트 생성
    
    Args:
        model: 사용할 OpenAI 모델 (기본값: gpt-4o-mini)
        api_key: OpenAI API 키 (선택, 환경변수에서도 읽음)
    
    Returns:
        생성된 에이전트
    """
    try:
        if not api_key:
            api_key = os.getenv("OPENAI_API_KEY")
        
        if not api_key:
            raise ValueError("OpenAI API 키가 필요합니다. .env 파일에 OPENAI_API_KEY를 설정하세요.")
        
        # 모든 Tools 리스트
        tools = [
            search_news_and_market_info,
            search_company_info,
            get_financial_metrics,
            calculate_financial_ratios,
            analyze_market_risk,
            analyze_industry_risk,
            analyze_financial_risk,
            comprehensive_risk_analysis,
            analyze_financial_statement_image_bytes,
            search_rag_documents
        ]
        
        # System Prompt
        system_prompt = """You are an expert financial analyst AI agent specialized in:
1. Company and market research
2. Financial statement analysis
3. Risk assessment
4. Investment recommendation

Your responsibilities:
- Search for latest news and market information about companies
- Analyze financial metrics (ROE, PER, PBR, growth rates, debt ratios, etc.)
- Evaluate market risk, industry risk, and financial risk
- Analyze financial statement images using Vision API
- Search relevant investment guides and research documents
- Generate comprehensive investment reports with buy/hold/sell recommendations

Always provide accurate, well-structured analysis based on the tools available.
Use Korean language for all outputs unless specifically requested otherwise.
Be thorough and consider multiple factors before making investment recommendations."""

        # LangChain v1.0 create_agent 사용
        # 사용자 요청에 따른 간단한 스타일 시도
        try:
            # 방법 1: 직접 모델 문자열 전달 (사용자 요청 스타일)
            agent = create_agent(
                model=model,
                tools=tools,
                system_prompt=system_prompt
            )
        except (TypeError, ValueError, AttributeError) as e:
            # 방법 2: init_chat_model 사용 (LangChain v1.0 공식 방법)
            logger.info(f"직접 모델 전달 실패, init_chat_model 사용: {str(e)}")
            try:
                chat_model = init_chat_model(
                    model,
                    temperature=0,
                    api_key=api_key
                )
                agent = create_agent(
                    model=chat_model,
                    tools=tools,
                    system_prompt=system_prompt
                )
            except Exception as e2:
                # 방법 3: ChatOpenAI 사용 (대체 방법)
                logger.info(f"init_chat_model 실패, ChatOpenAI 사용: {str(e2)}")
                from langchain_openai import ChatOpenAI
                chat_model = ChatOpenAI(
                    model_name=model,
                    temperature=0,
                    api_key=api_key
                )
                agent = create_agent(
                    model=chat_model,
                    tools=tools,
                    system_prompt=system_prompt
                )
        
        logger.info(f"금융 분석 에이전트 생성 완료: {model}")
        return agent
        
    except Exception as e:
        logger.error(f"에이전트 생성 오류: {str(e)}")
        raise

def analyze_company(
    agent: Any,
    company_name: str,
    ticker: str = "",
    industry: str = "",
    image_data: Optional[bytes] = None
) -> Dict:
    """
    기업 종합 분석 수행
    
    Args:
        agent: 생성된 에이전트
        company_name: 기업명
        ticker: 티커 심볼
        industry: 산업명
        image_data: 재무제표 이미지 바이트 (선택)
    
    Returns:
        분석 결과 딕셔너리
    """
    try:
        logger.info(f"기업 분석 시작: {company_name} ({ticker})")
        
        # 분석 요청 메시지 구성
        analysis_request = f"""
다음 기업에 대한 종합 금융 분석을 수행해주세요:

기업명: {company_name}
티커: {ticker}
산업: {industry}

다음 항목들을 포함하여 분석해주세요:
1. 기업 기본 정보 조회
2. 최신 뉴스 및 시장 정보 검색
3. 재무 지표 분석 (ROE, PER, PBR, 성장률, 부채비율 등)
4. 리스크 평가 (시장 리스크, 산업 리스크, 재무 리스크)
5. RAG 문서 검색을 통한 투자 가이드 참조
6. 종합 투자 의견 (매수/중립/매도)

모든 분석 결과를 구조화된 형태로 제공해주세요.
"""
        
        if image_data:
            analysis_request += "\n\n추가로 재무제표 이미지가 제공되었습니다. 이미지 분석도 포함해주세요."
        
        # 에이전트 실행
        messages = [
            {"role": "user", "content": analysis_request}
        ]
        
        result = agent.invoke({"messages": messages})
        
        logger.info("기업 분석 완료")
        return result
        
    except Exception as e:
        logger.error(f"기업 분석 오류: {str(e)}")
        raise

def generate_investment_report(
    agent: Any,
    company_name: str,
    ticker: str,
    industry: str,
    analysis_results: Dict
) -> str:
    """
    투자 리포트 생성
    
    Args:
        agent: 생성된 에이전트
        company_name: 기업명
        ticker: 티커 심볼
        industry: 산업명
        analysis_results: 분석 결과
    
    Returns:
        마크다운 형식의 투자 리포트
    """
    try:
        logger.info(f"투자 리포트 생성: {company_name}")
        
        report_request = f"""
다음 분석 결과를 바탕으로 전문적인 투자 리포트를 마크다운 형식으로 작성해주세요:

기업명: {company_name}
티커: {ticker}
산업: {industry}

분석 결과:
{str(analysis_results)}

리포트 구조:
# {company_name} 투자 분석 리포트

## 1. 기업 개요
## 2. 최근 뉴스 요약
## 3. 재무 분석
## 4. 리스크 분석
## 5. 투자 의견
## 6. 종합 결론

각 섹션을 상세하고 전문적으로 작성해주세요.
"""
        
        messages = [
            {"role": "user", "content": report_request}
        ]
        
        result = agent.invoke({"messages": messages})
        
        # 리포트 텍스트 추출
        if isinstance(result, dict):
            if "messages" in result:
                last_message = result["messages"][-1]
                if hasattr(last_message, "content"):
                    report = last_message.content
                elif isinstance(last_message, dict) and "content" in last_message:
                    report = last_message["content"]
                else:
                    report = str(result)
            else:
                report = str(result)
        else:
            report = str(result)
        
        logger.info("투자 리포트 생성 완료")
        return report
        
    except Exception as e:
        logger.error(f"리포트 생성 오류: {str(e)}")
        return f"# {company_name} 투자 분석 리포트\n\n리포트 생성 중 오류가 발생했습니다: {str(e)}"

