"""
Streamlit UI for AI 금융 분석 에이전트
"""
import streamlit as st
import sys
import os
from pathlib import Path

# 프로젝트 루트를 경로에 추가
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from agent.finance_agent import create_finance_agent, analyze_company, generate_investment_report
from utils.chart import create_financial_chart_plotly, create_comparison_chart
from utils.logger import logger
import json
import pandas as pd
import plotly.graph_objects as go

# 페이지 설정
st.set_page_config(
    page_title="AI 금융 분석 에이전트",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS 스타일
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2c3e50;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

def main():
    """메인 애플리케이션"""
    
    st.markdown('<div class="main-header">📊 AI 금융 분석 · 리스크 평가 · 투자 리포트 자동 생성 에이전트</div>', unsafe_allow_html=True)
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # API 키 입력 (선택)
        api_key = st.text_input(
            "OpenAI API Key",
            type="password",
            help="환경변수에 설정되어 있으면 비워둘 수 있습니다.",
            key="api_key_input"
        )
        
        model = st.selectbox(
            "모델 선택",
            ["gpt-4o-mini", "gpt-4o", "gpt-4-turbo"],
            index=0,
            key="selected_model"
        )
        
        st.markdown("---")
        st.markdown("### 📖 사용 방법")
        st.markdown("""
        1. 기업 정보 입력
        2. 재무제표 이미지 업로드 (선택)
        3. 분석 실행 버튼 클릭
        4. 결과 확인 및 리포트 다운로드
        """)
    
    # 메인 컨텐츠
    tab1, tab2 = st.tabs(["📈 기업 분석", "📋 분석 결과"])
    
    with tab1:
        st.markdown('<div class="section-header">기업 정보 입력</div>', unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            company_name = st.text_input(
                "기업명 *",
                placeholder="예: 삼성전자",
                key="company_name"
            )
            
            ticker = st.text_input(
                "티커 심볼",
                placeholder="예: 005930.KS 또는 AAPL",
                key="ticker"
            )
        
        with col2:
            industry = st.text_input(
                "산업",
                placeholder="예: 반도체, 전자제품",
                key="industry"
            )
            
            analysis_period = st.selectbox(
                "분석 기간",
                ["최근 1년", "최근 3년", "최근 5년"],
                index=0,
                key="analysis_period"
            )
        
        # 이미지 업로드
        st.markdown('<div class="section-header">재무제표 이미지 업로드 (선택)</div>', unsafe_allow_html=True)
        uploaded_image = st.file_uploader(
            "재무제표 이미지를 업로드하세요",
            type=["png", "jpg", "jpeg"],
            help="재무제표 스크린샷이나 이미지를 업로드하면 Vision API로 분석합니다."
        )
        
        if uploaded_image:
            st.image(uploaded_image, caption="업로드된 재무제표", use_container_width=True)
            image_bytes = uploaded_image.read()
        else:
            image_bytes = None
        
        # 분석 실행 버튼
        st.markdown("---")
        analyze_button = st.button(
            "🚀 분석 실행",
            type="primary",
            use_container_width=True
        )
        
        if analyze_button:
            if not company_name:
                st.error("❌ 기업명을 입력해주세요.")
            else:
                with st.spinner("분석을 수행하는 중입니다... 이 작업은 몇 분이 걸릴 수 있습니다."):
                    try:
                        # 에이전트 생성
                        agent = create_finance_agent(model=model, api_key=api_key if api_key else None)
                        
                        # 분석 수행
                        analysis_results = analyze_company(
                            agent=agent,
                            company_name=company_name,
                            ticker=ticker,
                            industry=industry,
                            image_data=image_bytes
                        )
                        
                        # 세션 상태에 저장 (위젯 키와 다른 이름 사용)
                        st.session_state['analysis_results'] = analysis_results
                        st.session_state['stored_company_name'] = company_name
                        st.session_state['stored_ticker'] = ticker
                        st.session_state['stored_industry'] = industry
                        st.session_state['stored_image_bytes'] = image_bytes
                        
                        st.success("✅ 분석이 완료되었습니다! '분석 결과' 탭을 확인하세요.")
                        
                    except Exception as e:
                        logger.error(f"분석 오류: {str(e)}")
                        st.error(f"❌ 분석 중 오류가 발생했습니다: {str(e)}")
    
    with tab2:
        if 'analysis_results' not in st.session_state:
            st.info("👈 '기업 분석' 탭에서 분석을 실행해주세요.")
        else:
            # 분석 결과 표시 (저장된 세션 상태에서 가져오기)
            company_name = st.session_state.get('stored_company_name', '알 수 없음')
            ticker = st.session_state.get('stored_ticker', '')
            industry = st.session_state.get('stored_industry', '')
            analysis_results = st.session_state.get('analysis_results', {})
            
            # 리포트 생성
            st.markdown('<div class="section-header">📊 종합 분석 결과</div>', unsafe_allow_html=True)
            
            try:
                # 사이드바에서 설정 가져오기
                current_model = st.session_state.get('selected_model', 'gpt-4o-mini')
                current_api_key = st.session_state.get('api_key_input', None)
                
                # 에이전트 재생성
                agent = create_finance_agent(model=current_model, api_key=current_api_key if current_api_key else None)
                
                # 리포트 생성
                with st.spinner("투자 리포트를 생성하는 중입니다..."):
                    report = generate_investment_report(
                        agent=agent,
                        company_name=company_name,
                        ticker=ticker,
                        industry=industry,
                        analysis_results=analysis_results
                    )
                
                # 리포트 표시
                st.markdown(report)
                
                # 리포트 다운로드 버튼
                st.download_button(
                    label="📥 리포트 다운로드 (Markdown)",
                    data=report,
                    file_name=f"{company_name}_투자분석리포트.md",
                    mime="text/markdown"
                )
                
                # 분석 결과 상세 (JSON)
                with st.expander("🔍 분석 결과 상세 (JSON)"):
                    st.json(analysis_results)
                
            except Exception as e:
                logger.error(f"리포트 생성 오류: {str(e)}")
                st.error(f"❌ 리포트 생성 중 오류가 발생했습니다: {str(e)}")
                
                # 기본 리포트 표시
                st.markdown(f"# {company_name} 투자 분석 리포트\n\n")
                st.markdown("## 분석 결과\n\n")
                st.json(analysis_results)

if __name__ == "__main__":
    main()

