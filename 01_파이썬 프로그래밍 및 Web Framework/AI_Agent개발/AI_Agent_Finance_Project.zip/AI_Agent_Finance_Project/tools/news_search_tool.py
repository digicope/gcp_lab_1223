"""
뉴스 및 시장 정보 검색 Tool
DuckDuckGo 검색을 사용하여 최신 뉴스와 시장 정보를 수집
"""
from langchain.tools import tool
from duckduckgo_search import DDGS
from typing import List, Dict
import json
from utils.logger import logger

@tool
def search_news_and_market_info(query: str, max_results: int = 10) -> str:
    """
    DuckDuckGo를 사용하여 뉴스 및 시장 정보를 검색합니다.
    
    Args:
        query: 검색 쿼리 (예: "삼성전자 주가 뉴스", "반도체 산업 분석")
        max_results: 최대 결과 수 (기본값: 10)
    
    Returns:
        검색 결과를 JSON 형식으로 반환
    """
    try:
        logger.info(f"뉴스 검색 실행: {query}")
        
        with DDGS() as ddgs:
            # 뉴스 검색
            news_results = list(ddgs.news(
                keywords=query,
                max_results=max_results
            ))
            
            # 웹 검색 (뉴스 외 일반 정보)
            web_results = list(ddgs.text(
                keywords=query,
                max_results=5
            ))
            
            # 결과 포맷팅
            formatted_results = {
                "news": [
                    {
                        "title": item.get("title", ""),
                        "url": item.get("url", ""),
                        "snippet": item.get("body", "")[:200] + "..." if item.get("body") else "",
                        "date": item.get("date", "")
                    }
                    for item in news_results[:max_results]
                ],
                "web": [
                    {
                        "title": item.get("title", ""),
                        "url": item.get("href", ""),
                        "snippet": item.get("body", "")[:200] + "..." if item.get("body") else ""
                    }
                    for item in web_results[:5]
                ]
            }
            
            result_str = json.dumps(formatted_results, ensure_ascii=False, indent=2)
            logger.info(f"검색 완료: {len(news_results)}개 뉴스, {len(web_results)}개 웹 결과")
            
            return result_str
            
    except Exception as e:
        logger.error(f"뉴스 검색 오류: {str(e)}")
        return json.dumps({
            "error": f"검색 중 오류 발생: {str(e)}",
            "news": [],
            "web": []
        }, ensure_ascii=False)

@tool
def search_company_info(company_name: str, ticker: str = "") -> str:
    """
    특정 기업의 기본 정보를 검색합니다.
    
    Args:
        company_name: 기업명
        ticker: 티커 심볼 (선택)
    
    Returns:
        기업 정보를 JSON 형식으로 반환
    """
    try:
        logger.info(f"기업 정보 검색: {company_name} ({ticker})")
        
        query = f"{company_name} {ticker} 기업 정보"
        if ticker:
            query += f" {ticker} 주가"
        
        with DDGS() as ddgs:
            results = list(ddgs.text(
                keywords=query,
                max_results=5
            ))
            
            company_info = {
                "company_name": company_name,
                "ticker": ticker,
                "sources": [
                    {
                        "title": item.get("title", ""),
                        "url": item.get("href", ""),
                        "snippet": item.get("body", "")[:300] + "..." if item.get("body") else ""
                    }
                    for item in results
                ]
            }
            
            return json.dumps(company_info, ensure_ascii=False, indent=2)
            
    except Exception as e:
        logger.error(f"기업 정보 검색 오류: {str(e)}")
        return json.dumps({
            "error": f"검색 중 오류 발생: {str(e)}",
            "company_name": company_name,
            "ticker": ticker,
            "sources": []
        }, ensure_ascii=False)

