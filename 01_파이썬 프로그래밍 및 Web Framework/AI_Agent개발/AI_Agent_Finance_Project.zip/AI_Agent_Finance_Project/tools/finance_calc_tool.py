"""
재무 지표 계산 Tool
ROE, PER, PBR, 성장률, 부채비율 등의 재무 지표를 계산
"""
from langchain.tools import tool
from typing import Dict, Optional
import json
import yfinance as yf
from utils.logger import logger

@tool
def get_financial_metrics(ticker: str, company_name: str = "") -> str:
    """
    Yahoo Finance를 사용하여 실제 재무 지표를 가져옵니다.
    
    Args:
        ticker: 주식 티커 심볼 (예: "005930.KS" for 삼성전자)
        company_name: 기업명 (선택)
    
    Returns:
        재무 지표를 JSON 형식으로 반환
    """
    try:
        logger.info(f"재무 지표 조회: {ticker} ({company_name})")
        
        stock = yf.Ticker(ticker)
        info = stock.info
        
        # 기본 정보
        metrics = {
            "company_name": info.get("longName", company_name),
            "ticker": ticker,
            "sector": info.get("sector", "N/A"),
            "industry": info.get("industry", "N/A"),
            "market_cap": info.get("marketCap", 0),
            "current_price": info.get("currentPrice", info.get("regularMarketPrice", 0)),
        }
        
        # 재무 지표
        financial_metrics = {
            "PER": info.get("trailingPE", 0),
            "PBR": info.get("priceToBook", 0),
            "ROE": info.get("returnOnEquity", 0),
            "ROA": info.get("returnOnAssets", 0),
            "debt_to_equity": info.get("debtToEquity", 0),
            "profit_margin": info.get("profitMargins", 0),
            "revenue_growth": info.get("revenueGrowth", 0),
            "earnings_growth": info.get("earningsGrowth", 0),
            "dividend_yield": info.get("dividendYield", 0),
        }
        
        # 재무제표 데이터
        financials = stock.financials
        balance_sheet = stock.balance_sheet
        cashflow = stock.cashflow
        
        # 최근 분기 데이터 추출
        if not financials.empty:
            latest_revenue = financials.iloc[0, 0] if financials.shape[1] > 0 else 0
            latest_net_income = financials.iloc[-1, 0] if financials.shape[0] > 0 else 0
            financial_metrics["latest_revenue"] = float(latest_revenue) if latest_revenue else 0
            financial_metrics["latest_net_income"] = float(latest_net_income) if latest_net_income else 0
        
        metrics["financial_metrics"] = financial_metrics
        
        # 퍼센트 값 변환
        for key in ["ROE", "ROA", "profit_margin", "revenue_growth", "earnings_growth", "dividend_yield"]:
            if financial_metrics[key] and isinstance(financial_metrics[key], (int, float)):
                if key == "dividend_yield":
                    financial_metrics[key] = financial_metrics[key] * 100
                else:
                    financial_metrics[key] = financial_metrics[key] * 100 if financial_metrics[key] < 1 else financial_metrics[key]
        
        result = json.dumps(metrics, ensure_ascii=False, indent=2, default=str)
        logger.info(f"재무 지표 조회 완료: {ticker}")
        
        return result
        
    except Exception as e:
        logger.error(f"재무 지표 조회 오류: {str(e)}")
        # 더미 데이터 반환 (실제 API 실패 시)
        return get_dummy_financial_metrics(ticker, company_name)

def get_dummy_financial_metrics(ticker: str, company_name: str) -> str:
    """
    더미 재무 지표 데이터 생성 (실제 API 실패 시 사용)
    
    Args:
        ticker: 티커 심볼
        company_name: 기업명
    
    Returns:
        더미 재무 지표 JSON
    """
    import random
    
    dummy_data = {
        "company_name": company_name or ticker,
        "ticker": ticker,
        "sector": "Technology",
        "industry": "Electronics",
        "market_cap": random.randint(100000, 1000000) * 1000000,
        "current_price": random.randint(50000, 200000),
        "financial_metrics": {
            "PER": round(random.uniform(10, 30), 2),
            "PBR": round(random.uniform(0.5, 3.0), 2),
            "ROE": round(random.uniform(5, 25), 2),
            "ROA": round(random.uniform(3, 15), 2),
            "debt_to_equity": round(random.uniform(0.1, 1.5), 2),
            "profit_margin": round(random.uniform(5, 20), 2),
            "revenue_growth": round(random.uniform(-5, 30), 2),
            "earnings_growth": round(random.uniform(-10, 40), 2),
            "dividend_yield": round(random.uniform(1, 5), 2),
            "latest_revenue": random.randint(10000, 100000) * 1000000,
            "latest_net_income": random.randint(1000, 10000) * 1000000,
        }
    }
    
    return json.dumps(dummy_data, ensure_ascii=False, indent=2)

@tool
def calculate_financial_ratios(
    revenue: float,
    net_income: float,
    total_assets: float,
    total_equity: float,
    total_debt: float,
    market_cap: float = 0
) -> str:
    """
    제공된 재무 데이터로부터 재무 비율을 계산합니다.
    
    Args:
        revenue: 매출액
        net_income: 순이익
        total_assets: 총자산
        total_equity: 자기자본
        total_debt: 총부채
        market_cap: 시가총액 (선택)
    
    Returns:
        계산된 재무 비율 JSON
    """
    try:
        ratios = {}
        
        # 수익성 지표
        if revenue > 0:
            ratios["profit_margin"] = round((net_income / revenue) * 100, 2)
        
        if total_assets > 0:
            ratios["ROA"] = round((net_income / total_assets) * 100, 2)
        
        if total_equity > 0:
            ratios["ROE"] = round((net_income / total_equity) * 100, 2)
        
        # 안정성 지표
        if total_equity > 0:
            ratios["debt_to_equity"] = round((total_debt / total_equity) * 100, 2)
        
        if total_assets > 0:
            ratios["debt_ratio"] = round((total_debt / total_assets) * 100, 2)
            ratios["equity_ratio"] = round((total_equity / total_assets) * 100, 2)
        
        # 시장 지표 (시가총액이 제공된 경우)
        if market_cap > 0 and net_income > 0:
            ratios["PER"] = round(market_cap / net_income, 2)
        
        if market_cap > 0 and total_equity > 0:
            ratios["PBR"] = round(market_cap / total_equity, 2)
        
        result = {
            "calculated_ratios": ratios,
            "input_data": {
                "revenue": revenue,
                "net_income": net_income,
                "total_assets": total_assets,
                "total_equity": total_equity,
                "total_debt": total_debt,
                "market_cap": market_cap
            }
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"재무 비율 계산 오류: {str(e)}")
        return json.dumps({
            "error": f"계산 중 오류 발생: {str(e)}",
            "calculated_ratios": {}
        }, ensure_ascii=False)

