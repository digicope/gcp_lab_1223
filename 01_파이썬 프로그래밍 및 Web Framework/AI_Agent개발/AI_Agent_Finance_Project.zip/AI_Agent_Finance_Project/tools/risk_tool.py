"""
리스크 분석 Tool
시장 리스크, 산업 리스크, 재무 리스크를 평가
"""
from langchain.tools import tool
from typing import Dict, List
import json
from utils.logger import logger

@tool
def analyze_market_risk(ticker: str, company_name: str = "", market_volatility: float = 0.0) -> str:
    """
    시장 리스크를 분석합니다.
    
    Args:
        ticker: 티커 심볼
        company_name: 기업명
        market_volatility: 시장 변동성 (선택, 0-1 범위)
    
    Returns:
        시장 리스크 분석 결과 JSON
    """
    try:
        logger.info(f"시장 리스크 분석: {ticker}")
        
        # 시장 리스크 요소 평가
        risk_factors = {
            "volatility_risk": "중간" if 0.2 <= market_volatility <= 0.5 else ("높음" if market_volatility > 0.5 else "낮음"),
            "market_sentiment": "긍정적",
            "sector_trend": "성장 중",
            "macro_economic": "안정적"
        }
        
        # 리스크 점수 계산 (0-100)
        risk_score = 50  # 기본값
        if market_volatility > 0.5:
            risk_score += 20
        elif market_volatility > 0.3:
            risk_score += 10
        
        risk_level = "낮음" if risk_score < 40 else ("중간" if risk_score < 70 else "높음")
        
        analysis = {
            "company_name": company_name or ticker,
            "ticker": ticker,
            "risk_type": "시장 리스크",
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_factors": risk_factors,
            "description": f"{company_name or ticker}의 시장 리스크는 {risk_level} 수준입니다. "
                          f"시장 변동성, 섹터 트렌드, 거시경제 환경을 종합적으로 고려한 결과입니다."
        }
        
        return json.dumps(analysis, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"시장 리스크 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "risk_type": "시장 리스크",
            "risk_level": "알 수 없음"
        }, ensure_ascii=False)

@tool
def analyze_industry_risk(industry: str, sector: str = "") -> str:
    """
    산업 리스크를 분석합니다.
    
    Args:
        industry: 산업명
        sector: 섹터명 (선택)
    
    Returns:
        산업 리스크 분석 결과 JSON
    """
    try:
        logger.info(f"산업 리스크 분석: {industry}")
        
        # 산업별 리스크 평가 (예시)
        industry_risk_map = {
            "Technology": {"risk_score": 60, "factors": ["기술 변화", "경쟁 심화", "규제 변화"]},
            "Finance": {"risk_score": 55, "factors": ["금리 변동", "규제 강화", "신용 리스크"]},
            "Healthcare": {"risk_score": 50, "factors": ["규제 승인", "특허 만료", "임상 시험"]},
            "Energy": {"risk_score": 65, "factors": ["원자재 가격", "환경 규제", "정치적 리스크"]},
            "Consumer": {"risk_score": 45, "factors": ["소비자 선호도", "경기 민감도", "경쟁"]}
        }
        
        # 기본값
        default_risk = {"risk_score": 50, "factors": ["경쟁", "규제", "시장 성장률"]}
        risk_data = industry_risk_map.get(sector or industry, default_risk)
        
        risk_score = risk_data["risk_score"]
        risk_level = "낮음" if risk_score < 40 else ("중간" if risk_score < 70 else "높음")
        
        analysis = {
            "industry": industry,
            "sector": sector,
            "risk_type": "산업 리스크",
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_factors": risk_data["factors"],
            "description": f"{industry} 산업의 리스크는 {risk_level} 수준입니다. "
                          f"주요 리스크 요인: {', '.join(risk_data['factors'])}"
        }
        
        return json.dumps(analysis, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"산업 리스크 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "risk_type": "산업 리스크",
            "risk_level": "알 수 없음"
        }, ensure_ascii=False)

@tool
def analyze_financial_risk(
    debt_to_equity: float,
    current_ratio: float = 0.0,
    quick_ratio: float = 0.0,
    interest_coverage: float = 0.0
) -> str:
    """
    재무 리스크를 분석합니다.
    
    Args:
        debt_to_equity: 부채비율
        current_ratio: 유동비율 (선택)
        quick_ratio: 당좌비율 (선택)
        interest_coverage: 이자보상배수 (선택)
    
    Returns:
        재무 리스크 분석 결과 JSON
    """
    try:
        logger.info(f"재무 리스크 분석: 부채비율 {debt_to_equity}")
        
        risk_score = 50  # 기본값
        risk_factors = {}
        
        # 부채비율 평가
        if debt_to_equity > 200:
            risk_score += 30
            risk_factors["debt_level"] = "매우 높음"
        elif debt_to_equity > 100:
            risk_score += 20
            risk_factors["debt_level"] = "높음"
        elif debt_to_equity > 50:
            risk_score += 10
            risk_factors["debt_level"] = "보통"
        else:
            risk_factors["debt_level"] = "낮음"
        
        # 유동성 평가
        if current_ratio > 0:
            if current_ratio < 1.0:
                risk_score += 20
                risk_factors["liquidity"] = "부족"
            elif current_ratio < 1.5:
                risk_score += 10
                risk_factors["liquidity"] = "보통"
            else:
                risk_factors["liquidity"] = "양호"
        
        # 이자보상배수 평가
        if interest_coverage > 0:
            if interest_coverage < 1.0:
                risk_score += 25
                risk_factors["interest_coverage"] = "부족"
            elif interest_coverage < 2.0:
                risk_score += 15
                risk_factors["interest_coverage"] = "보통"
            else:
                risk_factors["interest_coverage"] = "양호"
        
        # 최종 점수 조정
        risk_score = min(100, max(0, risk_score))
        risk_level = "낮음" if risk_score < 40 else ("중간" if risk_score < 70 else "높음")
        
        analysis = {
            "risk_type": "재무 리스크",
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_factors": risk_factors,
            "financial_metrics": {
                "debt_to_equity": debt_to_equity,
                "current_ratio": current_ratio if current_ratio > 0 else "N/A",
                "quick_ratio": quick_ratio if quick_ratio > 0 else "N/A",
                "interest_coverage": interest_coverage if interest_coverage > 0 else "N/A"
            },
            "description": f"재무 리스크는 {risk_level} 수준입니다. "
                          f"부채비율 {debt_to_equity}%, 유동성 및 이자보상 능력을 종합적으로 평가한 결과입니다."
        }
        
        return json.dumps(analysis, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"재무 리스크 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "risk_type": "재무 리스크",
            "risk_level": "알 수 없음"
        }, ensure_ascii=False)

@tool
def comprehensive_risk_analysis(
    ticker: str,
    company_name: str,
    industry: str,
    debt_to_equity: float,
    market_volatility: float = 0.0
) -> str:
    """
    종합 리스크 분석을 수행합니다.
    
    Args:
        ticker: 티커 심볼
        company_name: 기업명
        industry: 산업명
        debt_to_equity: 부채비율
        market_volatility: 시장 변동성 (선택)
    
    Returns:
        종합 리스크 분석 결과 JSON
    """
    try:
        logger.info(f"종합 리스크 분석: {company_name}")
        
        # 각 리스크 분석 호출 (간단화된 버전)
        market_risk_data = json.loads(analyze_market_risk(ticker, company_name, market_volatility))
        industry_risk_data = json.loads(analyze_industry_risk(industry))
        financial_risk_data = json.loads(analyze_financial_risk(debt_to_equity))
        
        # 종합 점수 계산 (가중 평균)
        market_score = market_risk_data.get("risk_score", 50)
        industry_score = industry_risk_data.get("risk_score", 50)
        financial_score = financial_risk_data.get("risk_score", 50)
        
        # 가중치: 시장 30%, 산업 30%, 재무 40%
        comprehensive_score = int(
            market_score * 0.3 + industry_score * 0.3 + financial_score * 0.4
        )
        
        comprehensive_level = "낮음" if comprehensive_score < 40 else ("중간" if comprehensive_score < 70 else "높음")
        
        analysis = {
            "company_name": company_name,
            "ticker": ticker,
            "comprehensive_risk_score": comprehensive_score,
            "comprehensive_risk_level": comprehensive_level,
            "risk_breakdown": {
                "market_risk": {
                    "score": market_score,
                    "level": market_risk_data.get("risk_level", "알 수 없음")
                },
                "industry_risk": {
                    "score": industry_score,
                    "level": industry_risk_data.get("risk_level", "알 수 없음")
                },
                "financial_risk": {
                    "score": financial_score,
                    "level": financial_risk_data.get("risk_level", "알 수 없음")
                }
            },
            "recommendation": "매수" if comprehensive_score < 40 else ("중립" if comprehensive_score < 70 else "매도"),
            "description": f"{company_name}의 종합 리스크는 {comprehensive_level} 수준입니다. "
                          f"시장 리스크, 산업 리스크, 재무 리스크를 종합적으로 평가한 결과입니다."
        }
        
        return json.dumps(analysis, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"종합 리스크 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "comprehensive_risk_level": "알 수 없음"
        }, ensure_ascii=False)

