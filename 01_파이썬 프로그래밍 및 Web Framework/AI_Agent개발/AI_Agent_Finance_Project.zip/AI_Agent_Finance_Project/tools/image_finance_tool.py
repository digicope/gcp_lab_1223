"""
Vision API를 사용한 재무제표 이미지 분석 Tool
"""
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from typing import Optional
import json
import base64
from PIL import Image
import io
from utils.logger import logger

def encode_image_to_base64(image_path: str) -> str:
    """
    이미지를 Base64로 인코딩
    
    Args:
        image_path: 이미지 파일 경로
    
    Returns:
        Base64 인코딩된 문자열
    """
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        logger.error(f"이미지 인코딩 오류: {str(e)}")
        raise

def encode_image_from_bytes(image_bytes: bytes) -> str:
    """
    이미지 바이트를 Base64로 인코딩
    
    Args:
        image_bytes: 이미지 바이트 데이터
    
    Returns:
        Base64 인코딩된 문자열
    """
    try:
        return base64.b64encode(image_bytes).decode('utf-8')
    except Exception as e:
        logger.error(f"이미지 인코딩 오류: {str(e)}")
        raise

@tool
def analyze_financial_statement_image(image_path: str, api_key: Optional[str] = None) -> str:
    """
    재무제표 이미지를 Vision API로 분석하여 텍스트 데이터를 추출합니다.
    
    Args:
        image_path: 이미지 파일 경로
        api_key: OpenAI API 키 (선택, 환경변수에서도 읽음)
    
    Returns:
        추출된 재무 데이터를 JSON 형식으로 반환
    """
    try:
        import os
        from dotenv import load_dotenv
        
        load_dotenv("C:/env/.env")
        
        if not api_key:
            api_key = os.getenv("OPENAI_API_KEY")
        
        if not api_key:
            raise ValueError("OpenAI API 키가 필요합니다.")
        
        logger.info(f"재무제표 이미지 분석 시작: {image_path}")
        
        # 이미지 인코딩
        base64_image = encode_image_to_base64(image_path)
        
        # Vision API 호출
        llm = ChatOpenAI(
            model="gpt-4o",
            api_key=api_key,
            temperature=0
        )
        
        prompt = """다음 재무제표 이미지를 분석하여 다음 정보를 JSON 형식으로 추출해주세요:
- 매출액 (Revenue)
- 영업이익 (Operating Income)
- 당기순이익 (Net Income)
- 총자산 (Total Assets)
- 총부채 (Total Liabilities)
- 자기자본 (Total Equity)
- 유동자산 (Current Assets)
- 유동부채 (Current Liabilities)
- 현금 및 현금성자산 (Cash and Cash Equivalents)

각 항목에 대해 숫자 값과 단위(원, 달러 등)를 포함하여 정확하게 추출해주세요.
표나 그래프가 있다면 모든 숫자 데이터를 포함해주세요."""

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"
                        }
                    }
                ]
            }
        ]
        
        response = llm.invoke(messages)
        extracted_text = response.content
        
        # JSON 파싱 시도
        try:
            # 응답에서 JSON 부분만 추출
            if "```json" in extracted_text:
                json_start = extracted_text.find("```json") + 7
                json_end = extracted_text.find("```", json_start)
                extracted_text = extracted_text[json_start:json_end].strip()
            elif "```" in extracted_text:
                json_start = extracted_text.find("```") + 3
                json_end = extracted_text.find("```", json_start)
                extracted_text = extracted_text[json_start:json_end].strip()
            
            extracted_data = json.loads(extracted_text)
        except json.JSONDecodeError:
            # JSON 파싱 실패 시 텍스트 그대로 반환
            extracted_data = {
                "raw_text": extracted_text,
                "note": "JSON 파싱 실패, 원본 텍스트 반환"
            }
        
        result = {
            "image_path": image_path,
            "extracted_data": extracted_data,
            "status": "success"
        }
        
        logger.info("재무제표 이미지 분석 완료")
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"재무제표 이미지 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "image_path": image_path,
            "status": "error"
        }, ensure_ascii=False)

@tool
def analyze_financial_statement_image_bytes(image_bytes: bytes, api_key: Optional[str] = None) -> str:
    """
    재무제표 이미지 바이트를 Vision API로 분석합니다.
    
    Args:
        image_bytes: 이미지 바이트 데이터
        api_key: OpenAI API 키 (선택)
    
    Returns:
        추출된 재무 데이터를 JSON 형식으로 반환
    """
    try:
        import os
        from dotenv import load_dotenv
        
        load_dotenv("C:/env/.env")
        
        if not api_key:
            api_key = os.getenv("OPENAI_API_KEY")
        
        if not api_key:
            raise ValueError("OpenAI API 키가 필요합니다.")
        
        logger.info("재무제표 이미지 바이트 분석 시작")
        
        # 이미지 인코딩
        base64_image = encode_image_from_bytes(image_bytes)
        
        # Vision API 호출
        llm = ChatOpenAI(
            model="gpt-4o",
            api_key=api_key,
            temperature=0
        )
        
        prompt = """다음 재무제표 이미지를 분석하여 다음 정보를 JSON 형식으로 추출해주세요:
- 매출액 (Revenue)
- 영업이익 (Operating Income)
- 당기순이익 (Net Income)
- 총자산 (Total Assets)
- 총부채 (Total Liabilities)
- 자기자본 (Total Equity)
- 유동자산 (Current Assets)
- 유동부채 (Current Liabilities)
- 현금 및 현금성자산 (Cash and Cash Equivalents)

각 항목에 대해 숫자 값과 단위(원, 달러 등)를 포함하여 정확하게 추출해주세요.
표나 그래프가 있다면 모든 숫자 데이터를 포함해주세요."""

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"
                        }
                    }
                ]
            }
        ]
        
        response = llm.invoke(messages)
        extracted_text = response.content
        
        # JSON 파싱 시도
        try:
            if "```json" in extracted_text:
                json_start = extracted_text.find("```json") + 7
                json_end = extracted_text.find("```", json_start)
                extracted_text = extracted_text[json_start:json_end].strip()
            elif "```" in extracted_text:
                json_start = extracted_text.find("```") + 3
                json_end = extracted_text.find("```", json_start)
                extracted_text = extracted_text[json_start:json_end].strip()
            
            extracted_data = json.loads(extracted_text)
        except json.JSONDecodeError:
            extracted_data = {
                "raw_text": extracted_text,
                "note": "JSON 파싱 실패, 원본 텍스트 반환"
            }
        
        result = {
            "extracted_data": extracted_data,
            "status": "success"
        }
        
        logger.info("재무제표 이미지 분석 완료")
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"재무제표 이미지 분석 오류: {str(e)}")
        return json.dumps({
            "error": f"분석 중 오류 발생: {str(e)}",
            "status": "error"
        }, ensure_ascii=False)

