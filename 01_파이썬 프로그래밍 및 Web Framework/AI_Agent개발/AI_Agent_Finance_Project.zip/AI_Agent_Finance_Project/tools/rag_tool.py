"""
RAG (Retrieval-Augmented Generation) Tool
Chroma를 사용한 벡터 데이터베이스 기반 문서 검색
"""
from langchain.tools import tool
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from typing import List, Optional
import json
import os
from utils.logger import logger

# 전역 변수로 벡터 스토어 관리
_vector_store: Optional[Chroma] = None
_embeddings: Optional[OpenAIEmbeddings] = None

def initialize_rag(api_key: Optional[str] = None, persist_directory: str = "./rag/chroma_db") -> Chroma:
    """
    RAG 시스템 초기화
    
    Args:
        api_key: OpenAI API 키
        persist_directory: Chroma DB 저장 디렉토리
    
    Returns:
        초기화된 Chroma 벡터 스토어
    """
    global _vector_store, _embeddings
    
    try:
        import os
        from dotenv import load_dotenv
        
        load_dotenv("C:/env/.env")
        
        if not api_key:
            api_key = os.getenv("OPENAI_API_KEY")
        
        if not api_key:
            raise ValueError("OpenAI API 키가 필요합니다.")
        
        _embeddings = OpenAIEmbeddings(api_key=api_key)
        
        # 기존 DB가 있으면 로드, 없으면 새로 생성
        if os.path.exists(persist_directory) and os.listdir(persist_directory):
            logger.info(f"기존 Chroma DB 로드: {persist_directory}")
            _vector_store = Chroma(
                persist_directory=persist_directory,
                embedding_function=_embeddings
            )
        else:
            logger.info("새로운 Chroma DB 생성")
            # 샘플 문서로 초기화
            sample_docs = get_sample_documents()
            _vector_store = Chroma.from_documents(
                documents=sample_docs,
                embedding=_embeddings,
                persist_directory=persist_directory
            )
            _vector_store.persist()
        
        logger.info("RAG 시스템 초기화 완료")
        return _vector_store
        
    except Exception as e:
        logger.error(f"RAG 초기화 오류: {str(e)}")
        raise

def get_sample_documents() -> List[Document]:
    """
    샘플 문서 생성 (실제 사용 시 dataset/ 폴더의 문서로 대체)
    
    Returns:
        Document 리스트
    """
    sample_texts = [
        """
        투자 분석 가이드: 재무제표 분석
        
        재무제표는 기업의 재무 상태를 파악하는 핵심 자료입니다. 주요 재무제표는 다음과 같습니다:
        1. 손익계산서: 기업의 수익성 평가
        2. 재무상태표: 자산, 부채, 자본 구조 파악
        3. 현금흐름표: 현금의 유입과 유출 분석
        
        주요 재무 지표:
        - ROE (자기자본이익률): 순이익 / 자기자본
        - ROA (총자산이익률): 순이익 / 총자산
        - PER (주가수익비율): 주가 / 주당순이익
        - PBR (주가순자산비율): 주가 / 주당순자산
        - 부채비율: 총부채 / 자기자본
        """,
        """
        리스크 평가 방법론
        
        투자 리스크는 크게 세 가지로 분류됩니다:
        
        1. 시장 리스크: 주식 시장 전체의 변동성, 경제 상황 변화
        2. 산업 리스크: 특정 산업에 영향을 미치는 요인 (규제, 기술 변화 등)
        3. 재무 리스크: 기업의 재무 건전성 (부채 수준, 유동성 등)
        
        리스크 평가 시 고려사항:
        - 부채비율이 100% 이상이면 재무 리스크가 높음
        - 유동비율이 1.0 미만이면 유동성 리스크 존재
        - 이자보상배수가 1.0 미만이면 이자 지급 능력 부족
        """,
        """
        투자 의견 결정 기준
        
        투자 의견은 다음과 같은 기준으로 결정됩니다:
        
        매수 (Buy):
        - 재무 지표가 우수 (ROE > 15%, PER < 20)
        - 리스크 점수가 낮음 (< 40)
        - 성장 가능성이 높음
        
        중립 (Hold):
        - 재무 지표가 보통 수준
        - 리스크 점수가 중간 (40-70)
        - 성장 전망이 불확실
        
        매도 (Sell):
        - 재무 지표가 약함 (ROE < 5%, 부채비율 > 200%)
        - 리스크 점수가 높음 (> 70)
        - 성장 전망이 부정적
        """,
        """
        산업별 분석 가이드
        
        기술 산업:
        - 높은 성장률과 변동성
        - 기술 혁신이 핵심 경쟁력
        - 특허와 R&D 투자가 중요
        
        금융 산업:
        - 금리 변동에 민감
        - 규제 환경이 중요
        - 신용 리스크 관리가 핵심
        
        헬스케어 산업:
        - 규제 승인 프로세스 중요
        - 특허 만료 리스크
        - 임상 시험 결과가 주가에 큰 영향
        
        에너지 산업:
        - 원자재 가격 변동성 높음
        - 환경 규제 영향 큼
        - 정치적 리스크 존재
        """
    ]
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    
    documents = []
    for i, text in enumerate(sample_texts):
        chunks = text_splitter.split_text(text)
        for chunk in chunks:
            documents.append(Document(page_content=chunk, metadata={"source": f"guide_{i}"}))
    
    return documents

@tool
def search_rag_documents(query: str, k: int = 3) -> str:
    """
    RAG 데이터베이스에서 관련 문서를 검색합니다.
    
    Args:
        query: 검색 쿼리
        k: 반환할 문서 수 (기본값: 3)
    
    Returns:
        검색된 문서를 JSON 형식으로 반환
    """
    try:
        global _vector_store
        
        if _vector_store is None:
            initialize_rag()
        
        logger.info(f"RAG 문서 검색: {query}")
        
        # 유사도 검색
        docs = _vector_store.similarity_search(query, k=k)
        
        results = []
        for i, doc in enumerate(docs):
            results.append({
                "rank": i + 1,
                "content": doc.page_content,
                "metadata": doc.metadata
            })
        
        result = {
            "query": query,
            "results": results,
            "count": len(results)
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"RAG 문서 검색 오류: {str(e)}")
        return json.dumps({
            "error": f"검색 중 오류 발생: {str(e)}",
            "query": query,
            "results": []
        }, ensure_ascii=False)

@tool
def add_documents_to_rag(documents: List[str], metadata: Optional[List[dict]] = None) -> str:
    """
    RAG 데이터베이스에 새 문서를 추가합니다.
    
    Args:
        documents: 추가할 문서 텍스트 리스트
        metadata: 각 문서의 메타데이터 리스트 (선택)
    
    Returns:
        추가 결과를 JSON 형식으로 반환
    """
    try:
        global _vector_store, _embeddings
        
        if _vector_store is None:
            initialize_rag()
        
        logger.info(f"RAG에 문서 추가: {len(documents)}개")
        
        # Document 객체 생성
        doc_objects = []
        for i, doc_text in enumerate(documents):
            meta = metadata[i] if metadata and i < len(metadata) else {"source": f"user_doc_{i}"}
            doc_objects.append(Document(page_content=doc_text, metadata=meta))
        
        # 벡터 스토어에 추가
        _vector_store.add_documents(doc_objects)
        _vector_store.persist()
        
        result = {
            "status": "success",
            "added_count": len(documents),
            "message": f"{len(documents)}개의 문서가 추가되었습니다."
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        logger.error(f"문서 추가 오류: {str(e)}")
        return json.dumps({
            "error": f"추가 중 오류 발생: {str(e)}",
            "status": "error"
        }, ensure_ascii=False)

