"""
AI 금융 분석 에이전트 메인 실행 파일
"""
import sys
from pathlib import Path

# 프로젝트 루트를 경로에 추가
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from agent.finance_agent import create_finance_agent, analyze_company
from utils.logger import logger
import os

def main():
    """메인 함수"""
    print("=" * 60)
    print("AI 금융 분석 · 리스크 평가 · 투자 리포트 자동 생성 에이전트")
    print("=" * 60)
    print()
    
    try:
        # 에이전트 생성
        print("에이전트를 생성하는 중...")
        agent = create_finance_agent()
        print("✅ 에이전트 생성 완료\n")
        
        # 사용자 입력
        print("기업 정보를 입력하세요:")
        company_name = input("기업명: ").strip()
        ticker = input("티커 심볼 (선택): ").strip()
        industry = input("산업 (선택): ").strip()
        
        if not company_name:
            print("❌ 기업명은 필수입니다.")
            return
        
        print(f"\n{company_name}에 대한 분석을 시작합니다...\n")
        
        # 분석 수행
        result = analyze_company(
            agent=agent,
            company_name=company_name,
            ticker=ticker,
            industry=industry
        )
        
        # 결과 출력
        print("\n" + "=" * 60)
        print("분석 결과")
        print("=" * 60)
        print()
        
        if isinstance(result, dict):
            if "messages" in result:
                last_message = result["messages"][-1]
                if hasattr(last_message, "content"):
                    print(last_message.content)
                elif isinstance(last_message, dict) and "content" in last_message:
                    print(last_message["content"])
                else:
                    print(result)
            else:
                print(result)
        else:
            print(result)
        
        print("\n✅ 분석 완료!")
        
    except KeyboardInterrupt:
        print("\n\n사용자에 의해 중단되었습니다.")
    except Exception as e:
        logger.error(f"실행 오류: {str(e)}")
        print(f"\n❌ 오류 발생: {str(e)}")

if __name__ == "__main__":
    main()

