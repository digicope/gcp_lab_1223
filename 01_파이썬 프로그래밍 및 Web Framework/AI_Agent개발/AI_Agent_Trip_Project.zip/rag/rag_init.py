"""
RAG 시스템 초기화 모듈
Chroma 벡터 DB를 사용하여 여행 정보 검색 시스템 구축
"""

import os
from pathlib import Path
from typing import List, Optional
import chromadb
from chromadb.config import Settings
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
# LangChain 최신 버전 호환성을 위한 import
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    try:
        from langchain_core.text_splitter import RecursiveCharacterTextSplitter
    except ImportError:
        from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from utils.logger import logger
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 임베딩 모델 초기화
embeddings = OpenAIEmbeddings(openai_api_key=os.getenv("OPENAI_API_KEY"))

# Chroma 클라이언트 설정
CHROMA_DB_PATH = "./chroma_db"
COLLECTION_NAME = "travel_knowledge"


def initialize_rag_system(data_dir: str = "./rag/dataset") -> Chroma:
    """
    RAG 시스템 초기화 및 벡터 DB 생성
    
    Args:
        data_dir: 여행 정보 문서가 있는 디렉토리 경로
    
    Returns:
        초기화된 Chroma 벡터 스토어 객체
    """
    try:
        logger.info("RAG 시스템 초기화 시작")
        
        # 데이터 디렉토리 생성
        Path(data_dir).mkdir(parents=True, exist_ok=True)
        
        # 샘플 데이터 파일이 없으면 생성
        sample_file = Path(data_dir) / "travel_info.txt"
        if not sample_file.exists():
            create_sample_data(sample_file)
        
        # 기존 DB가 있으면 로드, 없으면 생성
        if Path(CHROMA_DB_PATH).exists():
            logger.info("기존 벡터 DB 로드")
            vectorstore = Chroma(
                persist_directory=CHROMA_DB_PATH,
                embedding_function=embeddings,
                collection_name=COLLECTION_NAME
            )
        else:
            logger.info("새 벡터 DB 생성")
            # 문서 로드 및 분할
            documents = []
            data_path = Path(data_dir)
            
            for txt_file in data_path.glob("*.txt"):
                loader = TextLoader(str(txt_file), encoding='utf-8')
                docs = loader.load()
                documents.extend(docs)
            
            if not documents:
                logger.warning("로드할 문서가 없습니다. 샘플 데이터를 생성합니다.")
                create_sample_data(sample_file)
                loader = TextLoader(str(sample_file), encoding='utf-8')
                documents = loader.load()
            
            # 텍스트 분할
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1000,
                chunk_overlap=200,
                length_function=len
            )
            splits = text_splitter.split_documents(documents)
            
            # 벡터 스토어 생성
            vectorstore = Chroma.from_documents(
                documents=splits,
                embedding=embeddings,
                persist_directory=CHROMA_DB_PATH,
                collection_name=COLLECTION_NAME
            )
        
        logger.info("RAG 시스템 초기화 완료")
        return vectorstore
        
    except Exception as e:
        logger.error(f"RAG 시스템 초기화 오류: {e}")
        raise


def create_sample_data(file_path: Path):
    """
    샘플 여행 정보 데이터 생성
    
    Args:
        file_path: 저장할 파일 경로
    """
    sample_content = """여행 계획 가이드

1. 일반적인 여행 준비사항
- 비자 및 여권 확인 (6개월 이상 유효기간)
- 여행자 보험 가입 권장
- 현지 통화 및 환전 정보 확인
- 긴급 연락처 및 주소지 정보 기록

2. 인기 여행지 정보

파리 (프랑스)
- 주요 관광지: 에펠탑, 루브르 박물관, 노트르담 대성당, 몽마르트르
- 베스트 시즌: 4월~6월, 9월~10월
- 추천 일정: 최소 3일
- 예상 예산: 하루 15만원~25만원
- 주요 활동: 박물관 관람, 카페 체험, 쇼핑, 루브르 투어

도쿄 (일본)
- 주요 관광지: 시부야, 신주쿠, 아사쿠사, 오다이바, 도쿄타워
- 베스트 시즌: 3월~5월 (벚꽃), 10월~11월 (단풍)
- 추천 일정: 최소 4일
- 예상 예산: 하루 12만원~20만원
- 주요 활동: 스시 체험, 온천, 메이드 카페, 전통 시장 방문

제주도 (한국)
- 주요 관광지: 한라산, 성산일출봉, 협재해수욕장, 우도, 한옥마을
- 베스트 시즌: 4월~6월, 9월~11월
- 추천 일정: 최소 2일
- 예상 예산: 하루 8만원~15만원
- 주요 활동: 해변 휴양, 오름 등반, 흑돼지 맛집, 카페 투어

3. 여행 일정 계획 팁
- 첫날과 마지막 날은 이동 시간을 고려하여 여유있게 계획
- 주요 관광지는 오전에 방문하는 것을 권장
- 점심 식사 후 휴식 시간 포함
- 저녁에는 현지 음식 체험 및 야경 관람 추천

4. 예산 관리 팁
- 숙박비: 전체 예산의 30~40%
- 식비: 전체 예산의 25~35%
- 교통비: 전체 예산의 15~25%
- 관광/활동비: 전체 예산의 10~20%
- 쇼핑/여유비: 전체 예산의 10~15%

5. 안전 여행 수칙
- 현지 법규 및 문화 존중
- 소지품 관리 주의
- 긴급 상황 대비 연락처 준비
- 현지 응급실 및 약국 위치 확인
"""
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(sample_content)
        logger.info(f"샘플 데이터 생성 완료: {file_path}")
    except Exception as e:
        logger.error(f"샘플 데이터 생성 오류: {e}")


def get_vectorstore() -> Optional[Chroma]:
    """
    기존 벡터 스토어 인스턴스 반환
    
    Returns:
        Chroma 벡터 스토어 객체 (없으면 None)
    """
    try:
        if Path(CHROMA_DB_PATH).exists():
            return Chroma(
                persist_directory=CHROMA_DB_PATH,
                embedding_function=embeddings,
                collection_name=COLLECTION_NAME
            )
        return None
    except Exception as e:
        logger.error(f"벡터 스토어 로드 오류: {e}")
        return None

