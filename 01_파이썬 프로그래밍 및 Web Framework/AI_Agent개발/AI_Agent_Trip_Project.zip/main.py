"""
메인 실행 파일
콘솔에서 실행 가능한 여행 일정 추천 에이전트
"""

import sys
from pathlib import Path

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from agent.travel_agent import create_travel_agent
from utils.logger import logger


def main():
    """메인 함수"""
    print("=" * 60)
    print("✈️  AI 여행 루트 추천 에이전트")
    print("=" * 60)
    print()
    
    try:
        # 에이전트 초기화
        print("에이전트 초기화 중...")
        agent = create_travel_agent()
        print("✅ 에이전트 초기화 완료\n")
        
        # 사용자 입력 받기
        print("-" * 60)
        print("여행 정보를 입력해주세요:")
        print("-" * 60)
        
        destination = input("여행지: ").strip()
        if not destination:
            print("❌ 여행지를 입력해주세요.")
            return
        
        duration = input("여행 기간 (일): ").strip()
        try:
            duration = int(duration)
        except ValueError:
            print("❌ 올바른 숫자를 입력해주세요.")
            return
        
        budget = input("예산 (선택사항): ").strip() or None
        travelers = input("동행 인원 (선택사항): ").strip()
        travelers = int(travelers) if travelers else None
        
        preferences = input("선호사항 (선택사항): ").strip() or None
        
        image_path = input("이미지 파일 경로 (선택사항): ").strip() or None
        
        print("\n" + "=" * 60)
        print("여행 일정 생성 중...")
        print("=" * 60)
        print()
        
        # 일정 생성
        result = agent.plan_trip(
            destination=destination,
            duration=duration,
            budget=budget,
            travelers=travelers,
            preferences=preferences,
            image_path=image_path
        )
        
        print("\n" + "=" * 60)
        print("생성된 여행 일정")
        print("=" * 60)
        print()
        print(result)
        print()
        
        # 결과 저장
        save_option = input("결과를 파일로 저장하시겠습니까? (y/n): ").strip().lower()
        if save_option == 'y':
            output_file = f"itinerary_{destination}_{duration}days.txt"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(result)
            print(f"✅ 결과가 '{output_file}'에 저장되었습니다.")
        
    except KeyboardInterrupt:
        print("\n\n프로그램이 중단되었습니다.")
    except Exception as e:
        logger.error(f"프로그램 실행 오류: {e}")
        print(f"\n❌ 오류 발생: {str(e)}")


if __name__ == "__main__":
    main()

