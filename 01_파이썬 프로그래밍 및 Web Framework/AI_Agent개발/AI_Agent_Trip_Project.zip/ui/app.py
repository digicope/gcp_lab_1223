"""
Streamlit 기반 여행 일정 추천 UI
"""

import streamlit as st
import sys
import os
from pathlib import Path

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from agent.travel_agent import create_travel_agent
from utils.logger import logger
import tempfile
import json

# 페이지 설정
st.set_page_config(
    page_title="AI 여행 루트 추천 에이전트",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS 스타일
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #424242;
        margin-top: 1rem;
        margin-bottom: 1rem;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #E3F2FD;
        margin: 1rem 0;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #E8F5E9;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)


def main():
    """메인 UI 함수"""
    
    # 헤더
    st.markdown('<div class="main-header">✈️ AI 여행 루트 추천 에이전트</div>', unsafe_allow_html=True)
    st.markdown("---")
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        st.markdown("""
        ### 사용 방법
        1. 여행 정보를 입력하세요
        2. 여행 사진을 업로드할 수 있습니다 (선택)
        3. "여행 일정 생성하기" 버튼을 클릭하세요
        4. AI가 맞춤형 일정을 생성합니다
        
        ### 주요 기능
        - 📍 이미지 기반 장소 추론
        - 🌐 최신 여행 정보 검색
        - 📚 지식 베이스 검색
        - 📅 Day별 상세 일정 생성
        """)
        
        st.markdown("---")
        st.markdown("### 예시 입력")
        st.code("""
여행지: 파리
기간: 3일
예산: 150만원
동행 인원: 2명
선호사항: 문화, 음식
        """)
    
    # 세션 상태 초기화
    if "agent" not in st.session_state:
        try:
            with st.spinner("에이전트 초기화 중..."):
                st.session_state.agent = create_travel_agent()
                logger.info("UI에서 에이전트 초기화 완료")
        except Exception as e:
            st.error(f"에이전트 초기화 오류: {str(e)}")
            st.stop()
    
    if "itinerary_result" not in st.session_state:
        st.session_state.itinerary_result = None
    
    # 메인 콘텐츠
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown('<div class="sub-header">📝 여행 정보 입력</div>', unsafe_allow_html=True)
        
        # 입력 폼
        with st.form("travel_form"):
            destination = st.text_input(
                "여행지 *",
                placeholder="예: 파리, 도쿄, 제주도",
                help="여행할 목적지를 입력하세요"
            )
            
            duration = st.number_input(
                "여행 기간 (일) *",
                min_value=1,
                max_value=30,
                value=3,
                help="여행할 일수를 입력하세요"
            )
            
            budget = st.text_input(
                "예산",
                placeholder="예: 150만원, $2000",
                help="전체 여행 예산을 입력하세요 (선택사항)"
            )
            
            travelers = st.number_input(
                "동행 인원",
                min_value=1,
                max_value=20,
                value=2,
                help="여행할 인원 수를 입력하세요"
            )
            
            preferences = st.text_area(
                "선호사항",
                placeholder="예: 문화, 음식, 쇼핑, 자연",
                help="관심있는 활동이나 취향을 입력하세요 (선택사항)"
            )
            
            # 이미지 업로드
            uploaded_file = st.file_uploader(
                "여행 사진 업로드 (선택)",
                type=['png', 'jpg', 'jpeg'],
                help="여행하고 싶은 장소의 사진을 업로드하면 AI가 분석합니다"
            )
            
            submit_button = st.form_submit_button(
                "🚀 여행 일정 생성하기",
                use_container_width=True
            )
            
            if submit_button:
                if not destination:
                    st.error("여행지를 입력해주세요.")
                else:
                    # 이미지 저장
                    image_path = None
                    if uploaded_file is not None:
                        # 임시 파일로 저장
                        temp_dir = tempfile.gettempdir()
                        image_path = os.path.join(temp_dir, uploaded_file.name)
                        with open(image_path, "wb") as f:
                            f.write(uploaded_file.getbuffer())
                        st.success(f"이미지 업로드 완료: {uploaded_file.name}")
                    
                    # 일정 생성
                    with st.spinner("AI가 여행 일정을 생성하는 중입니다... 이 작업은 몇 분이 걸릴 수 있습니다."):
                        try:
                            result = st.session_state.agent.plan_trip(
                                destination=destination,
                                duration=duration,
                                budget=budget if budget else None,
                                travelers=int(travelers) if travelers else None,
                                preferences=preferences if preferences else None,
                                image_path=image_path
                            )
                            st.session_state.itinerary_result = result
                            
                            # 이미지 파일 정리
                            if image_path and os.path.exists(image_path):
                                try:
                                    os.remove(image_path)
                                except:
                                    pass
                            
                        except Exception as e:
                            st.error(f"일정 생성 중 오류 발생: {str(e)}")
                            logger.error(f"일정 생성 오류: {e}")
    
    with col2:
        st.markdown('<div class="sub-header">📸 이미지 분석 (선택)</div>', unsafe_allow_html=True)
        
        if uploaded_file is not None:
            # Streamlit 버전 호환성: use_container_width 파라미터 제거
            st.image(uploaded_file, caption="업로드된 이미지")
            
            # 이미지만 분석하는 버튼
            if st.button("🔍 이미지 분석하기", use_container_width=True):
                temp_dir = tempfile.gettempdir()
                image_path = os.path.join(temp_dir, uploaded_file.name)
                with open(image_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                
                with st.spinner("이미지 분석 중..."):
                    try:
                        analysis_result = st.session_state.agent.analyze_image_only(image_path)
                        st.markdown("### 분석 결과")
                        st.markdown(f'<div class="info-box">{analysis_result}</div>', unsafe_allow_html=True)
                        
                        if os.path.exists(image_path):
                            try:
                                os.remove(image_path)
                            except:
                                pass
                    except Exception as e:
                        st.error(f"이미지 분석 오류: {str(e)}")
        else:
            st.info("이미지를 업로드하면 AI가 장소를 분석합니다.")
    
    # 결과 표시
    if st.session_state.itinerary_result:
        st.markdown("---")
        st.markdown('<div class="sub-header">📅 생성된 여행 일정</div>', unsafe_allow_html=True)
        st.markdown("---")
        
        # 마크다운 결과 표시
        st.markdown(st.session_state.itinerary_result)
        
        # 다운로드 버튼
        st.download_button(
            label="📥 일정 다운로드 (텍스트)",
            data=st.session_state.itinerary_result,
            file_name=f"travel_itinerary_{destination}_{duration}days.txt",
            mime="text/plain",
            use_container_width=True
        )
        
        # JSON 형식으로도 표시 (개발용)
        with st.expander("🔧 원본 JSON 데이터 보기 (개발용)"):
            try:
                # 결과에서 JSON 추출 시도
                st.code(st.session_state.itinerary_result, language="markdown")
            except:
                st.code(st.session_state.itinerary_result, language="text")
    
    # 푸터
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #757575; padding: 2rem;">
        <p>AI 여행 루트 추천 에이전트 | LangChain v1.0 + OpenAI API</p>
        <p>이미지 분석, 웹 검색, RAG 통합 에이전트</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()

