"""
RAG 검색 도구
벡터 DB에서 여행 관련 정보를 검색
"""

from typing import Optional
from langchain_core.tools import tool
from rag.rag_init import get_vectorstore, initialize_rag_system
from utils.logger import logger


@tool
def search_travel_knowledge(query: str, k: int = 3) -> str:
    """
    저장된 여행 지식 베이스에서 관련 정보를 검색합니다.
    
    Args:
        query: 검색 쿼리 (예: "파리 관광지", "제주도 추천 일정")
        k: 반환할 문서 개수 (기본값: 3)
    
    Returns:
        검색 결과 문자열
    
    Example:
        search_travel_knowledge("파리 3일 일정 추천")
    """
    try:
        logger.info(f"RAG 검색 실행: {query}")
        
        # 벡터 스토어 가져오기
        vectorstore = get_vectorstore()
        
        # 벡터 스토어가 없으면 초기화
        if vectorstore is None:
            logger.info("벡터 스토어가 없어 초기화를 진행합니다.")
            vectorstore = initialize_rag_system()
        
        # 유사도 검색
        docs = vectorstore.similarity_search(query, k=k)
        
        if not docs:
            return "검색 결과가 없습니다."
        
        # 결과 포맷팅
        results = []
        for i, doc in enumerate(docs, 1):
            results.append({
                "rank": i,
                "content": doc.page_content[:500] + "..." if len(doc.page_content) > 500 else doc.page_content,
                "metadata": doc.metadata
            })
        
        response = {
            "query": query,
            "results": results,
            "count": len(results)
        }
        
        logger.info(f"RAG 검색 완료: {len(results)}건")
        
        # JSON 형태로 반환
        import json
        return json.dumps(response, ensure_ascii=False, indent=2)
        
    except Exception as e:
        error_msg = f"RAG 검색 오류: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def get_travel_tips(destination: str) -> str:
    """
    특정 여행지에 대한 팁과 정보를 검색합니다.
    
    Args:
        destination: 여행지 이름
    
    Returns:
        여행 팁 문자열
    """
    query = f"{destination} 여행 팁 추천 일정"
    return search_travel_knowledge(query, k=5)

