"""
웹 검색 도구
DuckDuckGo 검색 API를 사용하여 최신 여행 정보 검색
"""

import json
from typing import Optional
from langchain_core.tools import tool
from duckduckgo_search import DDGS
from utils.logger import logger


@tool
def search_travel_trends(destination: str, query_type: str = "general") -> str:
    """
    여행지의 최신 트렌드, 맛집, 인기 스팟을 검색합니다.
    
    Args:
        destination: 여행지 이름 (예: "파리", "도쿄", "제주도")
        query_type: 검색 유형 ("general", "restaurants", "attractions", "hotels")
    
    Returns:
        검색 결과 문자열 (JSON 형태)
    
    Example:
        search_travel_trends("파리", "restaurants")
    """
    try:
        logger.info(f"여행 트렌드 검색: {destination}, 유형: {query_type}")
        
        # 검색 쿼리 구성
        query_map = {
            "general": f"{destination} 최신 여행 정보 2024",
            "restaurants": f"{destination} 맛집 추천 2024",
            "attractions": f"{destination} 관광지 추천 2024",
            "hotels": f"{destination} 숙박 추천 2024"
        }
        
        query = query_map.get(query_type, query_map["general"])
        
        # DuckDuckGo 검색 실행
        results = []
        with DDGS() as ddgs:
            search_results = ddgs.text(
                query,
                max_results=5,
                region='kr-ko',  # 한국 지역 설정
                safesearch='moderate'
            )
            
            for result in search_results:
                results.append({
                    "title": result.get("title", ""),
                    "snippet": result.get("body", ""),
                    "url": result.get("href", "")
                })
        
        if not results:
            logger.warning(f"검색 결과가 없습니다: {destination}")
            return json.dumps({
                "destination": destination,
                "query_type": query_type,
                "results": [],
                "message": "검색 결과가 없습니다."
            }, ensure_ascii=False, indent=2)
        
        response = {
            "destination": destination,
            "query_type": query_type,
            "results": results,
            "summary": f"{destination}에 대한 {query_type} 검색 결과 {len(results)}건"
        }
        
        logger.info(f"검색 완료: {len(results)}건")
        return json.dumps(response, ensure_ascii=False, indent=2)
        
    except Exception as e:
        error_msg = f"웹 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return json.dumps({
            "error": error_msg,
            "destination": destination,
            "query_type": query_type
        }, ensure_ascii=False, indent=2)


@tool
def search_travel_info(destination: str, topic: str) -> str:
    """
    여행지에 대한 특정 주제의 정보를 검색합니다.
    
    Args:
        destination: 여행지 이름
        topic: 검색 주제 (예: "날씨", "교통", "축제", "쇼핑")
    
    Returns:
        검색 결과 문자열
    
    Example:
        search_travel_info("도쿄", "교통수단")
    """
    try:
        logger.info(f"여행 정보 검색: {destination} - {topic}")
        
        query = f"{destination} {topic} 정보"
        
        results = []
        with DDGS() as ddgs:
            search_results = ddgs.text(
                query,
                max_results=5,
                region='kr-ko',
                safesearch='moderate'
            )
            
            for result in search_results:
                results.append({
                    "title": result.get("title", ""),
                    "content": result.get("body", ""),
                    "url": result.get("href", "")
                })
        
        response = {
            "destination": destination,
            "topic": topic,
            "results": results
        }
        
        return json.dumps(response, ensure_ascii=False, indent=2)
        
    except Exception as e:
        error_msg = f"정보 검색 오류: {str(e)}"
        logger.error(error_msg)
        return json.dumps({
            "error": error_msg,
            "destination": destination,
            "topic": topic
        }, ensure_ascii=False, indent=2)


@tool
def search_recent_news(destination: str) -> str:
    """
    여행지의 최근 뉴스 및 이벤트를 검색합니다.
    
    Args:
        destination: 여행지 이름
    
    Returns:
        최근 뉴스 검색 결과 문자열
    """
    try:
        logger.info(f"최근 뉴스 검색: {destination}")
        
        query = f"{destination} 최근 뉴스 여행"
        
        results = []
        with DDGS() as ddgs:
            search_results = ddgs.text(
                query,
                max_results=5,
                region='kr-ko',
                safesearch='moderate'
            )
            
            for result in search_results:
                results.append({
                    "title": result.get("title", ""),
                    "content": result.get("body", ""),
                    "url": result.get("href", "")
                })
        
        response = {
            "destination": destination,
            "news": results,
            "count": len(results)
        }
        
        return json.dumps(response, ensure_ascii=False, indent=2)
        
    except Exception as e:
        error_msg = f"뉴스 검색 오류: {str(e)}"
        logger.error(error_msg)
        return json.dumps({
            "error": error_msg,
            "destination": destination
        }, ensure_ascii=False, indent=2)

