"""
여행 일정 생성 도구
사용자 입력을 기반으로 여행 일정 생성
"""

import json
from typing import Dict, List, Optional
from langchain_core.tools import tool
from openai import OpenAI
from dotenv import load_dotenv
import os
from utils.logger import logger

# 환경 변수 로드
load_dotenv("C:/env/.env")

# OpenAI 클라이언트 초기화
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


@tool
def generate_itinerary(
    destination: str,
    duration: int,
    budget: Optional[str] = None,
    travelers: Optional[int] = None,
    preferences: Optional[str] = None,
    image_analysis: Optional[str] = None,
    search_results: Optional[str] = None
) -> str:
    """
    여행 일정을 생성합니다.
    
    Args:
        destination: 여행지 이름
        duration: 여행 기간 (일수)
        budget: 예산 (선택사항)
        travelers: 동행 인원 (선택사항)
        preferences: 선호사항 (선택사항)
        image_analysis: 이미지 분석 결과 (선택사항)
        search_results: 웹 검색 결과 (선택사항)
    
    Returns:
        JSON 형태의 상세 여행 일정
    
    Example:
        generate_itinerary("파리", 3, "150만원", 2, "문화, 음식")
    """
    try:
        logger.info(f"여행 일정 생성 시작: {destination}, {duration}일")
        
        # 프롬프트 구성
        system_prompt = """당신은 전문 여행 플래너입니다. 
사용자의 요구사항을 바탕으로 실용적이고 흥미로운 여행 일정을 생성해주세요.
일정은 날짜별(Day 1, Day 2, ...)로 구분하고, 각 날짜별로 다음 정보를 포함해야 합니다:
- 오전 활동
- 점심 식사 장소 추천
- 오후 활동
- 저녁 식사 장소 추천
- 숙박 추천 (필요시)
- 예상 비용

JSON 형식으로 답변해주세요."""
        
        user_prompt = f"""다음 정보를 바탕으로 여행 일정을 생성해주세요:

여행지: {destination}
기간: {duration}일"""
        
        if budget:
            user_prompt += f"\n예산: {budget}"
        if travelers:
            user_prompt += f"\n동행 인원: {travelers}명"
        if preferences:
            user_prompt += f"\n선호사항: {preferences}"
        if image_analysis:
            user_prompt += f"\n\n이미지 분석 결과 (참고):\n{image_analysis}"
        if search_results:
            user_prompt += f"\n\n최신 정보 검색 결과 (참고):\n{search_results}"
        
        user_prompt += "\n\n일정은 Day 1, Day 2 형식으로 구분하고, 각 날짜별로 상세한 활동과 추천 장소를 포함해주세요."
        
        # OpenAI API 호출
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=2000,
            temperature=0.7
        )
        
        result = response.choices[0].message.content
        logger.info("여행 일정 생성 완료")
        return result
        
    except Exception as e:
        error_msg = f"일정 생성 오류: {str(e)}"
        logger.error(error_msg)
        return json.dumps({
            "error": error_msg,
            "destination": destination,
            "duration": duration
        }, ensure_ascii=False, indent=2)


@tool
def format_itinerary_markdown(itinerary_json: str) -> str:
    """
    JSON 형태의 일정을 마크다운 형식으로 변환합니다.
    
    Args:
        itinerary_json: JSON 형태의 일정
    
    Returns:
        마크다운 형식의 일정
    """
    try:
        itinerary = json.loads(itinerary_json)
        
        markdown = f"# {itinerary.get('destination', '여행지')} 여행 일정\n\n"
        markdown += f"**기간**: {itinerary.get('duration', '')}일\n"
        
        if 'budget' in itinerary:
            markdown += f"**예산**: {itinerary['budget']}\n"
        
        markdown += "\n---\n\n"
        
        # 각 날짜별 일정
        days = itinerary.get('itinerary', [])
        if not days:
            days = itinerary.get('days', [])
        
        for day in days:
            day_num = day.get('day', day.get('date', ''))
            markdown += f"## {day_num}\n\n"
            
            if 'morning' in day:
                markdown += f"### 오전\n{day['morning']}\n\n"
            if 'lunch' in day:
                markdown += f"### 점심\n{day['lunch']}\n\n"
            if 'afternoon' in day:
                markdown += f"### 오후\n{day['afternoon']}\n\n"
            if 'dinner' in day:
                markdown += f"### 저녁\n{day['dinner']}\n\n"
            if 'accommodation' in day:
                markdown += f"### 숙박\n{day['accommodation']}\n\n"
            if 'budget' in day:
                markdown += f"**예상 비용**: {day['budget']}\n\n"
            
            markdown += "---\n\n"
        
        return markdown
        
    except Exception as e:
        logger.error(f"마크다운 변환 오류: {e}")
        return f"일정 변환 오류: {str(e)}\n\n원본 JSON:\n{itinerary_json}"

