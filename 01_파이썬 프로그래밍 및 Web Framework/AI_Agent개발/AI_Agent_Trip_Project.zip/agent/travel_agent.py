"""
여행 에이전트 메인 모듈
LangChain v1.0의 create_agent를 사용하여 모든 도구를 통합
"""

import os
from typing import Optional, List
from dotenv import load_dotenv
from utils.logger import logger

# 도구 임포트
from tools.image_tool import analyze_travel_image, extract_location_from_image
from tools.search_tool import search_travel_trends, search_travel_info, search_recent_news
from tools.rag_tool import search_travel_knowledge, get_travel_tips
from tools.itinerary_tool import generate_itinerary, format_itinerary_markdown

# 환경 변수 로드
load_dotenv("C:/env/.env")

# LangChain v1.0 create_agent import 시도
try:
    from langchain.agents import create_agent
    HAS_CREATE_AGENT = True
except ImportError:
    # Fallback: create_tool_calling_agent 사용
    from langchain_openai import ChatOpenAI
    from langchain.agents import create_tool_calling_agent, AgentExecutor
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    HAS_CREATE_AGENT = False
    logger.warning("create_agent를 사용할 수 없습니다. create_tool_calling_agent를 사용합니다.")


def _create_agent_fallback(
    model: str = "gpt-4o-mini",
    tools: List = None,
    system_prompt: str = None,
):
    """
    Fallback 에이전트 생성 함수 (create_agent가 없을 때 사용)
    
    Args:
        model: 모델 이름
        tools: 도구 목록
        system_prompt: 시스템 프롬프트
    
    Returns:
        AgentExecutor 인스턴스
    """
    # 모델 이름 파싱
    if ":" in model:
        model_name = model.split(":")[-1]
    else:
        model_name = model
    
    # LLM 생성
    llm = ChatOpenAI(
        model=model_name,
        temperature=0.7,
        openai_api_key=os.getenv("OPENAI_API_KEY")
    )
    
    # 프롬프트 템플릿 생성
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt or "You are a helpful assistant."),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])
    
    # 에이전트 생성
    agent = create_tool_calling_agent(llm, tools, prompt)
    
    # 에이전트 실행기 생성
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=10
    )
    
    return agent_executor


class TravelAgent:
    """여행 일정 추천 에이전트"""
    
    def __init__(self, model_name: str = "gpt-4o-mini", temperature: float = 0.7):
        """
        에이전트 초기화
        
        Args:
            model_name: 사용할 OpenAI 모델 이름 (형식: "gpt-4o-mini")
            temperature: 모델 온도 (0.0~1.0) - create_agent에서는 사용되지 않음
        """
        # 모든 도구 수집
        tools = [
            analyze_travel_image,
            extract_location_from_image,
            search_travel_trends,
            search_travel_info,
            search_recent_news,
            search_travel_knowledge,
            get_travel_tips,
            generate_itinerary,
            format_itinerary_markdown
        ]
        
        # 시스템 프롬프트 설정
        system_prompt = """당신은 전문 여행 플래너 AI 에이전트입니다. 
사용자의 요구사항을 분석하여 최적의 여행 일정을 생성하는 것이 목표입니다.

사용 가능한 도구:
1. 이미지 분석: 사용자가 업로드한 여행 사진을 분석하여 장소를 추론
2. 웹 검색: 최신 여행 정보, 맛집, 관광지 정보 검색
3. 지식 검색: 저장된 여행 지식 베이스에서 정보 검색
4. 일정 생성: 모든 정보를 종합하여 상세한 여행 일정 생성

작업 흐름:
1. 사용자 입력 분석 (목적지, 기간, 예산 등)
2. 이미지가 있으면 분석하여 장소 추론
3. 필요한 경우 웹 검색으로 최신 정보 수집
4. 지식 베이스에서 관련 정보 검색
5. 모든 정보를 종합하여 Day별 상세 일정 생성

항상 친절하고 전문적으로 응답하며, 실용적인 조언을 제공하세요."""
        
        # LangChain v1.0 스타일로 에이전트 생성
        if HAS_CREATE_AGENT:
            self.agent = create_agent(
                model=model_name,
                tools=tools,
                system_prompt=system_prompt,
            )
        else:
            # Fallback: create_tool_calling_agent 사용
            self.agent = _create_agent_fallback(
                model=model_name,
                tools=tools,
                system_prompt=system_prompt,
            )
        
        logger.info("Travel Agent 초기화 완료")
    
    def plan_trip(
        self,
        destination: str,
        duration: int,
        budget: Optional[str] = None,
        travelers: Optional[int] = None,
        preferences: Optional[str] = None,
        image_path: Optional[str] = None
    ) -> str:
        """
        여행 일정 생성 메인 메서드
        
        Args:
            destination: 여행지
            duration: 기간 (일수)
            budget: 예산
            travelers: 동행 인원
            preferences: 선호사항
            image_path: 이미지 파일 경로 (선택사항)
        
        Returns:
            생성된 여행 일정 문자열
        """
        try:
            logger.info(f"여행 일정 생성 요청: {destination}, {duration}일")
            
            # 입력 메시지 구성
            user_input = f"""다음 정보를 바탕으로 여행 일정을 생성해주세요:
- 여행지: {destination}
- 기간: {duration}일"""
            
            if budget:
                user_input += f"\n- 예산: {budget}"
            if travelers:
                user_input += f"\n- 동행 인원: {travelers}명"
            if preferences:
                user_input += f"\n- 선호사항: {preferences}"
            
            if image_path:
                user_input += f"\n\n먼저 이미지 파일 '{image_path}'을 분석하여 장소를 추론하고, 그 정보를 여행 일정에 반영해주세요."
            
            user_input += """\n\n다음 단계를 수행해주세요:
1. 이미지가 있으면 analyze_travel_image 도구로 분석
2. search_travel_trends로 최신 여행 정보 검색
3. search_travel_knowledge로 저장된 지식 검색
4. generate_itinerary 도구로 Day별 상세 일정 생성
5. format_itinerary_markdown으로 마크다운 형식 변환

최종적으로 마크다운 형식의 일정을 제공해주세요."""
            
            # 에이전트 실행 (LangChain v1.0 스타일)
            if HAS_CREATE_AGENT:
                result = self.agent.invoke({
                    "messages": [
                        {"role": "user", "content": user_input}
                    ]
                })
                
                logger.info("여행 일정 생성 완료")
                
                # 결과에서 메시지 추출
                if isinstance(result, dict):
                    if "messages" in result and result["messages"]:
                        last_message = result["messages"][-1]
                        if hasattr(last_message, 'content'):
                            return last_message.content
                        elif isinstance(last_message, dict) and "content" in last_message:
                            return last_message["content"]
                    elif "output" in result:
                        return result["output"]
                
                return str(result)
            else:
                # Fallback: 기존 방식
                result = self.agent.invoke({"input": user_input})
                
                logger.info("여행 일정 생성 완료")
                
                if isinstance(result, dict):
                    return result.get("output", str(result))
                
                return str(result)
            
        except Exception as e:
            error_msg = f"여행 일정 생성 오류: {str(e)}"
            logger.error(error_msg)
            return error_msg
    
    def analyze_image_only(self, image_path: str) -> str:
        """
        이미지만 분석하는 메서드
        
        Args:
            image_path: 이미지 파일 경로
        
        Returns:
            이미지 분석 결과
        """
        try:
            logger.info(f"이미지 분석 요청: {image_path}")
            
            user_input = f"""이미지 파일 '{image_path}'을 분석하여 다음 정보를 추출해주세요:
1. 장소/랜드마크 이름
2. 추정 위치
3. 장소 유형
4. 분위기
5. 추천 활동

analyze_travel_image 도구를 사용해주세요."""
            
            # 에이전트 실행 (LangChain v1.0 스타일)
            if HAS_CREATE_AGENT:
                result = self.agent.invoke({
                    "messages": [
                        {"role": "user", "content": user_input}
                    ]
                })
                
                # 결과에서 메시지 추출
                if isinstance(result, dict):
                    if "messages" in result and result["messages"]:
                        last_message = result["messages"][-1]
                        if hasattr(last_message, 'content'):
                            return last_message.content
                        elif isinstance(last_message, dict) and "content" in last_message:
                            return last_message["content"]
                    elif "output" in result:
                        return result["output"]
                
                return str(result) if result else "이미지 분석 중 오류가 발생했습니다."
            else:
                # Fallback: 기존 방식
                result = self.agent.invoke({"input": user_input})
                
                if isinstance(result, dict):
                    return result.get("output", str(result))
                
                return str(result) if result else "이미지 분석 중 오류가 발생했습니다."
            
        except Exception as e:
            error_msg = f"이미지 분석 오류: {str(e)}"
            logger.error(error_msg)
            return error_msg


def create_travel_agent() -> TravelAgent:
    """
    TravelAgent 인스턴스 생성 (팩토리 함수)
    
    Returns:
        TravelAgent 인스턴스
    """
    return TravelAgent()

