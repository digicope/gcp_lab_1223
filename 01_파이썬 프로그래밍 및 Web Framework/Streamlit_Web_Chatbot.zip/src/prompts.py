"""
프롬프트 및 기본 설정 모듈
시스템 프롬프트와 기본값 관리
"""
from typing import Dict, Any

# 기본 시스템 프롬프트
DEFAULT_SYSTEM_PROMPT = """당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 
사용자의 질문에 정확하고 유용한 답변을 제공하세요."""

# 기본 모델 설정
DEFAULT_MODEL = "gpt-4o-mini"

# 기본 temperature 설정
DEFAULT_TEMPERATURE = 0.7

# 사용 가능한 모델 목록
AVAILABLE_MODELS = [
    "gpt-4o-mini",
    "gpt-4o",
    "gpt-4-turbo",
    "gpt-3.5-turbo",
]


def get_default_config() -> Dict[str, Any]:
    """
    기본 설정 딕셔너리 반환
    
    Returns:
        기본 설정이 포함된 딕셔너리
    """
    return {
        "system_prompt": DEFAULT_SYSTEM_PROMPT,
        "model": DEFAULT_MODEL,
        "temperature": DEFAULT_TEMPERATURE,
    }


def initialize_session_state():
    """
    Streamlit session_state 초기화
    """
    import streamlit as st
    
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    if "system_prompt" not in st.session_state:
        st.session_state.system_prompt = DEFAULT_SYSTEM_PROMPT
    
    if "model" not in st.session_state:
        st.session_state.model = DEFAULT_MODEL
    
    if "temperature" not in st.session_state:
        st.session_state.temperature = DEFAULT_TEMPERATURE

