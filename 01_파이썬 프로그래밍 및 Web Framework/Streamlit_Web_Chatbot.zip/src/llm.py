"""
OpenAI LLM 호출 및 스트리밍 처리 모듈
"""
import os
from typing import Iterator, Optional
from openai import OpenAI
from openai import OpenAIError

from src.utils import format_error_message, validate_api_key, log_error


def get_openai_client() -> tuple[Optional[OpenAI], Optional[str]]:
    """
    OpenAI 클라이언트 생성 및 검증
    
    Returns:
        (OpenAI 클라이언트, 에러 메시지)
    """
    api_key = os.getenv("OPENAI_API_KEY")
    
    is_valid, error_msg = validate_api_key(api_key)
    if not is_valid:
        return None, error_msg
    
    try:
        client = OpenAI(api_key=api_key)
        return client, None
    except Exception as e:
        log_error(e, "OpenAI client creation")
        return None, format_error_message(e)


def prepare_messages(system_prompt: str, conversation_history: list[dict]) -> list[dict]:
    """
    OpenAI API에 전달할 messages 포맷 준비
    
    Args:
        system_prompt: 시스템 프롬프트
        conversation_history: 대화 히스토리 (role, content 포함)
        
    Returns:
        OpenAI API 형식의 messages 리스트
    """
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(conversation_history)
    return messages


def stream_chat_completion(
    client: OpenAI,
    model: str,
    messages: list[dict],
    temperature: float
) -> Iterator[str]:
    """
    스트리밍 채팅 완성 생성
    
    Args:
        client: OpenAI 클라이언트
        model: 사용할 모델명
        messages: 대화 메시지 리스트
        temperature: temperature 설정
        
    Yields:
        스트리밍된 텍스트 청크
    """
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                if delta and delta.content is not None:
                    yield delta.content
                
    except OpenAIError as e:
        log_error(e, "stream_chat_completion")
        raise
    except Exception as e:
        log_error(e, "stream_chat_completion")
        raise OpenAIError(f"Unexpected error: {str(e)}")


def chat_completion(
    client: OpenAI,
    model: str,
    messages: list[dict],
    temperature: float
) -> str:
    """
    비스트리밍 채팅 완성 (에러 처리용)
    
    Args:
        client: OpenAI 클라이언트
        model: 사용할 모델명
        messages: 대화 메시지 리스트
        temperature: temperature 설정
        
    Returns:
        완성된 응답 텍스트
    """
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature
        )
        return response.choices[0].message.content
    except OpenAIError as e:
        log_error(e, "chat_completion")
        raise
    except Exception as e:
        log_error(e, "chat_completion")
        raise OpenAIError(f"Unexpected error: {str(e)}")

