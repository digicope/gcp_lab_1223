"""
공통 유틸리티 함수 모듈
로깅, 예외 메시지 포맷팅 등 공통 기능 제공
"""
import logging
from typing import Optional
from openai import OpenAIError, APIError, APIConnectionError, RateLimitError, AuthenticationError

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def format_error_message(error: Exception) -> str:
    """
    OpenAI API 에러를 사용자 친화적인 메시지로 변환
    
    Args:
        error: 발생한 예외 객체
        
    Returns:
        사용자 친화적인 에러 메시지
    """
    if isinstance(error, AuthenticationError):
        return "❌ API 키가 유효하지 않습니다. 환경변수 OPENAI_API_KEY를 확인해주세요."
    elif isinstance(error, RateLimitError):
        return "⏱️ API 요청 한도에 도달했습니다. 잠시 후 다시 시도해주세요."
    elif isinstance(error, APIConnectionError):
        return "🌐 네트워크 연결 오류가 발생했습니다. 인터넷 연결을 확인해주세요."
    elif isinstance(error, APIError):
        return f"⚠️ API 오류가 발생했습니다: {str(error)}"
    elif isinstance(error, OpenAIError):
        return f"❌ OpenAI API 오류: {str(error)}"
    else:
        return f"❌ 예상치 못한 오류가 발생했습니다: {str(error)}"


def validate_api_key(api_key: Optional[str]) -> tuple[bool, Optional[str]]:
    """
    API 키 유효성 검사
    
    Args:
        api_key: 검사할 API 키
        
    Returns:
        (유효 여부, 에러 메시지)
    """
    if not api_key:
        return False, "❌ OPENAI_API_KEY 환경변수가 설정되지 않았습니다. .env 파일을 확인해주세요."
    
    if not api_key.startswith("sk-"):
        return False, "❌ API 키 형식이 올바르지 않습니다. OpenAI API 키는 'sk-'로 시작해야 합니다."
    
    return True, None


def log_error(error: Exception, context: str = ""):
    """
    에러 로깅
    
    Args:
        error: 발생한 예외 객체
        context: 에러 발생 컨텍스트 정보
    """
    context_msg = f" [{context}]" if context else ""
    logger.error(f"Error occurred{context_msg}: {type(error).__name__}: {str(error)}", exc_info=True)

