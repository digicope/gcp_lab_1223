"""
채팅 UI 렌더링 함수 모듈
"""
import streamlit as st
from typing import Optional
from src.prompts import AVAILABLE_MODELS, DEFAULT_MODEL, DEFAULT_TEMPERATURE
from src.llm import get_openai_client, prepare_messages, stream_chat_completion
from src.utils import format_error_message
import os


def render_sidebar():
    """
    사이드바 UI 렌더링
    """
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # 모델 선택
        default_model = os.getenv("OPENAI_MODEL", DEFAULT_MODEL)
        if default_model not in AVAILABLE_MODELS:
            default_model = DEFAULT_MODEL
        
        current_model = st.session_state.get("model", default_model)
        if current_model not in AVAILABLE_MODELS:
            current_model = default_model
        
        model_index = AVAILABLE_MODELS.index(current_model)
        st.session_state.model = st.selectbox(
            "🤖 모델 선택",
            options=AVAILABLE_MODELS,
            index=model_index
        )
        
        # Temperature 슬라이더
        st.session_state.temperature = st.slider(
            "🌡️ Temperature",
            min_value=0.0,
            max_value=1.0,
            value=st.session_state.get("temperature", DEFAULT_TEMPERATURE),
            step=0.1,
            help="값이 높을수록 더 창의적인 응답을 생성합니다."
        )
        
        st.divider()
        
        # 대화 초기화 버튼
        if st.button("🗑️ 대화 초기화", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
        
        st.divider()
        
        # 시스템 프롬프트 편집
        st.subheader("📝 시스템 프롬프트")
        new_prompt = st.text_area(
            "시스템 프롬프트를 수정할 수 있습니다:",
            value=st.session_state.get("system_prompt", ""),
            height=150,
            label_visibility="collapsed"
        )
        st.session_state.system_prompt = new_prompt
        
        st.caption("💡 시스템 프롬프트는 AI의 행동과 응답 스타일을 정의합니다.")


def render_message(role: str, content: str):
    """
    개별 메시지 렌더링
    
    Args:
        role: 메시지 역할 (user 또는 assistant)
        content: 메시지 내용
    """
    with st.chat_message(role):
        st.markdown(content)


def render_chat_history():
    """
    대화 히스토리 렌더링
    """
    for message in st.session_state.messages:
        render_message(message["role"], message["content"])


def process_assistant_response():
    """
    어시스턴트 응답 생성 및 스트리밍 처리
    마지막 메시지가 사용자 메시지이고 아직 응답이 없는 경우에만 실행
    """
    # 마지막 메시지가 사용자 메시지이고, 아직 응답이 없는 경우에만 처리
    if not st.session_state.messages:
        return
    
    last_message = st.session_state.messages[-1]
    if last_message["role"] != "user":
        return
    
    # OpenAI 클라이언트 생성
    client, error_msg = get_openai_client()
    if client is None:
        st.error(error_msg)
        # 에러 발생 시 사용자 메시지도 롤백
        if st.session_state.messages and st.session_state.messages[-1]["role"] == "user":
            st.session_state.messages.pop()
        return
    
    # 어시스턴트 응답 준비
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""
        
        try:
            # 메시지 포맷 준비 (전체 히스토리 포함)
            messages = prepare_messages(
                st.session_state.system_prompt,
                st.session_state.messages  # 전체 히스토리 포함 (마지막 사용자 메시지 포함)
            )
            
            # 스트리밍 응답 생성
            for chunk in stream_chat_completion(
                client=client,
                model=st.session_state.model,
                messages=messages,
                temperature=st.session_state.temperature
            ):
                full_response += chunk
                message_placeholder.markdown(full_response + "▌")
            
            # 최종 응답 표시 (커서 제거)
            message_placeholder.markdown(full_response)
            
            # 어시스턴트 응답을 히스토리에 추가
            st.session_state.messages.append({"role": "assistant", "content": full_response})
            
        except Exception as e:
            error_msg = format_error_message(e)
            message_placeholder.error(error_msg)
            # 에러 발생 시 사용자 메시지 롤백
            if st.session_state.messages and st.session_state.messages[-1]["role"] == "user":
                st.session_state.messages.pop()


def render_main_area():
    """
    메인 채팅 영역 렌더링
    """
    # 대화 히스토리 표시
    render_chat_history()
    
    # 사용자 입력 처리 (히스토리 렌더링 후 처리)
    if user_input := st.chat_input("메시지를 입력하세요..."):
        # 사용자 메시지를 먼저 히스토리에 추가하고 즉시 표시
        st.session_state.messages.append({"role": "user", "content": user_input})
        # 페이지를 즉시 업데이트하여 사용자 메시지가 바로 보이도록 함
        st.rerun()
    
    # 마지막 메시지가 사용자 메시지인 경우 어시스턴트 응답 생성
    process_assistant_response()


def setup_page_config():
    """
    Streamlit 페이지 설정
    """
    st.set_page_config(
        page_title="Streamlit Web Chatbot",
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="expanded"
    )

