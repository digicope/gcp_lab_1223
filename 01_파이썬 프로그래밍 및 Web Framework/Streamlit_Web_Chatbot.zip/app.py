"""
Streamlit Web Chatbot - 메인 엔트리 포인트
"""
import streamlit as st
from dotenv import load_dotenv
from src.ui import setup_page_config, render_sidebar, render_main_area
from src.prompts import initialize_session_state

# 환경변수 로드
load_dotenv()

# 페이지 설정
setup_page_config()

# 세션 상태 초기화
initialize_session_state()

# 메인 타이틀
st.title("🤖 Streamlit Web Chatbot")
st.caption("OpenAI API를 사용하는 대화형 챗봇")

# 사이드바 렌더링
render_sidebar()

# 메인 채팅 영역 렌더링
render_main_area()

