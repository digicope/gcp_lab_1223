# Streamlit Web Chatbot

OpenAI API를 사용하는 대화형 웹 챗봇 애플리케이션입니다.

## 🚀 기능

- **실시간 스트리밍 응답**: 토큰 단위로 점진적으로 응답을 표시합니다
- **대화 히스토리 관리**: 세션 동안 대화 내용을 유지합니다
- **모델 선택**: 다양한 OpenAI 모델을 선택할 수 있습니다
- **Temperature 조절**: 응답의 창의성을 조절할 수 있습니다
- **시스템 프롬프트 커스터마이징**: AI의 행동과 스타일을 정의할 수 있습니다
- **에러 처리**: 친절한 에러 메시지와 함께 다양한 오류 상황을 처리합니다

## 📋 요구사항

- Python 3.11 이상
- OpenAI API 키

## 🛠️ 설치 방법

1. 저장소 클론 또는 프로젝트 디렉토리로 이동:
```bash
cd Streamlit_Web_Chatbot
```

2. 가상환경 생성 및 활성화 (권장):
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

3. 의존성 설치:
```bash
pip install -r requirements.txt
```

4. 환경변수 설정:
```bash
# .env.example을 .env로 복사
copy .env.example .env  # Windows
cp .env.example .env    # macOS/Linux

# .env 파일을 열어서 OPENAI_API_KEY를 설정
```

`.env` 파일 예시:
```
OPENAI_API_KEY=sk-your-actual-api-key-here
```

## ▶️ 실행 방법

```bash
streamlit run app.py
```

브라우저가 자동으로 열리며, 기본적으로 `http://localhost:8501`에서 애플리케이션이 실행됩니다.

## 📁 프로젝트 구조

```
Streamlit_Web_Chatbot/
├── app.py                 # Streamlit 엔트리 포인트
├── requirements.txt       # Python 의존성
├── .env.example          # 환경변수 템플릿
├── .env                  # 실제 환경변수 (git에 포함하지 않음)
├── README.md             # 프로젝트 문서
└── src/
    ├── llm.py            # OpenAI 호출 및 스트리밍 처리
    ├── prompts.py        # 시스템 프롬프트 및 기본 설정
    ├── ui.py             # 채팅 UI 렌더링 함수
    └── utils.py          # 공통 유틸리티 (로깅, 에러 처리)
```

## ⚙️ 환경변수

### 필수 변수

- `OPENAI_API_KEY`: OpenAI API 키 (필수)

### 선택 변수

- `OPENAI_MODEL`: 기본 모델 설정 (기본값: `gpt-4o-mini`)

## 🎨 사용 방법

1. **모델 선택**: 사이드바에서 사용할 OpenAI 모델을 선택합니다.

2. **Temperature 조절**: 사이드바의 슬라이더로 응답의 창의성을 조절합니다.
   - 낮은 값 (0.0-0.3): 더 일관되고 결정적인 응답
   - 중간 값 (0.4-0.7): 균형잡힌 응답 (기본값: 0.7)
   - 높은 값 (0.8-1.0): 더 창의적이고 다양한 응답

3. **시스템 프롬프트 수정**: 사이드바에서 AI의 행동과 응답 스타일을 정의할 수 있습니다.

4. **대화 초기화**: 사이드바의 "대화 초기화" 버튼으로 대화 히스토리를 지울 수 있습니다.

5. **메시지 입력**: 하단의 입력창에 메시지를 입력하고 Enter를 누르거나 전송 버튼을 클릭합니다.

## 🔧 주요 기능 설명

### 스트리밍 응답

응답은 토큰 단위로 실시간으로 표시되어, 긴 응답도 빠르게 확인할 수 있습니다.

### 대화 히스토리

`st.session_state`를 사용하여 세션 동안 대화 내용을 유지합니다. 페이지를 새로고침하면 히스토리가 초기화됩니다.

### 에러 처리

다음과 같은 오류 상황을 처리합니다:
- API 키 누락 또는 유효하지 않음
- API 요청 한도 초과
- 네트워크 연결 오류
- 기타 API 오류

## 🚢 배포 팁

### Streamlit Cloud 배포

1. GitHub에 프로젝트를 푸시합니다.
2. [Streamlit Cloud](https://streamlit.io/cloud)에 로그인합니다.
3. "New app"을 클릭하고 저장소를 선택합니다.
4. 환경변수 섹션에서 `OPENAI_API_KEY`를 추가합니다.
5. 배포합니다.

### 다른 플랫폼 배포

환경변수 `OPENAI_API_KEY`를 설정할 수 있는 모든 플랫폼에서 배포 가능합니다:
- Heroku
- Railway
- Render
- AWS/GCP/Azure 등

## 📝 라이선스

이 프로젝트는 MIT 라이선스를 따릅니다.

## 🤝 기여

버그 리포트나 기능 제안은 이슈로 등록해주세요.

## ⚠️ 주의사항

- API 키를 절대 공개 저장소에 커밋하지 마세요.
- `.env` 파일은 `.gitignore`에 추가되어야 합니다.
- OpenAI API 사용 시 비용이 발생할 수 있습니다. 사용량을 모니터링하세요.

