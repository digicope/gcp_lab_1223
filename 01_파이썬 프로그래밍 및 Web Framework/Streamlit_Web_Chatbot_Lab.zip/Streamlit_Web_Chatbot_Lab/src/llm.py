"""
OpenAI API 호출 및 스트리밍 처리 모듈
"""
import os
import base64
from typing import Iterator, List, Dict, Optional
from openai import OpenAI
from dotenv import load_dotenv

from src.utils import format_error_message, log_error

# 환경변수 로드
load_dotenv()

# OpenAI 클라이언트 초기화
def get_openai_client() -> Optional[OpenAI]:
    """
    OpenAI 클라이언트 인스턴스 반환
    
    Returns:
        OpenAI 클라이언트 또는 None (API 키가 없는 경우)
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    return OpenAI(api_key=api_key)


def build_messages(system_prompt: str, conversation_history: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    OpenAI API용 messages 리스트 구성
    
    Args:
        system_prompt: 시스템 프롬프트
        conversation_history: 대화 히스토리 (role, content 포함)
        
    Returns:
        OpenAI API 형식의 messages 리스트
    """
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(conversation_history)
    return messages


def stream_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> Iterator[str]:
    """
    OpenAI 스트리밍 채팅 완성 호출
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 파라미터
        
    Yields:
        스트리밍된 텍스트 청크
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content
    except Exception as e:
        log_error(e, "OpenAI API 호출 중")
        raise


def get_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> str:
    """
    OpenAI 비스트리밍 채팅 완성 호출 (에러 처리용)
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 파라미터
        
    Returns:
        완성된 응답 텍스트
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature
        )
        return response.choices[0].message.content
    except Exception as e:
        log_error(e, "OpenAI API 호출 중")
        raise


def analyze_image_with_vision(
    image_bytes: bytes,
    prompt: str = "이 이미지를 자세히 분석하고 설명해주세요.",
    model: str = "gpt-4o"
) -> str:
    """
    OpenAI Vision API를 사용하여 이미지 분석
    
    Args:
        image_bytes: 이미지 바이트 데이터
        prompt: 이미지 분석 프롬프트
        model: 사용할 모델 (기본값: gpt-4o)
        
    Returns:
        이미지 분석 결과 텍스트
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        # 이미지를 base64로 인코딩
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        # Vision API 호출
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=1000
        )
        
        return response.choices[0].message.content
    except Exception as e:
        log_error(e, "OpenAI Vision API 호출 중")
        raise


def stream_chat_completion_with_image(
    messages: List[Dict],
    model: str,
    temperature: float
) -> Iterator[str]:
    """
    이미지가 포함된 메시지로 스트리밍 채팅 완성 호출
    
    Args:
        messages: 대화 메시지 리스트 (이미지 포함 가능)
        model: 사용할 모델 이름
        temperature: temperature 파라미터
        
    Yields:
        스트리밍된 텍스트 청크
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content
    except Exception as e:
        log_error(e, "OpenAI API 호출 중 (이미지 포함)")
        raise

