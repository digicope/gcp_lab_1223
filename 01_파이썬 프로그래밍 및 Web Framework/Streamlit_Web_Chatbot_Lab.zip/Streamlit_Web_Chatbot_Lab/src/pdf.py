"""
PDF 텍스트 추출 및 처리 모듈
"""
from io import BytesIO
import pdfplumber

from src.utils import log_error


def extract_text_from_pdf(pdf_file) -> tuple[bool, str]:
    """
    PDF 파일에서 텍스트를 추출
    
    Args:
        pdf_file: Streamlit의 uploaded file 객체
        
    Returns:
        (성공 여부, 추출된 텍스트 또는 오류 메시지) 튜플
    """
    try:
        # PDF 파일을 BytesIO로 읽기
        pdf_bytes = BytesIO(pdf_file.getvalue())
        
        # PDF에서 텍스트 추출
        text_parts = []
        with pdfplumber.open(pdf_bytes) as pdf:
            total_pages = len(pdf.pages)
            for page_num, page in enumerate(pdf.pages, 1):
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
        
        if not text_parts:
            return False, "PDF에서 텍스트를 추출할 수 없습니다. 이미지로만 구성된 PDF이거나 스캔된 이미지일 수 있습니다."
        
        # 모든 페이지의 텍스트 결합
        full_text = "\n\n".join(text_parts)
        
        if not full_text.strip():
            return False, "PDF에서 텍스트를 추출할 수 없습니다."
        
        return True, full_text
        
    except Exception as e:
        error_msg = f"PDF 텍스트 추출 중 오류가 발생했습니다: {str(e)}"
        log_error(e, "PDF 텍스트 추출 중")
        return False, error_msg

