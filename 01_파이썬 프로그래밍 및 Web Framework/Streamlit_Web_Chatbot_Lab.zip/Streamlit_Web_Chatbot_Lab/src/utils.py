"""
공통 유틸리티 함수 모듈
로깅, 예외 메시지 포맷팅 등
"""
import logging
import os
import platform
from typing import Optional
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def format_error_message(error: Exception) -> str:
    """
    OpenAI API 에러를 사용자 친화적인 메시지로 변환
    
    Args:
        error: 발생한 예외 객체
        
    Returns:
        사용자 친화적인 에러 메시지
    """
    error_str = str(error).lower()
    error_type = type(error).__name__
    
    # API 키 관련 에러
    if 'api key' in error_str or 'authentication' in error_str or '401' in error_str:
        return "❌ OpenAI API 키가 유효하지 않습니다. 사이드바에서 API 키를 확인해주세요."
    
    # Rate limit 에러
    if 'rate limit' in error_str or '429' in error_str:
        return "⏱️ API 요청 한도에 도달했습니다. 잠시 후 다시 시도해주세요."
    
    # 네트워크 에러
    if 'network' in error_str or 'connection' in error_str or 'timeout' in error_str:
        return "🌐 네트워크 연결 오류가 발생했습니다. 인터넷 연결을 확인해주세요."
    
    # 모델 관련 에러
    if 'model' in error_str or 'not found' in error_str:
        return "🤖 선택한 모델을 사용할 수 없습니다. 다른 모델을 선택해주세요."
    
    # 일반적인 에러
    return f"❌ 오류가 발생했습니다: {error_type} - {str(error)}"


def log_error(error: Exception, context: Optional[str] = None):
    """
    에러를 로깅
    
    Args:
        error: 발생한 예외 객체
        context: 에러 발생 컨텍스트 정보
    """
    if context:
        logger.error(f"{context}: {error}", exc_info=True)
    else:
        logger.error(f"Error occurred: {error}", exc_info=True)


def register_korean_font():
    """
    시스템에 있는 한글 폰트를 찾아서 등록
    """
    # 이미 등록되어 있으면 스킵
    if 'KoreanFont' in pdfmetrics.getRegisteredFontNames():
        return 'KoreanFont'
    
    # Windows 폰트 경로
    system = platform.system()
    font_paths = []
    
    if system == 'Windows':
        # Windows 폰트 디렉토리
        windows_font_dir = os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts')
        # TTF 파일 우선 (TTC는 지원이 제한적)
        font_paths = [
            os.path.join(windows_font_dir, 'malgun.ttf'),      # 맑은 고딕
            os.path.join(windows_font_dir, 'malgunbd.ttf'),   # 맑은 고딕 Bold
            os.path.join(windows_font_dir, 'NanumGothic.ttf'),  # 나눔고딕 (설치된 경우)
            os.path.join(windows_font_dir, 'NanumBarunGothic.ttf'),  # 나눔바른고딕
        ]
        # TTC 파일도 시도
        font_paths.extend([
            os.path.join(windows_font_dir, 'gulim.ttc'),
            os.path.join(windows_font_dir, 'batang.ttc'),
        ])
    elif system == 'Darwin':  # macOS
        font_paths = [
            '/System/Library/Fonts/AppleGothic.ttf',
            '/Library/Fonts/AppleGothic.ttf',
            '/System/Library/Fonts/Supplemental/AppleGothic.ttf',
        ]
    elif system == 'Linux':
        font_paths = [
            '/usr/share/fonts/truetype/nanum/NanumGothic.ttf',
            '/usr/share/fonts/truetype/nanum/NanumBarunGothic.ttf',
            '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
        ]
    
    # 사용 가능한 폰트 찾기
    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                # TTC 파일인 경우 subfontIndex 지정 시도
                if font_path.endswith('.ttc'):
                    # TTC 파일의 첫 번째 폰트 사용
                    pdfmetrics.registerFont(TTFont('KoreanFont', font_path, subfontIndex=0))
                else:
                    pdfmetrics.registerFont(TTFont('KoreanFont', font_path))
                logger.info(f"한글 폰트 등록 성공: {font_path}")
                return 'KoreanFont'
            except Exception as e:
                logger.warning(f"폰트 등록 실패 ({font_path}): {e}")
                continue
    
    # 폰트를 찾지 못한 경우, 기본 폰트 사용 (한글이 깨질 수 있음)
    logger.warning("한글 폰트를 찾을 수 없습니다. 기본 폰트를 사용합니다.")
    return 'Helvetica'


def save_text_to_pdf(text: str, filename: str, title: str = "요약", output_dir: str = "outputs") -> str:
    """
    텍스트를 PDF 파일로 저장
    
    Args:
        text: 저장할 텍스트
        filename: 파일명 (확장자 제외)
        title: PDF 제목
        output_dir: 출력 디렉토리 (기본값: "outputs")
        
    Returns:
        저장된 파일의 전체 경로
    """
    # 한글 폰트 등록
    korean_font = register_korean_font()
    
    # 출력 디렉토리 생성
    os.makedirs(output_dir, exist_ok=True)
    
    # 파일 경로 생성
    if not filename.endswith('.pdf'):
        filename += '.pdf'
    filepath = os.path.join(output_dir, filename)
    
    # PDF 문서 생성
    doc = SimpleDocTemplate(filepath, pagesize=A4)
    story = []
    
    # 스타일 설정
    styles = getSampleStyleSheet()
    
    # 제목 스타일 (한글 폰트 사용)
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1,  # 중앙 정렬
        fontName=korean_font
    )
    
    # 본문 스타일 (한글 폰트 사용)
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['Normal'],
        fontSize=11,
        leading=16,
        spaceAfter=12,
        fontName=korean_font
    )
    
    # 제목 추가
    story.append(Paragraph(title, title_style))
    story.append(Spacer(1, 0.2*inch))
    
    # 텍스트를 줄 단위로 분리하여 처리
    lines = text.split('\n')
    for line in lines:
        if line.strip():
            # 특수 문자 이스케이프 처리
            escaped_line = (line
                          .replace('&', '&amp;')
                          .replace('<', '&lt;')
                          .replace('>', '&gt;')
                          .replace('"', '&quot;')
                          .replace("'", '&#39;'))
            story.append(Paragraph(escaped_line, body_style))
        else:
            story.append(Spacer(1, 0.1*inch))
    
    # PDF 생성
    doc.build(story)
    
    return filepath

