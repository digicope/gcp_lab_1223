"""
채팅 UI 렌더링 함수 모듈
"""
import streamlit as st
from typing import List, Dict, Optional


def render_message(message: Dict[str, str]):
    """
    단일 메시지를 role에 따라 렌더링
    
    Args:
        message: role과 content를 포함한 메시지 딕셔너리
    """
    role = message.get("role", "user")
    content = message.get("content", "")
    
    if role == "user":
        with st.chat_message("user"):
            st.markdown(content)
    elif role == "assistant":
        with st.chat_message("assistant"):
            st.markdown(content)


def render_chat_history(messages: List[Dict[str, str]]):
    """
    전체 대화 히스토리를 렌더링
    
    Args:
        messages: 대화 메시지 리스트 (role, content 포함)
    """
    # 시스템 메시지는 제외하고 렌더링
    for message in messages:
        if message.get("role") != "system":
            render_message(message)


def render_sidebar(
    current_model: str,
    current_temperature: float,
    current_system_prompt: str,
    available_models: List[str]
) -> tuple[str, float, str]:
    """
    사이드바 UI 렌더링 및 설정 반환
    
    Args:
        current_model: 현재 선택된 모델
        current_temperature: 현재 temperature 값
        current_system_prompt: 현재 시스템 프롬프트
        available_models: 사용 가능한 모델 리스트
        
    Returns:
        (선택된 모델, temperature, 시스템 프롬프트) 튜플
    """
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # 모델 선택
        selected_model = st.selectbox(
            "모델 선택",
            options=available_models,
            index=available_models.index(current_model) if current_model in available_models else 0
        )
        
        # Temperature 슬라이더
        temperature = st.slider(
            "Temperature",
            min_value=0.0,
            max_value=1.0,
            value=current_temperature,
            step=0.1,
            help="값이 높을수록 더 창의적인 응답을 생성합니다."
        )
        
        st.divider()
        
        # 시스템 프롬프트 편집
        st.subheader("시스템 프롬프트")
        system_prompt = st.text_area(
            "시스템 프롬프트를 수정할 수 있습니다.",
            value=current_system_prompt,
            height=200,
            help="AI의 행동과 응답 스타일을 제어합니다."
        )
        
        st.divider()
        
        # 대화 초기화 버튼
        if st.button("🗑️ 대화 초기화", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
        
        st.divider()
        
        # API 키 상태 표시
        import os
        from dotenv import load_dotenv
        load_dotenv()
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            st.success("✅ API 키가 설정되었습니다")
        else:
            st.error("❌ API 키가 설정되지 않았습니다")
            st.info("`.env` 파일에 `OPENAI_API_KEY`를 설정해주세요.")
    
    return selected_model, temperature, system_prompt

