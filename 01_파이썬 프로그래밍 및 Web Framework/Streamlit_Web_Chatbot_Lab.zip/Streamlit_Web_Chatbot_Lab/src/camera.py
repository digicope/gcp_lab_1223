"""
OpenCV를 사용한 카메라 제어 모듈
"""
import cv2
import numpy as np
from PIL import Image
from typing import Optional, Tuple
import io
import os
import platform

from src.utils import log_error

# Windows에서 OpenCV 경고 메시지 억제
os.environ['OPENCV_LOG_LEVEL'] = 'ERROR'
# OpenCV 경고 억제
cv2.setLogLevel(0)


def capture_frame_from_camera(camera_index: int = 0) -> Optional[Tuple[np.ndarray, bool]]:
    """
    웹캠에서 프레임 캡처
    
    Args:
        camera_index: 카메라 인덱스 (기본값: 0)
        
    Returns:
        (프레임 배열, 성공 여부) 튜플 또는 None
    """
    cap = None
    try:
        import time
        
        # Windows에서는 DSHOW 백엔드 우선 사용 (테스트 결과 가장 안정적)
        if platform.system() == 'Windows':
            # DSHOW 백엔드 사용 (테스트에서 확인된 가장 안정적인 방법)
            cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
            time.sleep(0.3)
            
            # DSHOW가 실패하면 기본 백엔드 시도
            if not cap.isOpened():
                if cap is not None:
                    cap.release()
                    time.sleep(0.2)
                cap = cv2.VideoCapture(camera_index)
                time.sleep(0.3)
        else:
            cap = cv2.VideoCapture(camera_index)
            time.sleep(0.2)
        
        if not cap.isOpened():
            return None
        
        # 카메라 속성 설정 (설정 실패해도 계속 진행)
        try:
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except:
            pass
        
        # 여러 프레임을 읽어서 안정화 (버퍼 비우기)
        frame = None
        ret = False
        for i in range(5):  # 최대 5번 시도 (테스트에서 충분함)
            ret, frame = cap.read()
            if ret and frame is not None and frame.size > 0:
                break
            time.sleep(0.05)
        
        if ret and frame is not None and frame.size > 0:
            # BGR을 RGB로 변환
            try:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                return frame_rgb, True
            except:
                # 이미 RGB인 경우
                return frame, True
        else:
            return None
            
    except Exception as e:
        log_error(e, "카메라 프레임 캡처 중")
        return None
    finally:
        if cap is not None:
            try:
                cap.release()
                if platform.system() == 'Windows':
                    time.sleep(0.3)  # Windows에서 더 긴 지연
            except:
                pass


def frame_to_image_bytes(frame: np.ndarray, format: str = 'JPEG') -> bytes:
    """
    OpenCV 프레임을 이미지 바이트로 변환
    
    Args:
        frame: OpenCV 프레임 (RGB)
        format: 이미지 포맷 (기본값: 'JPEG')
        
    Returns:
        이미지 바이트 데이터
    """
    try:
        # NumPy 배열을 PIL Image로 변환
        pil_image = Image.fromarray(frame)
        
        # 바이트로 변환
        img_byte_arr = io.BytesIO()
        pil_image.save(img_byte_arr, format=format)
        img_byte_arr.seek(0)
        
        return img_byte_arr.getvalue()
    except Exception as e:
        log_error(e, "프레임을 이미지 바이트로 변환 중")
        return None


def check_camera_available(camera_index: int = 0) -> bool:
    """
    카메라 사용 가능 여부 확인
    
    Args:
        camera_index: 카메라 인덱스 (기본값: 0)
        
    Returns:
        카메라 사용 가능 여부
    """
    cap = None
    try:
        import platform
        if platform.system() == 'Windows':
            # DSHOW 백엔드 시도
            cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
        else:
            cap = cv2.VideoCapture(camera_index)
        
        if not cap.isOpened():
            if platform.system() == 'Windows':
                if cap is not None:
                    cap.release()
                cap = cv2.VideoCapture(camera_index)
        
        if cap.isOpened():
            ret, _ = cap.read()
            if ret:
                return True
        return False
    except:
        return False
    finally:
        if cap is not None:
            try:
                cap.release()
            except:
                pass


def get_camera_frame(camera_index: int = 0) -> Optional[np.ndarray]:
    """
    카메라에서 단일 프레임 가져오기 (미리보기용)
    
    Args:
        camera_index: 카메라 인덱스 (기본값: 0)
        
    Returns:
        프레임 배열 또는 None
    """
    cap = None
    try:
        import platform
        # Windows에서는 DSHOW 백엔드 사용
        if platform.system() == 'Windows':
            cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
        else:
            cap = cv2.VideoCapture(camera_index)
        
        if not cap.isOpened():
            if platform.system() == 'Windows':
                if cap is not None:
                    cap.release()
                cap = cv2.VideoCapture(camera_index)
        
        if not cap.isOpened():
            return None
        
        # 카메라 속성 설정
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        
        # 여러 프레임을 읽어서 안정화
        for _ in range(3):
            ret, frame = cap.read()
            if ret and frame is not None:
                break
        
        if ret and frame is not None:
            # BGR을 RGB로 변환
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            return frame_rgb
        return None
        
    except Exception as e:
        log_error(e, "카메라 프레임 읽기 중")
        return None
    finally:
        if cap is not None:
            try:
                cap.release()
                # Windows에서 카메라 해제 후 약간의 지연
                import platform
                if platform.system() == 'Windows':
                    import time
                    time.sleep(0.1)
            except:
                pass

