"""
카메라 테스트 스크립트
OpenCV를 사용하여 카메라가 정상적으로 작동하는지 테스트합니다.
"""
import cv2
import sys
import platform

def test_camera(camera_index=0):
    """카메라 테스트"""
    print(f"\n{'='*60}")
    print(f"카메라 {camera_index} 테스트 시작")
    print(f"{'='*60}\n")
    
    print(f"운영체제: {platform.system()}")
    print(f"OpenCV 버전: {cv2.__version__}\n")
    
    cap = None
    backends_tried = []
    
    # Windows에서 여러 백엔드 시도
    if platform.system() == 'Windows':
        backends = [
            ("DSHOW", cv2.CAP_DSHOW),
            ("MSMF", cv2.CAP_MSMF),
            ("V4L2", cv2.CAP_V4L2),
            ("기본", cv2.CAP_ANY)
        ]
    else:
        backends = [
            ("V4L2", cv2.CAP_V4L2),
            ("기본", cv2.CAP_ANY)
        ]
    
    for backend_name, backend_id in backends:
        print(f"백엔드 시도: {backend_name} (ID: {backend_id})")
        try:
            cap = cv2.VideoCapture(camera_index, backend_id)
            
            if cap.isOpened():
                print(f"  [OK] 카메라가 열렸습니다!")
                
                # 카메라 속성 읽기
                width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
                height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                fps = cap.get(cv2.CAP_PROP_FPS)
                
                print(f"  해상도: {int(width)}x{int(height)}")
                print(f"  FPS: {fps}")
                
                # 프레임 읽기 테스트
                print(f"  프레임 읽기 테스트...")
                ret, frame = cap.read()
                
                if ret and frame is not None:
                    print(f"  [OK] 프레임 읽기 성공! (크기: {frame.shape})")
                    print(f"  [OK] 백엔드 '{backend_name}'로 카메라 사용 가능!")
                    backends_tried.append((backend_name, True))
                    
                    # 프레임 저장 (테스트용)
                    cv2.imwrite(f"test_camera_{camera_index}_{backend_name}.jpg", frame)
                    print(f"  테스트 이미지 저장: test_camera_{camera_index}_{backend_name}.jpg")
                    
                    cap.release()
                    return True, backend_name
                else:
                    print(f"  [FAIL] 프레임을 읽을 수 없습니다.")
                    backends_tried.append((backend_name, False))
                    if cap is not None:
                        cap.release()
            else:
                print(f"  [FAIL] 카메라를 열 수 없습니다.")
                backends_tried.append((backend_name, False))
                if cap is not None:
                    cap.release()
        except Exception as e:
            print(f"  [ERROR] 오류 발생: {e}")
            backends_tried.append((backend_name, False))
            if cap is not None:
                try:
                    cap.release()
                except:
                    pass
    
    print(f"\n{'='*60}")
    print("테스트 결과 요약:")
    print(f"{'='*60}")
    for backend_name, success in backends_tried:
        status = "[OK] 성공" if success else "[FAIL] 실패"
        print(f"  {backend_name}: {status}")
    
    print(f"\n{'='*60}")
    if not any(success for _, success in backends_tried):
        print(f"[FAIL] 카메라 {camera_index}를 열 수 없습니다.")
        print("\n가능한 원인:")
        print("  1. 카메라가 다른 프로그램에서 사용 중입니다")
        print("  2. 카메라 드라이버가 설치되지 않았습니다")
        print("  3. 해당 인덱스에 카메라가 연결되어 있지 않습니다 (정상일 수 있음)")
        print("  4. 카메라 권한이 없습니다")
        print(f"\n참고: 카메라 {camera_index}가 없을 수도 있습니다. 다른 인덱스를 시도해보세요.")
        return False, None
    else:
        working_backend = next(name for name, success in backends_tried if success)
        print(f"[OK] 작동하는 백엔드: {working_backend}")
        return True, working_backend


if __name__ == "__main__":
    # 여러 카메라 인덱스 테스트
    camera_indices = [0, 1, 2]
    
    print("\n" + "="*60)
    print("카메라 테스트 프로그램")
    print("="*60)
    
    working_cameras = []
    
    for idx in camera_indices:
        success, backend = test_camera(idx)
        if success:
            working_cameras.append((idx, backend))
        print("\n")
    
    print("\n" + "="*60)
    print("최종 결과")
    print("="*60)
    
    if working_cameras:
        print(f"[OK] {len(working_cameras)}개의 카메라가 작동합니다:")
        for idx, backend in working_cameras:
            print(f"  - 카메라 {idx} (백엔드: {backend})")
        print(f"\n권장사항: 앱에서 카메라 인덱스 {working_cameras[0][0]}을 사용하세요.")
    else:
        print("[FAIL] 작동하는 카메라를 찾을 수 없습니다.")
        print("\n해결 방법:")
        print("  1. 다른 프로그램에서 카메라를 닫아주세요")
        print("  2. 카메라 드라이버를 확인하세요")
        print("  3. 카메라가 연결되어 있는지 확인하세요")
        print("  4. Windows 설정 > 개인 정보 > 카메라에서 권한을 확인하세요")
    
    print("\n" + "="*60)

