"""
Streamlit Web Chatbot - 메인 엔트리 포인트
"""
import streamlit as st
import os
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import base64
import numpy as np
import io
import cv2
from PIL import Image
from dotenv import load_dotenv

from src.llm import (
    stream_chat_completion, 
    build_messages, 
    get_openai_client, 
    get_chat_completion,
    analyze_image_with_vision,
    stream_chat_completion_with_image
)
from src.ui import render_chat_history, render_sidebar
from src.prompts import (
    get_default_model,
    get_default_temperature,
    get_default_system_prompt
)
from src.utils import format_error_message, save_text_to_pdf
from src.youtube import extract_video_id, get_transcript, save_text_to_file
from src.pdf import extract_text_from_pdf
from src.excel import parse_quotation_excel, compare_quotations
from src.camera import capture_frame_from_camera, frame_to_image_bytes, check_camera_available
from datetime import datetime

# 환경변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="Streamlit Web Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 사용 가능한 모델 리스트
AVAILABLE_MODELS = [
    "gpt-4o-mini",
    "gpt-4o",
    "gpt-4-turbo",
    "gpt-3.5-turbo"
]

# Vision API 지원 모델
VISION_MODELS = [
    "gpt-4o",
    "gpt-4-turbo"
]


def initialize_session_state():
    """세션 상태 초기화"""
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    if "system_prompt" not in st.session_state:
        st.session_state.system_prompt = get_default_system_prompt()
    
    if "model" not in st.session_state:
        st.session_state.model = get_default_model()
    
    if "temperature" not in st.session_state:
        st.session_state.temperature = get_default_temperature()


def process_quotation_comparison(uploaded_files, model: str, temperature: float, system_prompt: str):
    """견적서 비교 처리 및 분석"""
    if len(uploaded_files) < 3:
        st.error("❌ 최소 3개 이상의 견적서 파일을 업로드해주세요.")
        return
    
    # 모든 견적서 파싱
    quotations = []
    with st.spinner("견적서 파일을 분석하는 중..."):
        for uploaded_file in uploaded_files:
            success, result = parse_quotation_excel(uploaded_file)
            if success:
                quotations.append(result)
            else:
                st.warning(f"⚠️ {uploaded_file.name} 파일 파싱 실패: {result}")
    
    if len(quotations) < 3:
        st.error("❌ 최소 3개 이상의 견적서를 성공적으로 파싱해야 합니다.")
        return
    
    # 견적서 비교
    comparison = compare_quotations(quotations)
    
    # 비교 결과 표시
    st.subheader("📊 견적서 비교 결과")
    
    # 비교 테이블
    comparison_df_data = {
        '견적서 파일명': [q['filename'] for q in comparison['quotations']],
        '총액': [f"{q['total_amount']:,.0f}원" for q in comparison['quotations']],
        '품목 수': [q['item_count'] for q in comparison['quotations']]
    }
    
    comparison_df = pd.DataFrame(comparison_df_data)
    st.dataframe(comparison_df, use_container_width=True)
    
    # 요약 정보 표시
    summary_info = comparison['summary']
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("최저가", f"{summary_info['min_amount']:,.0f}원")
    with col2:
        st.metric("최고가", f"{summary_info['max_amount']:,.0f}원")
    with col3:
        st.metric("평균가", f"{summary_info['avg_amount']:,.0f}원")
    
    # 그래프 섹션
    st.subheader("📈 시각화 분석")
    
    # 그래프 탭 생성
    graph_tab1, graph_tab2, graph_tab3, graph_tab4 = st.tabs([
        "💰 총액 비교", 
        "📊 품목별 가격 비교", 
        "📉 가격 분포", 
        "🔢 품목 수 비교"
    ])
    
    with graph_tab1:
        # 총액 비교 막대 그래프
        quotation_names = [q['filename'] for q in comparison['quotations']]
        total_amounts = [q['total_amount'] for q in comparison['quotations']]
        
        # 최저가 색상 강조
        colors = ['#2ecc71' if amount == min(total_amounts) else '#3498db' if amount == max(total_amounts) else '#95a5a6' 
                 for amount in total_amounts]
        
        fig1 = go.Figure(data=[
            go.Bar(
                x=quotation_names,
                y=total_amounts,
                marker_color=colors,
                text=[f"{amt:,.0f}원" for amt in total_amounts],
                textposition='auto',
            )
        ])
        fig1.update_layout(
            title='견적서별 총액 비교',
            xaxis_title='견적서',
            yaxis_title='총액 (원)',
            height=400,
            showlegend=False
        )
        st.plotly_chart(fig1, use_container_width=True)
        
        # 원형 그래프 (비율)
        fig_pie = go.Figure(data=[go.Pie(
            labels=quotation_names,
            values=total_amounts,
            hole=0.3,
            textinfo='label+percent+value',
            texttemplate='%{label}<br>%{value:,.0f}원<br>(%{percent})'
        )])
        fig_pie.update_layout(
            title='견적서별 총액 비율',
            height=400
        )
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with graph_tab2:
        # 품목별 가격 비교 그래프
        item_comparison = comparison.get('item_comparison', {})
        
        if item_comparison:
            # 품목별로 그룹화된 데이터 준비 (이미 정렬된 순서 사용)
            item_names = list(item_comparison.keys())[:15]  # 최대 15개 품목 표시
            
            if item_names:
                fig2 = go.Figure()
                
                quotation_names = [q['filename'] for q in comparison['quotations']]
                colors_list = px.colors.qualitative.Set3
                
                for idx, quotation_name in enumerate(quotation_names):
                    prices = [item_comparison[item].get(quotation_name) for item in item_names]
                    fig2.add_trace(go.Bar(
                        name=quotation_name,
                        x=item_names,
                        y=prices,
                        marker_color=colors_list[idx % len(colors_list)],
                        text=[f"{p:,.0f}원" if p else "-" for p in prices],
                        textposition='auto',
                    ))
                
                fig2.update_layout(
                    title='품목별 가격 비교',
                    xaxis_title='품목명',
                    yaxis_title='가격 (원)',
                    barmode='group',
                    height=500,
                    xaxis_tickangle=-45
                )
                st.plotly_chart(fig2, use_container_width=True)
                
                # 품목별 최저가 히트맵
                if len(item_names) > 0:
                    heatmap_data = []
                    for item_name in item_names:
                        row_data = []
                        for quotation_name in quotation_names:
                            price = item_comparison[item_name].get(quotation_name)
                            row_data.append(price if price else 0)
                        heatmap_data.append(row_data)
                    
                    fig_heatmap = go.Figure(data=go.Heatmap(
                        z=heatmap_data,
                        x=quotation_names,
                        y=item_names,
                        colorscale='RdYlGn_r',
                        text=[[f"{val:,.0f}원" if val > 0 else "-" for val in row] for row in heatmap_data],
                        texttemplate="%{text}",
                        textfont={"size": 10},
                        hoverongaps=False
                    ))
                    fig_heatmap.update_layout(
                        title='품목별 가격 히트맵 (낮을수록 진한 색)',
                        height=400,
                        xaxis_title='견적서',
                        yaxis_title='품목명'
                    )
                    st.plotly_chart(fig_heatmap, use_container_width=True)
            else:
                st.info("비교할 품목이 없습니다.")
        else:
            st.info("품목별 비교 데이터가 없습니다.")
    
    with graph_tab3:
        # 가격 분포 차트
        quotation_names = [q['filename'] for q in comparison['quotations']]
        total_amounts = [q['total_amount'] for q in comparison['quotations']]
        avg_amount = summary_info['avg_amount']
        
        # 박스 플롯 스타일의 분포 차트
        fig3 = go.Figure()
        
        # 각 견적서의 총액을 점으로 표시
        for idx, (name, amount) in enumerate(zip(quotation_names, total_amounts)):
            fig3.add_trace(go.Scatter(
                x=[name],
                y=[amount],
                mode='markers',
                marker=dict(
                    size=15,
                    color='#e74c3c' if amount == max(total_amounts) else '#2ecc71' if amount == min(total_amounts) else '#3498db',
                    line=dict(width=2, color='white')
                ),
                name=name,
                text=[f"{amount:,.0f}원"],
                textposition='top center',
                showlegend=False
            ))
        
        # 평균선 추가
        fig3.add_hline(
            y=avg_amount, 
            line_dash="dash", 
            line_color="gray",
            annotation_text=f"평균: {avg_amount:,.0f}원",
            annotation_position="right"
        )
        
        fig3.update_layout(
            title='견적서 가격 분포',
            xaxis_title='견적서',
            yaxis_title='총액 (원)',
            height=400,
            showlegend=False
        )
        st.plotly_chart(fig3, use_container_width=True)
        
        # 가격 차이 막대 그래프 (평균 대비)
        diff_from_avg = [amt - avg_amount for amt in total_amounts]
        colors_diff = ['#2ecc71' if diff < 0 else '#e74c3c' for diff in diff_from_avg]
        
        fig_diff = go.Figure(data=[
            go.Bar(
                x=quotation_names,
                y=diff_from_avg,
                marker_color=colors_diff,
                text=[f"{diff:+,.0f}원" for diff in diff_from_avg],
                textposition='auto',
            )
        ])
        fig_diff.add_hline(y=0, line_dash="dash", line_color="gray")
        fig_diff.update_layout(
            title='평균 대비 가격 차이 (음수: 평균보다 저렴, 양수: 평균보다 비쌈)',
            xaxis_title='견적서',
            yaxis_title='가격 차이 (원)',
            height=400,
            showlegend=False
        )
        st.plotly_chart(fig_diff, use_container_width=True)
    
    with graph_tab4:
        # 품목 수 비교
        item_counts = [q['item_count'] for q in comparison['quotations']]
        quotation_names = [q['filename'] for q in comparison['quotations']]
        
        fig4 = go.Figure(data=[
            go.Bar(
                x=quotation_names,
                y=item_counts,
                marker_color='#9b59b6',
                text=[f"{cnt}개" for cnt in item_counts],
                textposition='auto',
            )
        ])
        fig4.update_layout(
            title='견적서별 품목 수 비교',
            xaxis_title='견적서',
            yaxis_title='품목 수',
            height=400,
            showlegend=False
        )
        st.plotly_chart(fig4, use_container_width=True)
        
        # 품목 수와 총액의 관계 (산점도)
        fig_scatter = go.Figure()
        fig_scatter.add_trace(go.Scatter(
            x=item_counts,
            y=total_amounts,
            mode='markers+text',
            marker=dict(size=15, color='#3498db'),
            text=quotation_names,
            textposition='top center',
            name='견적서'
        ))
        fig_scatter.update_layout(
            title='품목 수 vs 총액 관계',
            xaxis_title='품목 수',
            yaxis_title='총액 (원)',
            height=400
        )
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    # 조건 정보 비교
    st.subheader("📋 조건 정보 비교")
    has_terms = any(q.get('terms') for q in comparison['quotations'])
    
    if has_terms:
        # 조건 정보를 테이블로 표시
        terms_categories = ['견적 안내', '제품 특장점', '납품 조건', 'A/S 안내', '결제 조건', '기타']
        
        for term_category in terms_categories:
            term_data = {}
            for q in comparison['quotations']:
                terms = q.get('terms', {})
                if term_category in terms:
                    term_data[q['filename']] = ' '.join(terms[term_category])
                else:
                    term_data[q['filename']] = '-'
            
            # 조건이 하나라도 있으면 표시
            if any(v != '-' for v in term_data.values()):
                st.write(f"**{term_category}**")
                term_df_data = {'견적서': list(term_data.keys()), term_category: list(term_data.values())}
                term_df = pd.DataFrame(term_df_data)
                st.dataframe(term_df, use_container_width=True, hide_index=True)
                st.write("")
    else:
        st.info("조건 정보가 없습니다.")
    
    # 품목별 비교 테이블
    st.subheader("📋 품목별 비교")
    item_comparison = comparison.get('item_comparison', {})
    
    if item_comparison:
        # 품목별 비교 데이터 구성
        item_comparison_data = {'품목명': []}
        quotation_names = [q['filename'] for q in comparison['quotations']]
        for name in quotation_names:
            item_comparison_data[name] = []
        
        for item_name, prices in item_comparison.items():
            item_comparison_data['품목명'].append(item_name)
            for quotation_name in quotation_names:
                price = prices.get(quotation_name)
                if price is not None:
                    item_comparison_data[quotation_name].append(f"{price:,.0f}원")
                else:
                    item_comparison_data[quotation_name].append("-")
        
        item_comparison_df = pd.DataFrame(item_comparison_data)
        st.dataframe(item_comparison_df, use_container_width=True, height=400)
        
        # 품목별 최저가 표시
        with st.expander("💰 품목별 최저가 정보", expanded=False):
            for item_name, prices in item_comparison.items():
                # None이 아닌 가격만 필터링
                valid_prices = {k: v for k, v in prices.items() if v is not None}
                if valid_prices:
                    min_price = min(valid_prices.values())
                    min_quotation = [k for k, v in valid_prices.items() if v == min_price][0]
                    st.write(f"**{item_name}**: {min_price:,.0f}원 ({min_quotation})")
    else:
        st.info("품목별 비교 데이터가 없습니다.")
    
    # 비교 분석 요약 생성
    with st.spinner("견적서 비교 분석을 생성하는 중..."):
        comparison_text = f"""견적서 비교 분석 요청

총 {summary_info['count']}개의 견적서를 비교 분석해주세요.

견적서 정보:
"""
        for q in comparison['quotations']:
            comparison_text += f"\n- {q['filename']}: 총액 {q['total_amount']:,.0f}원, 품목 수 {q['item_count']}개\n"
            if q['items']:
                comparison_text += "  주요 품목:\n"
                for item in q['items'][:3]:
                    comparison_text += f"    - {item['name']}: {item['amount']:,.0f}원\n"
            
            # 조건 정보 추가
            if q.get('terms'):
                comparison_text += "  조건 정보:\n"
                for term_key, term_values in q['terms'].items():
                    if term_values:
                        comparison_text += f"    - {term_key}: {' '.join(term_values)}\n"
        
        comparison_text += f"""
비교 통계:
- 최저가: {summary_info['min_amount']:,.0f}원 ({summary_info['min_quotation']})
- 최고가: {summary_info['max_amount']:,.0f}원
- 평균가: {summary_info['avg_amount']:,.0f}원
- 가격 차이: {summary_info['price_range']:,.0f}원

품목별 비교:
"""
        # 품목별 비교 정보 추가
        item_comparison = comparison.get('item_comparison', {})
        for item_name, prices in item_comparison.items():
            valid_prices = {k: v for k, v in prices.items() if v is not None}
            if valid_prices:
                price_list = ', '.join([f"{k}: {v:,.0f}원" for k, v in valid_prices.items()])
                comparison_text += f"- {item_name}: {price_list}\n"
        
        comparison_text += """
요구사항:
1. 각 견적서의 주요 특징과 장단점을 분석해주세요.
2. 품목별 가격 차이를 분석하고, 어떤 견적서가 각 품목에서 유리한지 설명해주세요.
3. 견적 안내, 납품 조건, A/S 안내, 제품 특장점 등의 조건 정보를 비교 분석해주세요.
4. 가격뿐만 아니라 납기, 보증, A/S 조건 등도 종합적으로 고려하여 최적의 견적서를 선택해주세요.
5. 선택한 최적 견적서와 그 이유를 명확히 설명해주세요 (가격, 조건, 품질 등을 모두 고려).
6. 한국어로 작성해주세요.
"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": comparison_text}
        ]
        
        try:
            analysis = get_chat_completion(
                messages=messages,
                model=model,
                temperature=temperature
            )
            
            # 분석 결과 표시
            st.subheader("📋 견적서 비교 분석 결과")
            st.markdown(analysis)
            
            # 분석 결과를 텍스트 파일로 저장
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            analysis_filename = f"quotation_comparison_{timestamp}.txt"
            analysis_filepath = save_text_to_file(analysis, analysis_filename)
            st.success(f"✅ 비교 분석 결과가 저장되었습니다: `{analysis_filepath}`")
            
        except Exception as e:
            error_message = format_error_message(e)
            st.error(error_message)


def process_pdf_file(uploaded_file, model: str, temperature: float, system_prompt: str):
    """PDF 파일 처리 및 요약"""
    # PDF에서 텍스트 추출
    with st.spinner("PDF에서 텍스트를 추출하는 중..."):
        success, result = extract_text_from_pdf(uploaded_file)
    
    if not success:
        st.error(f"❌ {result}")
        return
    
    extracted_text = result
    
    # 파일명에서 확장자 제거
    original_filename = uploaded_file.name
    file_basename = os.path.splitext(original_filename)[0]
    
    # 추출된 텍스트를 파일로 저장
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    text_filename = f"pdf_text_{file_basename}_{timestamp}.txt"
    text_filepath = save_text_to_file(extracted_text, text_filename)
    st.success(f"✅ 텍스트가 저장되었습니다: `{text_filepath}`")
    
    # 추출된 텍스트 미리보기
    with st.expander("📄 추출된 텍스트 미리보기", expanded=False):
        st.text_area("텍스트 내용", extracted_text[:5000], height=200, disabled=True, 
                    help="처음 5000자만 표시됩니다.")
    
    # 요약 생성
    with st.spinner("문서를 요약하는 중..."):
        summary_prompt = f"""다음은 PDF 문서의 내용입니다. 이 내용을 요약해주세요.

요구사항:
- 주요 내용을 간결하게 요약
- 핵심 포인트를 3-5개로 정리
- 한국어로 작성

문서 내용:
{extracted_text[:8000]}"""  # 토큰 제한을 위해 처음 8000자만 사용
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": summary_prompt}
        ]
        
        try:
            summary = get_chat_completion(
                messages=messages,
                model=model,
                temperature=temperature
            )
            
            # 요약 결과 표시
            st.subheader("📋 요약 결과")
            st.markdown(summary)
            
            # 요약 결과를 텍스트 파일로 저장
            summary_filename_txt = f"summary_{file_basename}_{timestamp}.txt"
            summary_filepath_txt = save_text_to_file(summary, summary_filename_txt)
            st.success(f"✅ 요약이 저장되었습니다: `{summary_filepath_txt}`")
            
            # 요약 결과를 PDF 파일로 저장
            summary_filename_pdf = f"summary_{file_basename}_{timestamp}.pdf"
            summary_filepath_pdf = save_text_to_pdf(summary, summary_filename_pdf, title="문서 요약")
            st.success(f"✅ 요약 PDF가 저장되었습니다: `{summary_filepath_pdf}`")
            
        except Exception as e:
            error_message = format_error_message(e)
            st.error(error_message)


def process_youtube_video(url: str, model: str, temperature: float, system_prompt: str):
    """유튜브 영상 처리 및 요약"""
    # 비디오 ID 추출
    video_id = extract_video_id(url)
    if not video_id:
        st.error("❌ 유효하지 않은 유튜브 URL입니다.")
        return
    
    # 자막 추출
    with st.spinner("자막을 추출하는 중..."):
        success, result = get_transcript(video_id)
    
    if not success:
        st.error(f"❌ {result}")
        st.info("💡 팁: 일부 영상은 자막이 없거나 비활성화되어 있을 수 있습니다. 다른 영상을 시도해보세요.")
        return
    
    transcript_text = result
    
    # 자막 텍스트 파일로 저장
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    transcript_filename = f"transcript_{video_id}_{timestamp}.txt"
    transcript_filepath = save_text_to_file(transcript_text, transcript_filename)
    st.success(f"✅ 자막이 저장되었습니다: `{transcript_filepath}`")
    
    # 자막 미리보기
    with st.expander("📝 추출된 자막 미리보기", expanded=False):
        st.text_area("자막 내용", transcript_text, height=200, disabled=True)
    
    # 요약 생성
    with st.spinner("자막을 요약하는 중..."):
        summary_prompt = f"""다음은 유튜브 영상의 자막입니다. 이 내용을 요약해주세요.

요구사항:
- 주요 내용을 간결하게 요약
- 핵심 포인트를 3-5개로 정리
- 한국어로 작성

자막 내용:
{transcript_text[:8000]}"""  # 토큰 제한을 위해 처음 8000자만 사용
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": summary_prompt}
        ]
        
        try:
            summary = get_chat_completion(
                messages=messages,
                model=model,
                temperature=temperature
            )
            
            # 요약 결과 표시
            st.subheader("📋 요약 결과")
            st.markdown(summary)
            
            # 요약 결과를 텍스트 파일로 저장
            summary_filename_txt = f"summary_{video_id}_{timestamp}.txt"
            summary_filepath_txt = save_text_to_file(summary, summary_filename_txt)
            st.success(f"✅ 요약이 저장되었습니다: `{summary_filepath_txt}`")
            
            # 요약 결과를 PDF 파일로 저장
            summary_filename_pdf = f"summary_{video_id}_{timestamp}.pdf"
            summary_filepath_pdf = save_text_to_pdf(summary, summary_filename_pdf, title="유튜브 영상 요약")
            st.success(f"✅ 요약 PDF가 저장되었습니다: `{summary_filepath_pdf}`")
            
        except Exception as e:
            error_message = format_error_message(e)
            st.error(error_message)


def main():
    """메인 애플리케이션 로직"""
    # 세션 상태 초기화
    initialize_session_state()
    
    # 헤더
    st.title("🤖 Streamlit Web Chatbot")
    st.caption("OpenAI API를 사용하는 대화형 챗봇")
    
    # 사이드바 렌더링 및 설정 업데이트
    selected_model, temperature, system_prompt = render_sidebar(
        current_model=st.session_state.model,
        current_temperature=st.session_state.temperature,
        current_system_prompt=st.session_state.system_prompt,
        available_models=AVAILABLE_MODELS
    )
    
    # 사이드바 설정을 세션 상태에 반영
    st.session_state.model = selected_model
    st.session_state.temperature = temperature
    st.session_state.system_prompt = system_prompt
    
    # API 키 확인
    client = get_openai_client()
    if not client:
        st.error("❌ OpenAI API 키가 설정되지 않았습니다.")
        st.info("`.env` 파일에 `OPENAI_API_KEY`를 설정하거나, 사이드바에서 확인해주세요.")
        st.stop()
    
    # 탭 생성
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "💬 챗봇", 
        "📷 멀티모달 챗봇", 
        "📺 유튜브 자막 요약", 
        "📄 PDF 문서 요약", 
        "📊 견적서 비교"
    ])
    
    # 멀티모달 챗봇용 세션 상태 초기화
    if "multimodal_messages" not in st.session_state:
        st.session_state.multimodal_messages = []
    
    # 챗봇 탭 (기존 텍스트 챗봇)
    with tab1:
        # 대화 히스토리 렌더링
        if st.session_state.messages:
            render_chat_history(st.session_state.messages)
        else:
            st.info("👋 안녕하세요! 메시지를 입력하여 대화를 시작하세요.")
        
        # 사용자 입력 처리
        if prompt := st.chat_input("메시지를 입력하세요..."):
            # 사용자 메시지를 세션 상태에 추가
            st.session_state.messages.append({
                "role": "user",
                "content": prompt
            })
            
            # 사용자 메시지 즉시 표시
            with st.chat_message("user"):
                st.markdown(prompt)
            
            # 어시스턴트 응답 생성
            with st.chat_message("assistant"):
                message_placeholder = st.empty()
                status_placeholder = st.empty()
                full_response = ""
                
                try:
                    # 로딩 인디케이터 표시
                    with status_placeholder:
                        st.spinner("응답을 생성하는 중...")
                    
                    # 메시지 구성
                    messages = build_messages(
                        system_prompt=st.session_state.system_prompt,
                        conversation_history=st.session_state.messages
                    )
                    
                    # 스트리밍 응답 생성
                    first_chunk = True
                    for chunk in stream_chat_completion(
                        messages=messages,
                        model=st.session_state.model,
                        temperature=st.session_state.temperature
                    ):
                        if first_chunk:
                            # 첫 번째 청크가 도착하면 로딩 인디케이터 제거
                            status_placeholder.empty()
                            first_chunk = False
                        
                        full_response += chunk
                        message_placeholder.markdown(full_response + "▌")
                    
                    # 최종 응답 표시 (커서 제거)
                    message_placeholder.markdown(full_response)
                    status_placeholder.empty()
                    
                    # 어시스턴트 응답을 세션 상태에 추가
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": full_response
                    })
                    
                except Exception as e:
                    error_message = format_error_message(e)
                    message_placeholder.error(error_message)
                    st.error(error_message)
    
    # 멀티모달 챗봇 탭
    with tab2:
        st.header("📷 멀티모달 챗봇")
        st.markdown("이미지 파일을 업로드하거나 카메라로 촬영하여 AI가 분석해드립니다.")
        
        # 이미지 분석 함수 (호출 전에 정의)
        def analyze_image(image_bytes, image_obj, image_source="이미지"):
            """이미지 분석 공통 함수"""
            # 사용자 메시지를 세션 상태에 추가
            st.session_state.multimodal_messages.append({
                "role": "user",
                "content": f"📷 {image_source} 분석 요청",
                "image": image_obj
            })
            
            # 사용자 메시지 표시
            with st.chat_message("user"):
                st.image(image_obj, use_container_width=True)
                st.markdown(f"📷 {image_source} 분석 요청")
            
            # 어시스턴트 응답 생성
            with st.chat_message("assistant"):
                message_placeholder = st.empty()
                status_placeholder = st.empty()
                
                try:
                    # 로딩 인디케이터 표시
                    with status_placeholder:
                        st.spinner("이미지를 분석하는 중...")
                    
                    # Vision API로 이미지 분석
                    analysis_result = analyze_image_with_vision(
                        image_bytes=image_bytes,
                        prompt="이 이미지를 자세히 분석하고 설명해주세요. 한국어로 답변해주세요.",
                        model="gpt-4o"
                    )
                    
                    # 분석 결과 표시
                    status_placeholder.empty()
                    message_placeholder.markdown(analysis_result)
                    
                    # 어시스턴트 응답을 세션 상태에 추가
                    st.session_state.multimodal_messages.append({
                        "role": "assistant",
                        "content": analysis_result
                    })
                    
                    st.rerun()
                    
                except Exception as e:
                    error_message = format_error_message(e)
                    message_placeholder.error(error_message)
                    st.error(error_message)
        
        # 대화 히스토리 렌더링
        if st.session_state.multimodal_messages:
            for msg in st.session_state.multimodal_messages:
                with st.chat_message(msg["role"]):
                    if msg["role"] == "user":
                        if "image" in msg:
                            st.image(msg["image"], use_container_width=True, caption="업로드된 이미지")
                        st.markdown(msg["content"])
                    else:
                        st.markdown(msg["content"])
        else:
            st.info("👋 이미지 파일을 업로드하거나 카메라로 촬영하여 시작하세요.")
        
        # 이미지 입력 섹션 (파일 업로드를 우선으로)
        st.subheader("📁 이미지 업로드 또는 촬영")
        
        # 파일 업로드 (주요 방법)
        uploaded_image = st.file_uploader(
            "이미지 파일을 선택하세요 (권장)",
            type=['png', 'jpg', 'jpeg', 'gif', 'webp'],
            key="multimodal_upload",
            help="PNG, JPG, JPEG, GIF, WEBP 형식의 이미지를 업로드할 수 있습니다. 카메라가 작동하지 않는 경우 이 방법을 사용하세요."
        )
        
        # OpenCV 카메라 입력
        st.write("---")
        st.subheader("📷 OpenCV 카메라로 촬영")
        
        st.info("💡 **팁**: 카메라가 작동하지 않는 경우, 위의 파일 업로드를 사용하세요. 카메라를 사용하려면 다른 프로그램에서 카메라를 닫아주세요.")
        
        # 카메라 인덱스 선택
        camera_index = st.selectbox(
            "카메라 선택",
            options=[0, 1, 2],
            index=0,
            help="사용할 카메라 인덱스를 선택하세요. 기본값은 0입니다."
        )
        
        # 카메라 테스트 버튼
        if st.button("🔍 카메라 연결 테스트", use_container_width=True, key="test_camera"):
            with st.spinner("카메라를 확인하는 중..."):
                camera_available = check_camera_available(camera_index)
                if camera_available:
                    st.success(f"✅ 카메라 {camera_index}가 정상적으로 연결되었습니다!")
                else:
                    st.error(f"❌ 카메라 {camera_index}를 찾을 수 없습니다. 다른 카메라 인덱스를 시도하거나 파일 업로드를 사용하세요.")
        
        # 사진 촬영 버튼
        if st.button("📸 사진 촬영", type="primary", use_container_width=True, key="capture_photo"):
            with st.spinner("카메라에서 이미지를 캡처하는 중..."):
                result = capture_frame_from_camera(camera_index)
                
                if result:
                    frame, success = result
                    if success:
                        # 프레임을 이미지로 변환
                        pil_image = Image.fromarray(frame)
                        
                        # 세션 상태에 저장
                        st.session_state.captured_image = pil_image
                        st.session_state.captured_frame = frame
                        st.success("✅ 이미지가 성공적으로 캡처되었습니다!")
                        st.rerun()
                    else:
                        st.error("이미지 캡처에 실패했습니다.")
                else:
                    st.error(f"""
                    ❌ 카메라에서 이미지를 읽을 수 없습니다.
                    
                    **가능한 원인:**
                    - 카메라가 다른 프로그램에서 사용 중입니다
                    - 카메라 권한이 없습니다
                    - 카메라 드라이버 문제
                    - 잘못된 카메라 인덱스
                    
                    **해결 방법:**
                    1. 다른 프로그램에서 카메라를 닫아주세요
                    2. 위의 파일 업로드를 사용하세요
                    3. 다른 카메라 인덱스를 시도해보세요
                    """)
        
        # 캡처된 이미지 표시
        if "captured_image" in st.session_state:
            st.write("---")
            st.subheader("📸 촬영된 이미지")
            st.image(st.session_state.captured_image, caption="촬영된 이미지", use_container_width=True)
            
            col1, col2 = st.columns([1, 1])
            with col1:
                if st.button("📤 이미지 분석하기", type="primary", use_container_width=True, key="analyze_camera_opencv"):
                    # 프레임을 이미지 바이트로 변환
                    frame = st.session_state.captured_frame
                    image_bytes = frame_to_image_bytes(frame)
                    
                    if image_bytes:
                        analyze_image(image_bytes, st.session_state.captured_image, "카메라 촬영")
                    else:
                        st.error("이미지를 변환하는 중 오류가 발생했습니다.")
            
            with col2:
                if st.button("🔄 다시 촬영", use_container_width=True, key="retake_photo"):
                    if "captured_image" in st.session_state:
                        del st.session_state.captured_image
                    if "captured_frame" in st.session_state:
                        del st.session_state.captured_frame
                    st.rerun()
        
        # 업로드된 이미지 처리
        if uploaded_image is not None:
            st.image(uploaded_image, caption="업로드된 이미지", use_container_width=True)
            
            if st.button("📤 이미지 분석하기", type="primary", use_container_width=True, key="analyze_upload"):
                image_bytes = uploaded_image.getvalue()
                analyze_image(image_bytes, uploaded_image, f"파일: {uploaded_image.name}")
        
        # 대화 초기화 버튼
        if st.session_state.multimodal_messages:
            st.write("---")
            if st.button("🗑️ 대화 초기화", use_container_width=True, key="clear_multimodal"):
                st.session_state.multimodal_messages = []
                st.rerun()
    
    # 유튜브 자막 요약 탭
    with tab3:
        st.header("📺 유튜브 영상 자막 추출 및 요약")
        st.markdown("유튜브 영상 URL을 입력하면 자막을 추출하고 요약해드립니다.")
        
        youtube_url = st.text_input(
            "유튜브 URL",
            placeholder="https://www.youtube.com/watch?v=... 또는 https://youtu.be/...",
            help="유튜브 영상 URL을 입력해주세요."
        )
        
        if st.button("🚀 자막 추출 및 요약", type="primary", use_container_width=True):
            if youtube_url:
                process_youtube_video(
                    url=youtube_url,
                    model=st.session_state.model,
                    temperature=st.session_state.temperature,
                    system_prompt=st.session_state.system_prompt
                )
            else:
                st.warning("⚠️ 유튜브 URL을 입력해주세요.")
    
    # PDF 문서 요약 탭
    with tab4:
        st.header("📄 PDF 문서 텍스트 추출 및 요약")
        st.markdown("PDF 파일을 업로드하면 텍스트를 추출하고 요약해드립니다.")
        
        uploaded_file = st.file_uploader(
            "PDF 파일 선택",
            type=['pdf'],
            help="PDF 파일을 업로드해주세요."
        )
        
        if uploaded_file is not None:
            # 파일 정보 표시
            col1, col2 = st.columns(2)
            with col1:
                st.info(f"📄 파일명: {uploaded_file.name}")
            with col2:
                file_size = len(uploaded_file.getvalue()) / 1024  # KB
                st.info(f"📊 파일 크기: {file_size:.2f} KB")
            
            if st.button("🚀 텍스트 추출 및 요약", type="primary", use_container_width=True):
                process_pdf_file(
                    uploaded_file=uploaded_file,
                    model=st.session_state.model,
                    temperature=st.session_state.temperature,
                    system_prompt=st.session_state.system_prompt
                )
    
    # 견적서 비교 탭
    with tab5:
        st.header("📊 견적서 비교 분석")
        st.markdown("엑셀 견적서 파일을 3개 이상 업로드하면 견적서를 비교 분석해드립니다.")
        
        uploaded_files = st.file_uploader(
            "견적서 엑셀 파일 선택 (3개 이상)",
            type=['xlsx', 'xls'],
            accept_multiple_files=True,
            help="엑셀 견적서 파일을 3개 이상 업로드해주세요."
        )
        
        if uploaded_files:
            st.info(f"📁 업로드된 파일: {len(uploaded_files)}개")
            
            # 업로드된 파일 목록 표시
            if len(uploaded_files) > 0:
                with st.expander("📋 업로드된 파일 목록", expanded=True):
                    for idx, file in enumerate(uploaded_files, 1):
                        file_size = len(file.getvalue()) / 1024  # KB
                        st.write(f"{idx}. {file.name} ({file_size:.2f} KB)")
            
            if len(uploaded_files) < 3:
                st.warning("⚠️ 최소 3개 이상의 견적서 파일을 업로드해주세요.")
            else:
                if st.button("🚀 견적서 비교 분석", type="primary", use_container_width=True):
                    process_quotation_comparison(
                        uploaded_files=uploaded_files,
                        model=st.session_state.model,
                        temperature=st.session_state.temperature,
                        system_prompt=st.session_state.system_prompt
                    )


if __name__ == "__main__":
    main()

