"""
시스템 프롬프트 및 기본 설정 모듈
"""
import os
from dotenv import load_dotenv

# 환경변수 로드
load_dotenv()

# 기본 설정
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
DEFAULT_TEMPERATURE = 0.7
DEFAULT_SYSTEM_PROMPT = """당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 
사용자의 질문에 정확하고 유용한 답변을 제공해주세요.
한국어로 대화합니다."""


def get_default_model() -> str:
    """기본 모델 이름 반환"""
    return DEFAULT_MODEL


def get_default_temperature() -> float:
    """기본 temperature 값 반환"""
    return DEFAULT_TEMPERATURE


def get_default_system_prompt() -> str:
    """기본 시스템 프롬프트 반환"""
    return DEFAULT_SYSTEM_PROMPT

