"""
엑셀 견적서 파싱 및 비교 모듈
"""
import pandas as pd
from typing import List, Dict, Optional, Tuple
from io import BytesIO

from src.utils import log_error


def parse_quotation_excel(excel_file) -> Tuple[bool, Dict]:
    """
    엑셀 견적서 파일을 파싱하여 주요 정보 추출
    
    Args:
        excel_file: Streamlit의 uploaded file 객체
        
    Returns:
        (성공 여부, 파싱된 데이터 또는 오류 메시지) 튜플
    """
    try:
        # 엑셀 파일 읽기
        excel_bytes = BytesIO(excel_file.getvalue())
        
        # 첫 번째 시트 읽기
        df = pd.read_excel(excel_bytes, sheet_name=0, header=None)
        
        # 파일명 저장
        filename = excel_file.name
        
        # 견적서 정보 추출
        quotation_data = {
            'filename': filename,
            'items': [],
            'total_amount': None,
            'terms': {},  # 견적 안내, 납품 조건, A/S 안내 등
            'raw_data': df
        }
        
        # 총액 찾기 (다양한 패턴 시도)
        total_keywords = ['총액', '합계', 'total', '합계금액', '총합', '합계', 'TOTAL', 'Total']
        
        # 데이터프레임에서 총액 찾기
        for idx, row in df.iterrows():
            row_str = ' '.join([str(val) for val in row.values if pd.notna(val)])
            for keyword in total_keywords:
                if keyword in str(row_str).lower():
                    # 다음 행이나 같은 행에서 숫자 찾기
                    for col_idx, cell in enumerate(row):
                        if pd.notna(cell):
                            cell_str = str(cell)
                            # 숫자 추출 (쉼표 제거)
                            if any(char.isdigit() for char in cell_str):
                                try:
                                    # 숫자만 추출
                                    numbers = ''.join([c for c in cell_str.replace(',', '') if c.isdigit() or c == '.'])
                                    if numbers:
                                        amount = float(numbers)
                                        if amount > 0:
                                            quotation_data['total_amount'] = amount
                                            break
                                except:
                                    pass
                    if quotation_data['total_amount']:
                        break
            if quotation_data['total_amount']:
                break
        
        # 헤더 행 찾기 (수량, 설명, 단가, 총액 등)
        header_keywords = ['수량', '설명', '단가', '총액', '품목', '항목', '내용', '금액']
        header_row_idx = None
        
        for idx, row in df.iterrows():
            row_str = ' '.join([str(val) for val in row.values if pd.notna(val)]).lower()
            # 헤더 키워드가 2개 이상 포함된 행을 헤더로 간주
            keyword_count = sum(1 for keyword in header_keywords if keyword in row_str)
            if keyword_count >= 2:
                header_row_idx = idx
                break
        
        # 품목 추출 (헤더 행 다음부터, 총액 행 이전까지)
        items = []
        if header_row_idx is not None:
            # 헤더 행에서 "총액" 컬럼 인덱스 찾기
            header_row = df.iloc[header_row_idx]
            total_col_idx = None
            for col_idx, cell in enumerate(header_row):
                if pd.notna(cell):
                    cell_str = str(cell).lower()
                    if any(keyword in cell_str for keyword in ['총액', '합계', 'total', '금액']):
                        total_col_idx = col_idx
                        break
            
            # 설명 컬럼 인덱스 찾기
            desc_col_idx = None
            for col_idx, cell in enumerate(header_row):
                if pd.notna(cell):
                    cell_str = str(cell).lower()
                    if any(keyword in cell_str for keyword in ['설명', '품목', '항목', '내용', 'description']):
                        desc_col_idx = col_idx
                        break
            
            # 헤더 다음 행부터 데이터 추출
            for idx in range(header_row_idx + 1, len(df)):
                row = df.iloc[idx]
                row_str = ' '.join([str(val) for val in row.values if pd.notna(val)])
                
                # 빈 행이거나 "합계", "총액" 같은 키워드가 포함된 행은 건너뛰기
                if not row_str.strip():
                    continue
                if any(keyword in row_str.lower() for keyword in ['합계', '총액', 'total', '합계금액']):
                    break
                
                # 총액 컬럼에서 값 추출
                total_amount = None
                if total_col_idx is not None and total_col_idx < len(row):
                    cell = row.iloc[total_col_idx]
                    if pd.notna(cell):
                        try:
                            cell_str = str(cell).replace(',', '').replace(' ', '')
                            numbers = ''.join([c for c in cell_str if c.isdigit() or c == '.'])
                            if numbers:
                                total_amount = float(numbers)
                        except:
                            pass
                
                # 총액 컬럼을 찾지 못한 경우, 모든 컬럼에서 큰 숫자 찾기
                if total_amount is None or total_amount == 0:
                    for col_idx, cell in enumerate(row):
                        if pd.notna(cell):
                            try:
                                cell_str = str(cell).replace(',', '').replace(' ', '')
                                numbers = ''.join([c for c in cell_str if c.isdigit() or c == '.'])
                                if numbers:
                                    amount = float(numbers)
                                    # 합리적인 금액 범위 (1000원 이상, 1억원 이하)
                                    if 1000 <= amount <= 100000000:
                                        total_amount = amount
                                        break
                            except:
                                pass
                
                # 설명 컬럼에서 품목명 추출
                item_name = ''
                if desc_col_idx is not None and desc_col_idx < len(row):
                    cell = row.iloc[desc_col_idx]
                    if pd.notna(cell):
                        item_name = str(cell).strip()
                
                # 품목명을 찾지 못한 경우, 첫 번째 비어있지 않은 컬럼 사용
                if not item_name:
                    for col_idx, cell in enumerate(row):
                        if pd.notna(cell):
                            cell_str = str(cell).strip()
                            # 숫자만 있는 셀은 건너뛰기
                            if cell_str and not cell_str.replace(',', '').replace('.', '').isdigit():
                                item_name = cell_str
                                break
                
                # 총액이 있고 품목명이 있으면 추가
                if total_amount and total_amount > 0 and item_name:
                    items.append({
                        'name': item_name[:100],  # 품목명 길이 제한
                        'amount': total_amount
                    })
        else:
            # 헤더를 찾지 못한 경우 기존 로직 사용 (하지만 더 엄격하게)
            for idx, row in df.iterrows():
                row_data = [str(val) if pd.notna(val) else '' for val in row.values]
                # 빈 행 제외
                if not any(cell.strip() for cell in row_data if cell):
                    continue
                
                # "합계", "총액" 같은 키워드가 포함된 행은 건너뛰기
                row_str = ' '.join(row_data).lower()
                if any(keyword in row_str for keyword in ['합계', '총액', 'total', '합계금액']):
                    continue
                
                # 첫 번째 컬럼이 항목명, 마지막 컬럼이 금액인 경우
                if len(row_data) >= 2:
                    item_name = row_data[0].strip()
                    # 마지막 컬럼에서 금액 추출
                    for cell in reversed(row_data[1:]):
                        if cell:
                            try:
                                cell_str = str(cell).replace(',', '').replace(' ', '')
                                numbers = ''.join([c for c in cell_str if c.isdigit() or c == '.'])
                                if numbers:
                                    amount = float(numbers)
                                    if amount > 1000:  # 최소 금액 필터 (노이즈 제거)
                                        items.append({
                                            'name': item_name[:100],
                                            'amount': amount
                                        })
                                        break
                            except:
                                pass
        
        quotation_data['items'] = items
        
        # 총액이 없으면 항목들의 합으로 계산
        if quotation_data['total_amount'] is None and items:
            quotation_data['total_amount'] = sum(item['amount'] for item in items)
        
        # 하단 조건 정보 추출 (총액 행 이후)
        # 총액 행 찾기 (이미 찾은 총액 근처 또는 합계 행)
        total_row_idx = None
        
        # 먼저 합계/총액 키워드가 있는 행 찾기
        for idx, row in df.iterrows():
            row_str = ' '.join([str(val) for val in row.values if pd.notna(val)]).lower()
            if any(keyword in row_str for keyword in ['총액', '합계', 'total', '합계금액', '소계']):
                # 큰 숫자가 포함된 경우 총액 행으로 간주
                for cell in row:
                    if pd.notna(cell):
                        cell_str = str(cell).replace(',', '').replace(' ', '')
                        numbers = ''.join([c for c in cell_str if c.isdigit() or c == '.'])
                        if numbers:
                            try:
                                amount = float(numbers)
                                # 합리적인 총액 범위 (10만원 이상)
                                if amount >= 100000:
                                    total_row_idx = idx
                                    break
                            except:
                                pass
                if total_row_idx is not None:
                    break
        
        # 총액 행을 찾지 못한 경우, 마지막 품목 행 이후로 추정
        if total_row_idx is None and items:
            # 마지막 품목이 있는 행 찾기
            last_item_row = None
            for idx, row in df.iterrows():
                for item in items:
                    row_str = ' '.join([str(val) for val in row.values if pd.notna(val)])
                    if item['name'] in row_str:
                        last_item_row = idx
                        break
                if last_item_row is not None:
                    break
            if last_item_row is not None:
                total_row_idx = last_item_row + 1
        
        # 총액 행 이후의 정보 추출
        if total_row_idx is not None:
            terms_keywords = {
                '견적 안내': ['견적 안내', '견적안내', '견적 안내사항', '유의사항'],
                '제품 특장점': ['제품 특장점', '제품특장점', '특장점', '제품 특징', '제품특징'],
                '납품 조건': ['납품 조건', '납품조건', '납기', '납기 조건', '납기조건', '배송 조건', '배송조건'],
                'A/S 안내': ['A/S 안내', 'A/S안내', 'AS 안내', 'AS안내', '보증', '보증 기간', '보증기간', '무상 A/S', '무상AS'],
                '결제 조건': ['결제 조건', '결제조건', '지불 조건', '지불조건', '대금 지불', '대금지불'],
                '기타': ['기타', '비고', '참고사항', '참고 사항', '주의사항', '주의 사항']
            }
            
            for idx in range(total_row_idx + 1, len(df)):
                row = df.iloc[idx]
                row_str = ' '.join([str(val) for val in row.values if pd.notna(val)])
                
                if not row_str.strip():
                    continue
                
                # 각 조건 키워드 확인
                for term_key, keywords in terms_keywords.items():
                    for keyword in keywords:
                        if keyword in row_str:
                            # 해당 행의 내용 추출
                            content_parts = []
                            for cell in row.values:
                                if pd.notna(cell):
                                    cell_str = str(cell).strip()
                                    if cell_str and cell_str != keyword:
                                        content_parts.append(cell_str)
                            
                            # 다음 행들도 확인 (같은 섹션일 수 있음)
                            next_content = []
                            for next_idx in range(idx + 1, min(idx + 10, len(df))):
                                next_row = df.iloc[next_idx]
                                next_row_str = ' '.join([str(val) for val in next_row.values if pd.notna(val)])
                                
                                # 빈 행이면 건너뛰기
                                if not next_row_str.strip():
                                    continue
                                
                                # 새로운 섹션이 시작되면 중단 (다른 키워드가 있으면)
                                is_new_section = False
                                for other_key, other_keywords in terms_keywords.items():
                                    if other_key != term_key:
                                        for other_kw in other_keywords:
                                            if other_kw in next_row_str:
                                                is_new_section = True
                                                break
                                    if is_new_section:
                                        break
                                
                                if is_new_section:
                                    break
                                
                                # 숫자만 있는 행은 건너뛰기 (품목 행일 수 있음)
                                is_number_only = True
                                for cell in next_row.values:
                                    if pd.notna(cell):
                                        cell_str = str(cell).strip()
                                        if cell_str and not cell_str.replace(',', '').replace('.', '').isdigit():
                                            is_number_only = False
                                            break
                                
                                if not is_number_only:
                                    for cell in next_row.values:
                                        if pd.notna(cell):
                                            cell_str = str(cell).strip()
                                            if cell_str and not cell_str.replace(',', '').replace('.', '').isdigit():
                                                next_content.append(cell_str)
                            
                            # 내용 합치기
                            all_content = ' '.join(content_parts + next_content)
                            if all_content:
                                if term_key not in quotation_data['terms']:
                                    quotation_data['terms'][term_key] = []
                                quotation_data['terms'][term_key].append(all_content)
                            break
        
        return True, quotation_data
        
    except Exception as e:
        error_msg = f"엑셀 파일 파싱 중 오류가 발생했습니다: {str(e)}"
        log_error(e, "엑셀 견적서 파싱 중")
        return False, error_msg


def compare_quotations(quotations: List[Dict]) -> Dict:
    """
    여러 견적서를 비교 분석
    
    Args:
        quotations: 견적서 데이터 리스트
        
    Returns:
        비교 분석 결과 딕셔너리
    """
    if len(quotations) < 2:
        return {'error': '비교할 견적서가 2개 이상 필요합니다.'}
    
    # 총액 비교
    total_amounts = [q.get('total_amount', 0) for q in quotations]
    min_amount = min(total_amounts)
    max_amount = max(total_amounts)
    avg_amount = sum(total_amounts) / len(total_amounts)
    
    # 최저가 견적서 찾기
    min_index = total_amounts.index(min_amount)
    min_quotation = quotations[min_index]
    
    # 품목별 비교를 위한 항목 매칭
    # 모든 견적서의 항목명을 수집
    all_item_names = set()
    for q in quotations:
        for item in q.get('items', []):
            all_item_names.add(item['name'].strip())
    
    # 각 견적서별로 항목별 가격 매핑
    item_comparison = {}
    for item_name in all_item_names:
        item_comparison[item_name] = {}
        for q in quotations:
            # 항목명이 정확히 일치하거나 유사한 항목 찾기
            matched_item = None
            for item in q.get('items', []):
                if item['name'].strip() == item_name:
                    matched_item = item
                    break
                # 부분 일치도 시도 (유사도 기반)
                elif item_name in item['name'] or item['name'] in item_name:
                    if not matched_item:  # 첫 번째 매칭만 사용
                        matched_item = item
            
            if matched_item:
                item_comparison[item_name][q['filename']] = matched_item['amount']
            else:
                item_comparison[item_name][q['filename']] = None
    
    # 비교 데이터 구성
    comparison_data = {
        'quotations': [],
        'item_comparison': item_comparison,
        'summary': {
            'count': len(quotations),
            'min_amount': min_amount,
            'max_amount': max_amount,
            'avg_amount': avg_amount,
            'min_quotation': min_quotation['filename'],
            'price_range': max_amount - min_amount,
            'price_variance': max_amount / min_amount if min_amount > 0 else 0
        }
    }
    
    # 각 견적서 정보 정리
    for q in quotations:
        comparison_data['quotations'].append({
            'filename': q['filename'],
            'total_amount': q.get('total_amount', 0),
            'item_count': len(q.get('items', [])),
            'items': q.get('items', []),  # 모든 항목 포함
            'terms': q.get('terms', {})  # 조건 정보 포함
        })
    
    return comparison_data

