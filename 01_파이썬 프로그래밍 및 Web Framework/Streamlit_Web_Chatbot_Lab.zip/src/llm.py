"""
OpenAI API 호출 및 스트리밍 처리 모듈
"""
import os
from typing import Iterator, List, Dict, Optional
from openai import OpenAI
from dotenv import load_dotenv

from src.utils import format_error_message, log_error

# 환경변수 로드
load_dotenv()

# OpenAI 클라이언트 초기화
def get_openai_client() -> Optional[OpenAI]:
    """
    OpenAI 클라이언트 인스턴스 반환
    
    Returns:
        OpenAI 클라이언트 또는 None (API 키가 없는 경우)
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    return OpenAI(api_key=api_key)


def build_messages(system_prompt: str, conversation_history: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    OpenAI API용 messages 리스트 구성
    
    Args:
        system_prompt: 시스템 프롬프트
        conversation_history: 대화 히스토리 (role, content 포함)
        
    Returns:
        OpenAI API 형식의 messages 리스트
    """
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(conversation_history)
    return messages


def stream_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> Iterator[str]:
    """
    OpenAI 스트리밍 채팅 완성 호출
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 파라미터
        
    Yields:
        스트리밍된 텍스트 청크
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content
    except Exception as e:
        log_error(e, "OpenAI API 호출 중")
        raise


def get_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> str:
    """
    OpenAI 비스트리밍 채팅 완성 호출 (에러 처리용)
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 파라미터
        
    Returns:
        완성된 응답 텍스트
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    if not client:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature
        )
        return response.choices[0].message.content
    except Exception as e:
        log_error(e, "OpenAI API 호출 중")
        raise

