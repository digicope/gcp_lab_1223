"""
유튜브 자막 추출 및 처리 모듈
"""
import re
import os
from typing import Optional, List
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api.formatters import TextFormatter
from youtube_transcript_api._errors import (
    TranscriptsDisabled,
    NoTranscriptFound,
    VideoUnavailable
)

from src.utils import log_error


def extract_video_id(url: str) -> Optional[str]:
    """
    유튜브 URL에서 비디오 ID 추출
    
    Args:
        url: 유튜브 URL
        
    Returns:
        비디오 ID 또는 None
    """
    if 'watch?v=' in url:
        video_id = url.split('watch?v=')[1].split('&')[0]
    elif 'youtu.be/' in url:
        video_id = url.split('youtu.be/')[1].split('?')[0]
    else:
        # 이미 비디오 ID인 경우
        video_id = url if len(url) == 11 else None
    
    return video_id


def get_transcript(video_id: str, languages: List[str] = ['ko', 'en']) -> tuple[bool, str]:
    """
    유튜브 비디오의 자막을 추출하여 텍스트로 반환
    
    Args:
        video_id: 유튜브 비디오 ID
        languages: 우선순위 언어 리스트 (기본값: ['ko', 'en'])
        
    Returns:
        (성공 여부, 자막 텍스트 또는 오류 메시지) 튜플
    """
    try:
        # YouTubeTranscriptApi 인스턴스 생성
        yt_api = YouTubeTranscriptApi()
        
        # 자막 가져오기 (여러 언어 시도)
        transcript = yt_api.fetch(video_id, languages=languages)
        
        # TextFormatter를 사용하여 텍스트로 변환
        formatter = TextFormatter()
        text = formatter.format_transcript(transcript)
        
        return True, text
        
    except TranscriptsDisabled:
        error_msg = "이 비디오는 자막이 비활성화되어 있습니다."
        log_error(Exception(error_msg), "유튜브 자막 추출 중")
        return False, error_msg
    except NoTranscriptFound:
        error_msg = "사용 가능한 자막을 찾을 수 없습니다. 다른 언어의 자막이 있는지 확인해주세요."
        log_error(Exception(error_msg), "유튜브 자막 추출 중")
        return False, error_msg
    except VideoUnavailable:
        error_msg = "비디오를 사용할 수 없습니다. 비디오가 삭제되었거나 비공개일 수 있습니다."
        log_error(Exception(error_msg), "유튜브 자막 추출 중")
        return False, error_msg
    except Exception as e:
        error_msg = f"자막 추출 중 오류가 발생했습니다: {str(e)}"
        log_error(e, "유튜브 자막 추출 중")
        return False, error_msg


def save_text_to_file(text: str, filename: str, output_dir: str = "outputs") -> str:
    """
    텍스트를 파일로 저장
    
    Args:
        text: 저장할 텍스트
        filename: 파일명
        output_dir: 출력 디렉토리 (기본값: "outputs")
        
    Returns:
        저장된 파일의 전체 경로
    """
    # 출력 디렉토리 생성
    os.makedirs(output_dir, exist_ok=True)
    
    # 파일 경로 생성
    filepath = os.path.join(output_dir, filename)
    
    # 파일 저장
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(text)
    
    return filepath

