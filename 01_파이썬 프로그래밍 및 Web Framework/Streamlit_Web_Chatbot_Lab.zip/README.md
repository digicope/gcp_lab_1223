# Streamlit Web Chatbot

OpenAI API를 사용하는 대화형 웹 챗봇 애플리케이션입니다.

## 주요 기능

- 🤖 OpenAI GPT 모델 지원 (gpt-4o-mini, gpt-4o, gpt-4-turbo, gpt-3.5-turbo)
- 💬 실시간 스트리밍 대화
- 📝 대화 히스토리 유지
- ⚙️ 모델 및 Temperature 설정
- 🎨 커스터마이징 가능한 시스템 프롬프트
- 🛡️ 에러 처리 및 사용자 친화적인 오류 메시지

## 프로젝트 구조

```
Streamlit_Web_Chatbot/
├── app.py                 # Streamlit 메인 엔트리 포인트
├── requirements.txt       # Python 패키지 의존성
├── .env.example          # 환경변수 템플릿
├── .env                  # 실제 환경변수 (gitignore에 포함)
├── README.md             # 프로젝트 문서
└── src/
    ├── llm.py            # OpenAI API 호출 및 스트리밍 처리
    ├── prompts.py        # 시스템 프롬프트 및 기본 설정
    ├── ui.py             # 채팅 UI 렌더링 함수
    └── utils.py          # 공통 유틸리티 (로깅, 에러 처리)
```

## 설치 및 실행

### 1. 저장소 클론 또는 프로젝트 디렉토리로 이동

```bash
cd Streamlit_Web_Chatbot
```

### 2. 가상 환경 생성 및 활성화 (권장)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. 패키지 설치

```bash
pip install -r requirements.txt
```

### 4. 환경변수 설정

`.env.example` 파일을 참고하여 `.env` 파일을 생성하고 OpenAI API 키를 설정합니다:

```bash
# .env 파일 생성
OPENAI_API_KEY=your_openai_api_key_here
```

또는 `.env.example` 파일을 복사하여 수정:

**Windows:**
```bash
copy .env.example .env
```

**macOS/Linux:**
```bash
cp .env.example .env
```

그리고 `.env` 파일을 열어 `OPENAI_API_KEY` 값을 실제 API 키로 변경합니다.

### 5. 애플리케이션 실행

```bash
streamlit run app.py
```

브라우저가 자동으로 열리며, `http://localhost:8501`에서 챗봇을 사용할 수 있습니다.

## 환경변수

### 필수 환경변수

- `OPENAI_API_KEY`: OpenAI API 키 (필수)

### 선택적 환경변수

- `OPENAI_MODEL`: 기본 모델 이름 (기본값: `gpt-4o-mini`)

## 사용 방법

1. **대화 시작**: 하단의 입력창에 메시지를 입력하고 Enter를 누르거나 전송 버튼을 클릭합니다.

2. **모델 변경**: 사이드바에서 사용할 모델을 선택할 수 있습니다.

3. **Temperature 조정**: 사이드바의 슬라이더로 응답의 창의성을 조절할 수 있습니다 (0.0 = 일관성, 1.0 = 창의성).

4. **시스템 프롬프트 수정**: 사이드바의 텍스트 영역에서 AI의 행동과 응답 스타일을 커스터마이징할 수 있습니다.

5. **대화 초기화**: 사이드바의 "대화 초기화" 버튼을 클릭하여 대화 히스토리를 지울 수 있습니다.

## 기능 상세

### 스트리밍 응답

응답은 토큰 단위로 실시간 스트리밍되어 표시됩니다. 긴 응답도 빠르게 확인할 수 있습니다.

### 에러 처리

다음과 같은 에러 상황을 자동으로 감지하고 사용자 친화적인 메시지를 표시합니다:

- API 키 누락 또는 유효하지 않음
- Rate limit 초과
- 네트워크 연결 오류
- 모델 사용 불가
- 기타 API 오류

### 대화 히스토리 관리

모든 대화는 `st.session_state`를 사용하여 세션 동안 유지됩니다. 페이지를 새로고침하지 않는 한 대화 히스토리가 보존됩니다.

## 배포 팁

### Streamlit Cloud 배포

1. GitHub 저장소에 코드를 푸시합니다.
2. [Streamlit Cloud](https://streamlit.io/cloud)에 로그인합니다.
3. "New app"을 클릭하고 저장소를 선택합니다.
4. 환경변수 섹션에서 `OPENAI_API_KEY`를 추가합니다.
5. 배포를 시작합니다.

### 다른 플랫폼 배포

- **Heroku**: `Procfile`에 `web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0` 추가
- **Docker**: Streamlit 공식 Docker 이미지 사용
- **AWS/GCP/Azure**: 각 플랫폼의 컨테이너 서비스 활용

### 보안 주의사항

- `.env` 파일은 절대 Git에 커밋하지 마세요.
- `.gitignore`에 `.env`가 포함되어 있는지 확인하세요.
- 프로덕션 환경에서는 환경변수를 안전하게 관리하세요.

## 문제 해결

### API 키 오류

- `.env` 파일이 프로젝트 루트에 있는지 확인하세요.
- API 키가 올바르게 설정되었는지 확인하세요.
- Streamlit을 재시작해보세요.

### 패키지 설치 오류

- Python 버전이 3.11 이상인지 확인하세요: `python --version`
- 가상 환경이 활성화되어 있는지 확인하세요.

### 스트리밍이 작동하지 않음

- OpenAI SDK 버전이 최신인지 확인하세요: `pip install --upgrade openai`
- 네트워크 연결을 확인하세요.

## 라이선스

이 프로젝트는 자유롭게 사용 및 수정할 수 있습니다.

## 기여

버그 리포트나 기능 제안은 이슈로 등록해주세요.

