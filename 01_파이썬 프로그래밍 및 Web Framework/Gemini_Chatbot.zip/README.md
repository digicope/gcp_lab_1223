# Gemini 3 챗봇 예제

Google의 Gemini API를 사용한 간단한 챗봇 예제입니다.

## 설치 방법

1. 필요한 패키지 설치:
```bash
pip install -r requirements.txt
```

2. API 키 설정:
   - `.env.example` 파일을 `.env`로 복사
   - `.env` 파일에 Gemini API 키 입력
   - API 키는 [Google AI Studio](https://aistudio.google.com/)에서 발급받을 수 있습니다

```bash
# Windows
copy .env.example .env

# Linux/Mac
cp .env.example .env
```

## 실행 방법

### 콘솔 버전 (main.py)

```bash
python main.py
```

### 웹 버전 (Streamlit)

```bash
streamlit run streamlit_app.py
```

브라우저에서 자동으로 열리며, 웹 인터페이스로 챗봇을 사용할 수 있습니다.

## 사용 방법

### 콘솔 버전
- 챗봇과 대화를 시작하세요
- 종료하려면 `exit`, `quit`, 또는 `종료`를 입력하세요
- `Ctrl+C`로도 종료할 수 있습니다

### 웹 버전
1. 사이드바에서 API 키를 입력하고 "모델 초기화" 버튼 클릭
2. 하단 입력창에 메시지를 입력하고 Enter
3. 대화 기록은 브라우저 세션 동안 유지됩니다
4. "대화 기록 삭제" 버튼으로 초기화 가능

## 주요 기능

- Gemini 1.5 Pro 모델 사용
- 대화 히스토리 관리
- 환경 변수를 통한 API 키 관리
- 에러 처리

## 참고사항

- API 키는 절대 공개 저장소에 커밋하지 마세요
- `.env` 파일은 `.gitignore`에 추가하는 것을 권장합니다

