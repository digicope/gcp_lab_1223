import google.generativeai as genai
import os
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# API 키 설정
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    print("경고: GEMINI_API_KEY 환경 변수가 설정되지 않았습니다.")
    api_key = input("Gemini API 키를 입력하세요: ")

genai.configure(api_key=api_key)

# 사용 가능한 모델 확인 및 초기화
def get_available_model():
    """사용 가능한 모델을 찾아 반환"""
    print("사용 가능한 모델을 확인하는 중...")
    
    # 먼저 사용 가능한 모델 목록을 가져옴
    try:
        available_models = []
        for model in genai.list_models():
            if 'generateContent' in model.supported_generation_methods:
                # 모델 이름에서 "models/" 접두사 제거
                model_name = model.name.replace('models/', '')
                available_models.append(model_name)
        
        if available_models:
            print(f"사용 가능한 모델: {', '.join(available_models)}")
            
            # 우선순위에 따라 모델 선택
            priority_models = [
                "gemini-1.5-flash",
                "gemini-1.5-pro", 
                "gemini-pro",
                "gemini-1.5-flash-latest",
                "gemini-1.5-pro-latest"
            ]
            
            # 우선순위 모델 중 사용 가능한 것 찾기
            for priority_model in priority_models:
                if priority_model in available_models:
                    selected_model = priority_model
                    break
            else:
                # 우선순위 모델이 없으면 첫 번째 사용 가능한 모델 사용
                selected_model = available_models[0]
            
            print(f"선택된 모델: {selected_model}")
            model = genai.GenerativeModel(selected_model)
            return model, selected_model
        else:
            raise Exception("generateContent를 지원하는 모델을 찾을 수 없습니다.")
            
    except Exception as e:
        print(f"모델 목록 확인 중 오류: {e}")
        # 모델 목록을 가져올 수 없는 경우 기본 모델 시도
        fallback_models = ["gemini-pro", "gemini-1.5-flash", "gemini-1.5-pro"]
        for model_name in fallback_models:
            try:
                print(f"기본 모델 '{model_name}' 시도 중...")
                model = genai.GenerativeModel(model_name)
                return model, model_name
            except:
                continue
        
        raise Exception("사용 가능한 모델을 찾을 수 없습니다. API 키와 인터넷 연결을 확인해주세요.")

# 모델 초기화
try:
    model, model_name = get_available_model()
    print(f"✓ Gemini 모델 '{model_name}'이 초기화되었습니다.")
    print("챗봇과 대화를 시작하세요! (종료하려면 'exit' 또는 'quit' 입력)\n")
except Exception as e:
    print(f"모델 초기화 오류: {e}")
    exit(1)

# 채팅 히스토리 관리
chat = model.start_chat(history=[])

def main():
    """메인 챗봇 루프"""
    while True:
        try:
            # 사용자 입력 받기
            user_input = input("사용자: ").strip()
            
            # 종료 조건 확인
            if user_input.lower() in ["exit", "quit", "종료"]:
                print("\n챗봇을 종료합니다. 안녕히 가세요!")
                break
            
            # 빈 입력 처리
            if not user_input:
                continue
            
            # 모델에 메시지 전송 및 응답 받기
            response = chat.send_message(user_input)
            
            # 응답 출력
            print(f"챗봇: {response.text}\n")
            
        except KeyboardInterrupt:
            print("\n\n챗봇을 종료합니다. 안녕히 가세요!")
            break
        except Exception as e:
            print(f"오류가 발생했습니다: {e}\n")

if __name__ == "__main__":
    main()

