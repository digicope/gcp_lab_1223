import streamlit as st
import google.generativeai as genai
import os
from dotenv import load_dotenv

# 페이지 설정
st.set_page_config(
    page_title="Gemini 챗봇",
    page_icon="🤖",
    layout="wide"
)

# 환경 변수 로드
load_dotenv()

# 세션 상태 초기화
if "messages" not in st.session_state:
    st.session_state.messages = []
if "model" not in st.session_state:
    st.session_state.model = None
if "model_name" not in st.session_state:
    st.session_state.model_name = None

def get_available_model(api_key):
    """사용 가능한 모델을 찾아 반환"""
    genai.configure(api_key=api_key)
    
    try:
        available_models = []
        for model in genai.list_models():
            if 'generateContent' in model.supported_generation_methods:
                model_name = model.name.replace('models/', '')
                available_models.append(model_name)
        
        if available_models:
            # 우선순위에 따라 모델 선택
            priority_models = [
                "gemini-1.5-flash",
                "gemini-1.5-pro", 
                "gemini-pro",
                "gemini-1.5-flash-latest",
                "gemini-1.5-pro-latest"
            ]
            
            for priority_model in priority_models:
                if priority_model in available_models:
                    selected_model = priority_model
                    break
            else:
                selected_model = available_models[0]
            
            model = genai.GenerativeModel(selected_model)
            return model, selected_model
        else:
            return None, None
            
    except Exception as e:
        st.error(f"모델 확인 중 오류: {e}")
        return None, None

# 사이드바 - API 키 설정
with st.sidebar:
    st.title("⚙️ 설정")
    
    api_key = st.text_input(
        "Gemini API 키",
        type="password",
        value=os.getenv("GEMINI_API_KEY", ""),
        help="Google AI Studio에서 발급받은 API 키를 입력하세요"
    )
    
    if st.button("모델 초기화"):
        if api_key:
            with st.spinner("모델을 초기화하는 중..."):
                model, model_name = get_available_model(api_key)
                if model:
                    st.session_state.model = model
                    st.session_state.model_name = model_name
                    st.success(f"✓ 모델 '{model_name}' 초기화 완료!")
                    # 모델이 초기화되면 대화 히스토리 초기화
                    st.session_state.messages = []
                else:
                    st.error("사용 가능한 모델을 찾을 수 없습니다.")
        else:
            st.error("API 키를 입력해주세요.")
    
    if st.session_state.model_name:
        st.info(f"현재 모델: {st.session_state.model_name}")
    
    st.divider()
    
    if st.button("🗑️ 대화 기록 삭제"):
        st.session_state.messages = []
        st.rerun()

# 메인 영역
st.title("🤖 Gemini 챗봇")
st.markdown("Gemini AI와 대화를 나눠보세요!")

# 모델이 초기화되지 않은 경우 안내
if not st.session_state.model:
    st.warning("⚠️ 사이드바에서 API 키를 입력하고 '모델 초기화' 버튼을 클릭해주세요.")
    st.info("💡 API 키는 [Google AI Studio](https://aistudio.google.com/)에서 발급받을 수 있습니다.")
else:
    # 채팅 메시지 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # 사용자 입력
    if prompt := st.chat_input("메시지를 입력하세요..."):
        # 사용자 메시지를 세션에 추가
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # 챗봇 응답 생성
        with st.chat_message("assistant"):
            with st.spinner("생각하는 중..."):
                try:
                    # 채팅 히스토리 구성
                    chat_history = []
                    for msg in st.session_state.messages[:-1]:  # 마지막 메시지 제외
                        if msg["role"] == "user":
                            chat_history.append({"role": "user", "parts": [msg["content"]]})
                        elif msg["role"] == "assistant":
                            chat_history.append({"role": "model", "parts": [msg["content"]]})
                    
                    # 채팅 시작
                    chat = st.session_state.model.start_chat(history=chat_history)
                    
                    # 응답 생성
                    response = chat.send_message(prompt)
                    response_text = response.text
                    
                    st.markdown(response_text)
                    
                    # 챗봇 응답을 세션에 추가
                    st.session_state.messages.append({"role": "assistant", "content": response_text})
                    
                except Exception as e:
                    error_msg = f"오류가 발생했습니다: {str(e)}"
                    st.error(error_msg)
                    st.session_state.messages.append({"role": "assistant", "content": error_msg})

# 하단 정보
st.divider()
st.caption("💡 팁: 대화 기록은 브라우저 세션 동안 유지됩니다. 새로고침하면 초기화됩니다.")

