import os
import fitz  # PyMuPDF
import pandas as pd
import uuid
from datetime import datetime
from contextlib import asynccontextmanager
from fastapi import FastAPI, UploadFile, File, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from google.cloud import storage, bigquery
import google.generativeai as genai
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# 설정 정보
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
BUCKET_NAME = os.getenv("GCS_BUCKET_NAME")
DATASET_ID = os.getenv("BQ_DATASET_ID")
TABLE_ID = os.getenv("BQ_TABLE_ID")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# 서비스 클라이언트 초기화
# BigQuery 클라이언트를 PROJECT_ID와 함께 초기화 (제공된 예제 방식)
storage_client = storage.Client(project=PROJECT_ID)
bq_client = bigquery.Client(project=PROJECT_ID)
genai.configure(api_key=GEMINI_API_KEY)

# BigQuery 테이블 전체 경로
FULL_TABLE_ID = f"{PROJECT_ID}.{DATASET_ID}.{TABLE_ID}"

def ensure_bq_table():
    """BigQuery 데이터셋과 테이블이 존재하는지 확인하고 없으면 생성합니다 (제공된 예제 스타일)."""
    dataset_ref = bq_client.dataset(DATASET_ID)
    try:
        bq_client.get_dataset(dataset_ref)
    except Exception:
        dataset = bigquery.Dataset(dataset_ref)
        dataset.location = "US"
        bq_client.create_dataset(dataset, timeout=30)
        print(f"Dataset {DATASET_ID} created.")

    # 스키마 정의 (제공된 예제 방식)
    schema = [
        bigquery.SchemaField("id", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("filename", "STRING", mode="REQUIRED"),
        bigquery.SchemaField("extracted_text", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("summary", "STRING", mode="NULLABLE"),
        bigquery.SchemaField("created_at", "TIMESTAMP", mode="REQUIRED"),
    ]
    
    table = bigquery.Table(FULL_TABLE_ID, schema=schema)
    
    try:
        bq_client.get_table(FULL_TABLE_ID)
    except Exception:
        bq_client.create_table(table, timeout=30)
        print(f"Table {TABLE_ID} created.")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 시작 시 실행: 테이블 존재 여부 확인
    ensure_bq_table()
    yield

app = FastAPI(lifespan=lifespan)
templates = Jinja2Templates(directory="templates")

def extract_text_from_pdf(pdf_content: bytes):
    """PDF 바이트 데이터에서 텍스트를 추출합니다."""
    text = ""
    try:
        with fitz.open(stream=pdf_content, filetype="pdf") as doc:
            for page in doc:
                text += page.get_text()
    except Exception as e:
        print(f"Error extracting text: {e}")
        return ""
    return text

def summarize_text(text: str):
    """Gemini API를 사용하여 텍스트를 요약합니다. (gemini-2.5-flash 최신 모델 사용)"""
    try:
        # 요청하신 최신 모델 gemini-2.5-flash 시도
        model = genai.GenerativeModel("gemini-2.5-flash") # 현재 가장 범용적인 모델로 설정 (2.5가 미지원일 경우 대비)
        # 만약 gemini-2.5-flash가 지원된다면 아래 주석 해제하여 사용
        # model = genai.GenerativeModel("gemini-2.5-flash")
    except:
        model = genai.GenerativeModel("gemini-2.5-flash")
        
    prompt = f"다음 PDF 추출 내용을 한국어로 요약해줘:\n\n{text}"
    response = model.generate_content(prompt)
    return response.text

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    # GCS에서 파일 목록 가져오기
    try:
        bucket = storage_client.bucket(BUCKET_NAME)
        blobs = bucket.list_blobs()
        files = [blob.name for blob in blobs if blob.name.endswith(".pdf")]
    except Exception as e:
        print(f"GCS Error: {e}")
        files = []
    
    return templates.TemplateResponse("index.html", {"request": request, "files": files})

@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="PDF 파일만 업로드 가능합니다.")
    
    bucket = storage_client.bucket(BUCKET_NAME)
    blob = bucket.blob(file.filename)
    
    content = await file.read()
    blob.upload_from_string(content, content_type="application/pdf")
    
    return RedirectResponse(url="/", status_code=303)

@app.post("/process")
async def process_pdf(filename: str = Form(...)):
    # 1. GCS에서 파일 읽기
    bucket = storage_client.bucket(BUCKET_NAME)
    blob = bucket.blob(filename)
    pdf_content = blob.download_as_bytes()
    
    # 2. 텍스트 추출
    extracted_text = extract_text_from_pdf(pdf_content)
    if not extracted_text:
        raise HTTPException(status_code=500, detail="텍스트 추출에 실패했습니다.")
    
    # 3. Gemini 요약
    try:
        summary = summarize_text(extracted_text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI 요약 실패: {str(e)}")
    
    # 4. BigQuery 저장 (제공된 예제의 insert_rows_json 방식 사용)
    rows_to_insert = [
        {
            "id": str(uuid.uuid4()),
            "filename": filename,
            "extracted_text": extracted_text,
            "summary": summary,
            "created_at": datetime.utcnow().isoformat()
        }
    ]
    
    errors = bq_client.insert_rows_json(FULL_TABLE_ID, rows_to_insert)
    if errors:
        raise HTTPException(status_code=500, detail=f"BigQuery 저장 실패: {errors}")
    
    return RedirectResponse(url="/results", status_code=303)

@app.get("/results", response_class=HTMLResponse)
async def show_results(request: Request):
    # BigQuery에서 데이터 조회 (제공된 예제의 to_dataframe 방식 참조)
    query = f"""
    SELECT 
        filename, 
        summary, 
        created_at 
    FROM `{FULL_TABLE_ID}` 
    ORDER BY created_at DESC
    """
    
    try:
        # Pandas DataFrame으로 읽기 (제공된 예제 방식)
        df = bq_client.query(query).to_dataframe()
        
        # 날짜 포맷팅 등 처리 (필요시)
        if not df.empty and 'created_at' in df.columns:
            df['created_at'] = df['created_at'].dt.strftime('%Y-%m-%d %H:%M:%S')
            
        rows = df.to_dict('records')
    except Exception as e:
        print(f"Query error: {e}")
        rows = []
        
    return templates.TemplateResponse("results.html", {"request": request, "rows": rows})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
