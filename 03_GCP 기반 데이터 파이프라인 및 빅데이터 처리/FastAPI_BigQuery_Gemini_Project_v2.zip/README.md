# PDF AI 요약 및 BigQuery 저장 서비스

이 프로젝트는 FastAPI를 기반으로 사용자가 업로드한 PDF 파일에서 텍스트를 추출하고, Google Gemini AI를 사용하여 요약한 뒤 그 결과를 Google Cloud Storage(GCS)와 BigQuery에 저장하는 웹 애플리케이션입니다.

## 주요 기능

1.  **PDF 업로드**: 로컬 PDF 파일을 Google Cloud Storage에 업로드합니다.
2.  **텍스트 추출 및 AI 요약**:
    -   `PyMuPDF`를 사용하여 PDF에서 텍스트를 추출합니다.
    -   추출된 텍스트를 `Gemini 2.5 Flash` 모델을 사용하여 요약합니다.
3.  **BigQuery 저장**: 추출된 원본 텍스트와 요약 결과를 BigQuery 테이블에 저장합니다.
4.  **결과 조회**: BigQuery에 저장된 데이터를 웹페이지에서 리스트 형태로 조회할 수 있습니다.

## 사전 준비 사항

1.  **Google Cloud 프로젝트 설정**:
    -   Google Cloud 콘솔에서 프로젝트(`gknu-digicope`)를 생성합니다.
    -   Cloud Storage 버킷(`mybucket-105186977018`)을 생성합니다.
    -   BigQuery API, Cloud Storage API, Generative Language API를 활성화합니다.
2.  **Gemini API Key 발급**: [Google AI Studio](https://aistudio.google.com/)에서 API Key를 발급받습니다.
3.  **인증 설정**: 서비스 계정 키(`google_credentials.json`)를 프로젝트 루트 디렉토리에 위치시킵니다.

## 설치 및 실행 방법

### 1. 프로젝트 복제 및 이동
```bash
cd FastAPI_BigQuery_Gemini_Project_v2
```

### 2. 가상환경 설정 및 라이브러리 설치
```bash
python -m venv .venv
# Windows (PowerShell)
.\.venv\Scripts\Activate.ps1
# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

### 3. 환경 변수 설정
`.env` 파일을 열어 `GEMINI_API_KEY`를 실제 키로 수정합니다. (프로젝트 ID, 버킷 이름 등은 이미 설정되어 있습니다.)
```env
GOOGLE_APPLICATION_CREDENTIALS=google_credentials.json
GOOGLE_CLOUD_PROJECT=gknu-digicope
GCS_BUCKET_NAME=mybucket-105186977018
BQ_DATASET_ID=pdf_processed
BQ_TABLE_ID=summary
GEMINI_API_KEY=your-actual-api-key
```

### 4. 애플리케이션 실행
```bash
python main.py
```
애플리케이션이 실행되면 브라우저에서 `http://localhost:8000`으로 접속합니다.

## 사용 방법

1.  **메인 페이지 (`/`)**: 
    -   `파일 선택` 버튼을 눌러 PDF 파일을 업로드합니다.
    -   업로드된 파일 목록에서 `텍스트 추출 및 요약` 버튼을 클릭합니다.
2.  **결과 확인 (`/results`)**:
    -   처리가 완료되면 자동으로 결과 페이지로 이동합니다.
    -   BigQuery 테이블에 저장된 파일명, 요약 내용, 처리 시간을 확인할 수 있습니다.

## 기술 스택

-   **Backend**: FastAPI
-   **Frontend**: Jinja2 Templates, Bootstrap 5
-   **AI**: Google Gemini 2.5 Flash
-   **Database/Storage**: Google BigQuery, Google Cloud Storage
-   **PDF Library**: PyMuPDF (fitz)
-   **Data Analysis**: Pandas (BigQuery 연동용)

