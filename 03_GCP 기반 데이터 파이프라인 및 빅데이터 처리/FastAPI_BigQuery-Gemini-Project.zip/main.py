import os
import io
from fastapi import FastAPI, UploadFile, File, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from google.cloud import storage, bigquery
from google import genai
from pypdf import PdfReader
from datetime import datetime
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# 환경 변수 설정
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GCS_BUCKET_NAME = os.getenv("GCS_BUCKET_NAME")
GOOGLE_CLOUD_PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT", "gknu-digicope")
BQ_DATASET_ID = os.getenv("BQ_DATASET_ID", "pdf_processing")
BQ_TABLE_ID = os.getenv("BQ_TABLE_ID", "summaries")

# Google Cloud 인증은 환경 변수 GOOGLE_APPLICATION_CREDENTIALS (JSON 키 경로)를 통해 자동으로 수행됩니다.

# 클라이언트 초기화
storage_client = storage.Client(project=GOOGLE_CLOUD_PROJECT)
bigquery_client = bigquery.Client(project=GOOGLE_CLOUD_PROJECT)
gemini_client = genai.Client(api_key=GEMINI_API_KEY)
bucket = storage_client.bucket(GCS_BUCKET_NAME)

app = FastAPI()

# GCS 폴더(Prefix) 설정
UPLOAD_PREFIX = "uploads/"
PROCESSED_PREFIX = "processed/"

# 템플릿 설정
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # GCS에서 업로드된 파일 목록 가져오기
    blobs = storage_client.list_blobs(GCS_BUCKET_NAME, prefix=UPLOAD_PREFIX)
    pdf_files = [blob.name.replace(UPLOAD_PREFIX, "") for blob in blobs if blob.name.lower().endswith('.pdf') and blob.name != UPLOAD_PREFIX]
    return templates.TemplateResponse("index.html", {"request": request, "files": pdf_files})

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        blob_name = f"{UPLOAD_PREFIX}{file.filename}"
        blob = bucket.blob(blob_name)
        
        # 스트림 방식으로 GCS에 직접 업로드
        blob.upload_from_file(file.file, content_type=file.content_type)
        
        return JSONResponse(content={"filename": file.filename, "message": "GCS 업로드 성공"})
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/process")
async def process_pdf(filename: str = Form(...)):
    try:
        # 1. GCS에서 PDF 파일 읽기
        blob_name = f"{UPLOAD_PREFIX}{filename}"
        blob = bucket.blob(blob_name)
        
        if not blob.exists():
            return JSONResponse(content={"error": "GCS에서 파일을 찾을 수 없습니다."}, status_code=404)

        # PDF 데이터를 메모리로 다운로드
        pdf_data = blob.download_as_bytes()
        pdf_stream = io.BytesIO(pdf_data)
        
        # 2. 텍스트 추출
        reader = PdfReader(pdf_stream)
        extracted_text = ""
        for page in reader.pages:
            extracted_text += page.extract_text() + "\n"

        # 추출된 텍스트 GCS 저장
        text_filename = f"{os.path.splitext(filename)[0]}_extracted.txt"
        text_blob = bucket.blob(f"{PROCESSED_PREFIX}{text_filename}")
        text_blob.upload_from_string(extracted_text, content_type="text/plain")

        # 3. Gemini를 이용한 요약 (Gemini 2.5 Flash 모델 사용)
        prompt = f"다음 텍스트를 핵심 내용을 중심으로 한국어로 요약해줘:\n\n{extracted_text[:30000]}"
        
        response = gemini_client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt
        )
        summary_text = response.text

        # 요약된 텍스트 GCS 저장
        summary_filename = f"{os.path.splitext(filename)[0]}_summary.txt"
        summary_blob = bucket.blob(f"{PROCESSED_PREFIX}{summary_filename}")
        summary_blob.upload_from_string(summary_text, content_type="text/plain")

        # 4. BigQuery에 데이터 저장
        table_id = f"{bigquery_client.project}.{BQ_DATASET_ID}.{BQ_TABLE_ID}"
        
        # 테이블 스키마 정의 및 생성 (없을 경우)
        schema = [
            bigquery.SchemaField("filename", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("extracted_text", "STRING", mode="NULLABLE"),
            bigquery.SchemaField("summary", "STRING", mode="NULLABLE"),
            bigquery.SchemaField("created_at", "TIMESTAMP", mode="REQUIRED"),
        ]
        
        try:
            bigquery_client.get_table(table_id)
        except Exception:
            dataset = bigquery.Dataset(f"{bigquery_client.project}.{BQ_DATASET_ID}")
            dataset.location = "US"  # 또는 적절한 리전
            try:
                bigquery_client.create_dataset(dataset, exists_ok=True)
            except Exception: pass
            
            table = bigquery.Table(table_id, schema=schema)
            bigquery_client.create_table(table)

        rows_to_insert = [
            {
                "filename": filename,
                "extracted_text": extracted_text,
                "summary": summary_text,
                "created_at": datetime.now().isoformat()
            }
        ]
        
        errors = bigquery_client.insert_rows_json(table_id, rows_to_insert)
        if errors:
            raise Exception(f"BigQuery 삽입 오류: {errors}")

        return JSONResponse(content={
            "message": "GCS 처리 및 BigQuery 저장 완료",
            "extracted_text_file": text_filename,
            "summary_file": summary_filename,
            "summary": summary_text
        })

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.get("/bigquery_data")
async def get_bigquery_data():
    try:
        table_id = f"{bigquery_client.project}.{BQ_DATASET_ID}.{BQ_TABLE_ID}"
        query = f"SELECT filename, summary, created_at FROM `{table_id}` ORDER BY created_at DESC LIMIT 20"
        query_job = bigquery_client.query(query)
        results = query_job.result()
        
        data = []
        for row in results:
            data.append({
                "filename": row.filename,
                "summary": row.summary,
                "created_at": row.created_at.strftime("%Y-%m-%d %H:%M:%S")
            })
        return JSONResponse(content=data)
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.post("/delete_entry")
async def delete_entry(filename: str = Form(...), created_at: str = Form(...)):
    try:
        table_id = f"{bigquery_client.project}.{BQ_DATASET_ID}.{BQ_TABLE_ID}"
        # 참조 코드의 'CREATE OR REPLACE TABLE' 패턴 활용
        query = f"""
        CREATE OR REPLACE TABLE `{table_id}` AS
        SELECT *
        FROM `{table_id}`
        WHERE NOT (filename = '{filename}' AND CAST(created_at AS STRING) LIKE '{created_at}%')
        """
        query_job = bigquery_client.query(query)
        query_job.result()
        
        return JSONResponse(content={"message": f"{filename} 데이터가 삭제되었습니다."})
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
